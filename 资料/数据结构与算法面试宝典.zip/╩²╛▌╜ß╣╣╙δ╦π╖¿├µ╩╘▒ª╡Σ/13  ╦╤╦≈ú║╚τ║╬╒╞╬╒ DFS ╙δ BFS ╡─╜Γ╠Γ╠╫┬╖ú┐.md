### 本资源由 itjc8.com 收集整理
<p data-nodeid="6721" class="">深度优先遍历（Depth First Search，简称 DFS） 与广度优先遍历（Breath First Search，简称 BFS）是图论中两种非常重要的算法，生产上广泛用于拓扑排序、寻路（走迷宫）、搜索引擎、爬虫等。因此，算法面试也经常考察这两种搜索算法。</p>
<p data-nodeid="6722">在本讲，我们将重点介绍面试中常用的 DFS 与 BFS 代码技巧。学完本讲，你将收获：</p>
<ul data-nodeid="6723">
<li data-nodeid="6724">
<p data-nodeid="6725">DFS 搜索与剪枝</p>
</li>
<li data-nodeid="6726">
<p data-nodeid="6727">BFS 搜索与剪枝</p>
</li>
</ul>
<p data-nodeid="6728">让我们马上开始。</p>
<h3 data-nodeid="6729">DFS 概述</h3>
<p data-nodeid="6730">在玩迷宫游戏的时候，使用的策略就是 DFS，也就是当一条路走不通的时候，我们再尝试换一条路，直到走通为止。</p>
<p data-nodeid="6731">下面我们也从这个游戏展开，一步一步得到常用的 DFS 解题模板。以下图为例，位置 0 表示出发点，然后只能上下左右四个方向移动，我们希望能从圆圈位置出发，最后走到五角星的终点位置。</p>
<p data-nodeid="6732"><img src="https://s0.lgstatic.com/i/image6/M00/34/1A/Cgp9HWBwLIuAe-K4AAThUffhgBs401.png" alt="Drawing 0.png" data-nodeid="7053"></p>
<p data-nodeid="6733">比如，刚从入口出发的时候，我们可以走到 1、2 这两个位置。如果用伪代码进表示，可以写出如下代码：</p>
<pre class="lang-java" data-nodeid="6734"><code data-language="java"><span class="hljs-keyword">void</span> 走迷宫(<span class="hljs-keyword">int</span> start) {
  位置<span class="hljs-number">1</span>， 位置<span class="hljs-number">2</span> = getNextPos(start); <span class="hljs-comment">// 拿到后继位置[1, 5]</span>

  走迷宫(位置<span class="hljs-number">1</span>)
  <span class="hljs-keyword">if</span> success:
      找到出口-&gt; <span class="hljs-keyword">return</span>

  走迷宫(位置<span class="hljs-number">2</span>出发)
  <span class="hljs-keyword">if</span> success:
      找到出口-&gt; <span class="hljs-keyword">return</span>
}
</code></pre>
<p data-nodeid="6735">通过上面这样直白的代码，已经可以清晰地表达我们的思路了。但是还存在一些问题，下面我们一步一步讨论。</p>
<h4 data-nodeid="6736">问题 1</h4>
<p data-nodeid="6737">后面能走的位置只有 2 个的时候，处理起来是比较好写的。但是如果有很多位置都可以走呢？发现这种情况，就是时候<strong data-nodeid="7062">用循环</strong>来改写我们的 DFS 模板了。</p>
<pre class="lang-java" data-nodeid="6738"><code data-language="java"><span class="hljs-keyword">void</span> 走迷宫(<span class="hljs-keyword">int</span> start) {
  <span class="hljs-function"><span class="hljs-keyword">for</span> pos in <span class="hljs-title">getNextPos</span><span class="hljs-params">(start)</span> </span>{
      走迷宫(pos);
      <span class="hljs-keyword">if</span> success {
          <span class="hljs-keyword">return</span>;
      }
  }
}
</code></pre>
<h4 data-nodeid="6739">问题 2</h4>
<p data-nodeid="6740">虽然上述代码中引入了 success 变量，但是并没有讨论什么时候才是 success。不过走迷宫，肯定是找到最终出口，才算是成功。于是我们可以将代码改写如下：</p>
<pre class="lang-java" data-nodeid="6741"><code data-language="java"><span class="hljs-keyword">void</span> 走迷宫(<span class="hljs-keyword">int</span> start) {
  <span class="hljs-keyword">if</span> start == 五角星 { <span class="hljs-comment">// &lt;-- 成功了，当然不需要再走了</span>
      success = <span class="hljs-keyword">true</span>
      <span class="hljs-keyword">return</span>
  }
  <span class="hljs-function"><span class="hljs-keyword">for</span> pos in <span class="hljs-title">getNextPos</span><span class="hljs-params">(start)</span> </span>{
      走迷宫(pos);
      <span class="hljs-keyword">if</span> success {
          <span class="hljs-keyword">return</span>;
      }
  }
}
</code></pre>
<h4 data-nodeid="6742">问题 3</h4>
<p data-nodeid="6743">另外，我们还需要处理一些重复的问题，比如下图所示的情况：</p>
<p data-nodeid="6744"><img src="https://s0.lgstatic.com/i/image6/M00/34/1A/Cgp9HWBwLJiAVEFMAAPis02Ruvg421.png" alt="Drawing 1.png" data-nodeid="7069"></p>
<p data-nodeid="6745">假设一下，当从位置 0 走到位置 2 之后，其代码应该如下：</p>
<pre class="lang-java" data-nodeid="6746"><code data-language="java"><span class="hljs-keyword">void</span> 走迷宫(位置<span class="hljs-number">0</span>) {
  [位置<span class="hljs-number">1</span>, 位置<span class="hljs-number">2</span>] = getNextPos(位置<span class="hljs-number">0</span>)
  <span class="hljs-comment">//.. </span>
  走迷宫(位置<span class="hljs-number">2</span>); 
}
<span class="hljs-keyword">void</span> 走迷宫(位置<span class="hljs-number">2</span>) {
  [位置<span class="hljs-number">0</span>, 位置<span class="hljs-number">1</span>, 位置<span class="hljs-number">3</span>， 位置<span class="hljs-number">4</span>] = getNextPos(位置<span class="hljs-number">2</span>)
  <span class="hljs-comment">//...</span>
  走迷宫(位置<span class="hljs-number">0</span>);   <span class="hljs-comment">// &lt;---- 这里会再次访问位置0</span>
}
</code></pre>
<p data-nodeid="6747">但是当路径如下图所示，两个位置存在环的情况时，就会一直在递归里面。</p>
<p data-nodeid="6748"><img src="https://s0.lgstatic.com/i/image6/M00/34/23/CioPOWBwLJ-ATFhdAABKyVvexQk941.png" alt="Drawing 2.png" data-nodeid="7074"></p>
<p data-nodeid="6749">那么，有没有什么办法可以处理这种回环问题呢？如果我们能够标记一下已经访问过的结点，就可以破解这个环了。</p>
<p data-nodeid="6750"><img src="https://s0.lgstatic.com/i/image6/M00/34/1A/Cgp9HWBwLKaAD7D0AABYDtLlfjg808.png" alt="Drawing 3.png" data-nodeid="7078"></p>
<p data-nodeid="6751">比如，当访问位置 0 之后，将其标记为“已访问”（绿色的叉），再从位置 2 遍历的时候，如果发现位置 0 已经访问过了，就不再访问。经过上述分析，代码可以更新如下：</p>
<pre class="lang-java" data-nodeid="6752"><code data-language="java"><span class="hljs-keyword">void</span> 走迷宫(<span class="hljs-keyword">int</span> start) {
  <span class="hljs-keyword">if</span> start == 五角星 { <span class="hljs-comment">// &lt;-- 成功了，当然不需要再走了</span>
      success = <span class="hljs-keyword">true</span>
      <span class="hljs-keyword">return</span>
  }
  <span class="hljs-function"><span class="hljs-keyword">for</span> pos in <span class="hljs-title">getNextPos</span><span class="hljs-params">(start)</span> </span>{
      <span class="hljs-keyword">if</span> (pos 已访问) <span class="hljs-keyword">continue</span>;
      设置pos为已访问
      走迷宫(pos);
      <span class="hljs-keyword">if</span> success {
          <span class="hljs-keyword">return</span>;
      }
  }
}
</code></pre>
<h4 data-nodeid="6753">DFS 的模板 1</h4>
<p data-nodeid="6754">到这里，我们已经得到了 DFS 的模板伪代码。这里将 opt 设置为每次可以做出的选择，代码如下：</p>
<pre class="lang-java" data-nodeid="6755"><code data-language="java"><span class="hljs-keyword">boolean</span> vis[N];
<span class="hljs-function"><span class="hljs-keyword">void</span> <span class="hljs-title">DFS</span><span class="hljs-params">(<span class="hljs-keyword">int</span> start)</span> </span>{
  <span class="hljs-keyword">if</span> start == end {
      success = <span class="hljs-keyword">true</span>
      <span class="hljs-keyword">return</span>
  }
  <span class="hljs-comment">// 遍历当前可以做出的选择</span>
  <span class="hljs-function"><span class="hljs-keyword">for</span> opt in <span class="hljs-title">getOptions</span><span class="hljs-params">(start)</span> </span>{
      <span class="hljs-keyword">if</span> (vis[opt]) <span class="hljs-keyword">continue</span>;
      vis[opt] = <span class="hljs-keyword">true</span>;
      dfs(opt);
      <span class="hljs-keyword">if</span> success {
          <span class="hljs-keyword">return</span>;
      }
  }
}
</code></pre>
<p data-nodeid="6756">接下来，我们尝试使用上面这个模板解决一些题目。</p>
<h3 data-nodeid="6757">DFS 连通域问题</h3>
<h4 data-nodeid="6758">例 1：替换字母</h4>
<p data-nodeid="6759">【<strong data-nodeid="7110">题目</strong>】给你一个矩阵 A，里面只包含字母 ‘O’ 和 'X'，如果一个 'O' 上下左右四周都被 'X' 包围，那么这个 'O' 会被替换成 'X'。请你写程序处理一下这个过程。</p>
<p data-nodeid="6760"><img src="https://s0.lgstatic.com/i/image6/M00/34/1A/Cgp9HWBwLLCAcS1NAAA2jBxc2Hc121.png" alt="Drawing 4.png" data-nodeid="7113"></p>
<p data-nodeid="6761"><strong data-nodeid="7141">解释</strong>：由于中心的 'O' 四周都被 'X' 包围，所以需要被换成 'X'，而第 A[0][0] = 'O' 靠着边，所以不能被替换。</p>
<p data-nodeid="6762">【<strong data-nodeid="7151">分析</strong>】我们曾经在“<a href="https://kaiwu.lagou.com/course/courseInfo.htm?courseId=685#/detail/pc?id=6696&amp;fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7149">第 07 讲｜并查集</a>”中讲解过这个题目。实际上，这道题还有另外一种思路。可以演示如下：</p>
<p data-nodeid="6763"><img src="https://s0.lgstatic.com/i/image6/M00/34/1A/Cgp9HWBwLLmAe45dAAa82spZOiQ958.gif" alt="1.gif" data-nodeid="7154"></p>
<p data-nodeid="6764">因此，这道题目的重点就是遍历每一个边缘的点，以及与之相邻的点。如果把这个问题的求解过程看成走迷宫，那么需要稍微做出两点变动。</p>
<ul data-nodeid="6765">
<li data-nodeid="6766">
<p data-nodeid="6767">原始问题中的走迷宫，需要用 vis 专门记录某<strong data-nodeid="7161">个点是否已经被访问过了</strong>而这道题中，我们可以直接在给定的数组上进行标记（visited）。</p>
</li>
<li data-nodeid="6768">
<p data-nodeid="6769">原始问题中的走迷宫，需要走到某个具体的位置就结束。而这道题里，我们需要遍历所有相连的结点。</p>
</li>
</ul>
<p data-nodeid="6770">【<strong data-nodeid="7168">代码</strong>】到这里，就可以写出如下代码了：</p>
<pre class="lang-java" data-nodeid="6771"><code data-language="java"><span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">Solution</span> </span>{
    <span class="hljs-keyword">private</span> <span class="hljs-keyword">char</span> VIS = <span class="hljs-string">'A'</span>;
    <span class="hljs-keyword">private</span> <span class="hljs-keyword">int</span>[][] dir = {{<span class="hljs-number">0</span>, <span class="hljs-number">1</span>}, {<span class="hljs-number">0</span>, -<span class="hljs-number">1</span>}, {<span class="hljs-number">1</span>, <span class="hljs-number">0</span>}, {-<span class="hljs-number">1</span>, <span class="hljs-number">0</span>}};
    <span class="hljs-keyword">private</span> <span class="hljs-keyword">int</span> R, C;
    <span class="hljs-function"><span class="hljs-keyword">private</span> <span class="hljs-keyword">void</span> <span class="hljs-title">dfs</span><span class="hljs-params">(<span class="hljs-keyword">char</span>[][] A, <span class="hljs-keyword">int</span> r, <span class="hljs-keyword">int</span> c)</span> </span>{
        <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> d = <span class="hljs-number">0</span>; d &lt; <span class="hljs-number">4</span>; d++) {
            <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> nr = r + dir[d][<span class="hljs-number">0</span>];
            <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> nc = c + dir[d][<span class="hljs-number">1</span>];
            <span class="hljs-keyword">if</span> (nr &lt; <span class="hljs-number">0</span> || nr &gt;= R ||
                nc &lt; <span class="hljs-number">0</span> || nc &gt;= C) {
                <span class="hljs-keyword">continue</span>;
            }
            <span class="hljs-keyword">if</span> (A[nr][nc] == <span class="hljs-string">'O'</span>) {
                A[nr][nc] = VIS;
                dfs(A, nr, nc);
            }
        }
 
    }
    <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">void</span> <span class="hljs-title">solve</span><span class="hljs-params">(<span class="hljs-keyword">char</span>[][] A)</span> </span>{
        <span class="hljs-keyword">if</span> (A == <span class="hljs-keyword">null</span> || A.length == <span class="hljs-number">0</span>) {
            <span class="hljs-keyword">return</span>;
        }
        R = A.length;
        C = A[<span class="hljs-number">0</span>].length;
        <span class="hljs-comment">// Step 1. 从边缘出发，遍历所有与之相邻的点。</span>
        <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> r = <span class="hljs-number">0</span>; r &lt; R; r++) {
            <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> c = <span class="hljs-number">0</span>; c &lt; C; c++) {
                <span class="hljs-keyword">if</span> (r == <span class="hljs-number">0</span> || c == <span class="hljs-number">0</span> || 
                    r == R - <span class="hljs-number">1</span> || c == C - <span class="hljs-number">1</span>) {
                    <span class="hljs-keyword">if</span> (A[r][c] == <span class="hljs-string">'O'</span>) {
                        A[r][c] = VIS;
                        dfs(A, r, c);
                    }
                }
            }
        }
        <span class="hljs-comment">// Step 2. 把所有未标记过的点，修改为'X', 并将标记过的点修改为'O'</span>
        <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> r = <span class="hljs-number">0</span>; r &lt; R; r++) {
            <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> c = <span class="hljs-number">0</span>; c &lt; C; c++) {
                <span class="hljs-keyword">if</span> (A[r][c] != VIS) {
                    A[r][c] = <span class="hljs-string">'X'</span>;
                } <span class="hljs-keyword">else</span> {
                    A[r][c] = <span class="hljs-string">'O'</span>;
                }
            }
        }
    }
}
</code></pre>
<blockquote data-nodeid="6772">
<p data-nodeid="6773">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/130.%E8%A2%AB%E5%9B%B4%E7%BB%95%E7%9A%84%E5%8C%BA%E5%9F%9F.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7172">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/130.%E8%A2%AB%E5%9B%B4%E7%BB%95%E7%9A%84%E5%8C%BA%E5%9F%9F.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7176">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/130.%E8%A2%AB%E5%9B%B4%E7%BB%95%E7%9A%84%E5%8C%BA%E5%9F%9F.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7180">Python</a></p>
</blockquote>
<p data-nodeid="6774"><strong data-nodeid="7185">复杂度分析</strong>：每当一个点被 DFS 函数访问过之后，后面的 DFS 将不会再去访问它。因此整个程序的时间复杂度为 O(N)，其中 N 为点的总数。空间复杂度为递归的深度，最差情况下，递归深度可以达到 O(N) 级别（虽然深度不是 N，但是与 N 是线性函数，所以为 O(N)）。</p>
<p data-nodeid="6775">【<strong data-nodeid="7191">小结</strong>】我们总结一下这道题目，在经典的 DFS 模板的基础上，用 DFS 来求解边缘上的点，以及与之相连通的点。</p>
<p data-nodeid="6776">因此，我们就收获了 DFS 的一个应用：<strong data-nodeid="7201">求解连通域</strong>。你可以和我们之前学习“<a href="https://kaiwu.lagou.com/course/courseInfo.htm?courseId=685#/detail/pc?id=6696&amp;fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7199">第 07 讲｜并查集</a>”中求解连通域的方法进行比较。这里带你复习已学知识，同时巩固本讲介绍的新方法，我特地给你留了两道关于连通域的练习题，希望你不要偷懒，尝试求解一下。</p>
<p data-nodeid="6777"><strong data-nodeid="7214">练习题 1</strong>：给定一个黑白图像，其中白色像素用 '1' 表示，黑色像素用 '0' 表示。如果把上下左右相邻的白色像素看成一个连通域，给定一幅图（用矩阵表示），请问图中有几个连通域。</p>
<p data-nodeid="6778">输入：A = [['1', '1', '0'], ['0', '1', '0']]</p>
<p data-nodeid="6779">输出：1</p>
<p data-nodeid="6780"><strong data-nodeid="7254">解释</strong>：图中所有的 '1' 都是连在一起的，所以只有一个连通域。</p>
<blockquote data-nodeid="6781">
<p data-nodeid="6782">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/200.%E5%B2%9B%E5%B1%BF%E6%95%B0%E9%87%8F.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7258">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/200.%E5%B2%9B%E5%B1%BF%E6%95%B0%E9%87%8F.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7262">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/200.%E5%B2%9B%E5%B1%BF%E6%95%B0%E9%87%8F.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7266">Python</a></p>
</blockquote>
<p data-nodeid="6783"><strong data-nodeid="7278">练习题 2</strong>：给定一个图（不是图像）的矩阵，A[i][j] = 1 表示点 i 与点 j 相连，求这个图里面连通域的数目。</p>
<p data-nodeid="6784">输入：A = [[1,0,0],[0,1,0],[0,0,1]]</p>
<p data-nodeid="6785">输出：3</p>
<p data-nodeid="6786"><strong data-nodeid="7302">解释</strong>：[0, 1, 2] 三个点中，每个点都不与其他点相连，所以连通域有 3 个。</p>
<blockquote data-nodeid="6787">
<p data-nodeid="6788">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/547.%E7%9C%81%E4%BB%BD%E6%95%B0%E9%87%8F.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7306">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/547.%E7%9C%81%E4%BB%BD%E6%95%B0%E9%87%8F.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7310">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/547.%E7%9C%81%E4%BB%BD%E6%95%B0%E9%87%8F.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7314">Python</a></p>
</blockquote>
<h3 data-nodeid="6789">DFS 最优解问题</h3>
<p data-nodeid="6790"><strong data-nodeid="7320">除了求解连通域之外，还可以利用 DFS 来搜寻最优解</strong>。在一些面试题中，最终需要解决的是：</p>
<blockquote data-nodeid="6791">
<p data-nodeid="6792">如何从所有可行解中找到最优解？</p>
</blockquote>
<p data-nodeid="6793">首先，我们将这些问题放宽，就退化为我们在“<a href="https://kaiwu.lagou.com/course/courseInfo.htm?courseId=685#/detail/pc?id=6701&amp;fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7327">12 | 回溯：我把回溯总结成一个公式，回溯题一出就用它</a>”介绍过的“回溯问题”。因此，我们需要在回溯的基础上，从所有解中，找到最优解。</p>
<p data-nodeid="6794"><img src="https://s0.lgstatic.com/i/image6/M00/34/1B/Cgp9HWBwLMmAAEXKAADJJpVxkwY674.png" alt="Drawing 6.png" data-nodeid="7331"></p>
<h4 data-nodeid="6795">DFS 的模板 2</h4>
<p data-nodeid="6796">如果题目中需要求解最优解，那么，DFS 问题就退化为回溯问题，只不过满足约束的条件就变成：“从所有解中找到最优解”。这里我再给出 DFS 的第 2 个模板。</p>
<pre class="lang-java" data-nodeid="6797"><code data-language="java"><span class="hljs-function"><span class="hljs-keyword">void</span> <span class="hljs-title">dfs</span><span class="hljs-params">(A,
         <span class="hljs-keyword">int</span> start, <span class="hljs-comment">/* start 表示出发点*/</span>
         vis,  <span class="hljs-comment">/* 记录每个点是否已经访问 */</span>
         path, <span class="hljs-comment">/* 路径*/</span>
         answer<span class="hljs-comment">/*存放最优的答案*/</span>)</span> </span>{
  <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> N = A == <span class="hljs-keyword">null</span> ? <span class="hljs-number">0</span> : A.length;
 
  <span class="hljs-keyword">if</span> (状态满足要求) { <span class="hljs-comment">// 是更好的解吗？</span>
    <span class="hljs-keyword">if</span> (s better_than ans) {
        ans = s
    }
    <span class="hljs-keyword">return</span>;
  }

  <span class="hljs-keyword">for</span> next in {start点的后继点} {
    <span class="hljs-keyword">if</span> !vis[next] {
      path.append(next);
      vis[next] = <span class="hljs-keyword">true</span>;
      dfs(A, next, vis, path, answer);
      path.pop();
      vis[next] = <span class="hljs-keyword">false</span>;
    }
  }
}
</code></pre>
<p data-nodeid="6798">注意，调用方的代码，在调用的时候，需要注意这样调用：</p>
<pre class="lang-java te-preview-highlight" data-nodeid="28567"><code data-language="java">vis[begin] = <span class="hljs-keyword">true</span>;  <span class="hljs-comment">// ！注意设置初始点为已访问</span>
path.append(begin); <span class="hljs-comment">// ! 注意把begin放到path中。</span>
dfs(A, vis, path, ans)
<span class="hljs-keyword">return</span> ans;
</code></pre>







<h4 data-nodeid="6800">例 2：最短路径</h4>
<p data-nodeid="6801">【<strong data-nodeid="7341">题目</strong>】给定一个迷宫，其中 0 表示可能通过的地方，而 1 表示墙壁。请问，从左上角走到右下角的最短路径是什么样的？请依次输出行走的点坐标。</p>
<p data-nodeid="6802">输入：A = [[0, 1], [0, 0]]</p>
<p data-nodeid="6803">输出：ans = [[0, 0], [1, 0], [1,1]]</p>
<p data-nodeid="6804">解释：</p>
<p data-nodeid="6805"><img src="https://s0.lgstatic.com/i/image6/M01/34/1B/Cgp9HWBwLNKAT4oJAABZGKVGoYU587.png" alt="Drawing 7.png" data-nodeid="7369"></p>
<p data-nodeid="6806">【<strong data-nodeid="7383">分析</strong>】最优路径如上图所示，如果两点在图中可达，那么这两个点肯定是在同一个连通域中。不难得出，这个题一定可以利用 DFS 进行求解。但是注意问题要求的是找到最优解，因此，我们还需要从<strong data-nodeid="7384">所有解</strong>中找到<strong data-nodeid="7385">最优解</strong>。此时就需要使用我们刚学过的 DFS 的模板 2 了。</p>
<p data-nodeid="6807">【<strong data-nodeid="7391">代码</strong>】问题本身已经非常模板化了，因此，我们可以直接写代码如下：</p>
<pre class="lang-java" data-nodeid="6808"><code data-language="java"><span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">Node</span> </span>{
  <span class="hljs-keyword">public</span> <span class="hljs-keyword">int</span> r;
  <span class="hljs-keyword">public</span> <span class="hljs-keyword">int</span> c;
  <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-title">Node</span><span class="hljs-params">()</span> </span>{}
  <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-title">Node</span><span class="hljs-params">(<span class="hljs-keyword">int</span> a, <span class="hljs-keyword">int</span> b)</span> </span>{
    r = a;
    c = b;
  }
}
<span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">Solution</span> </span>{
  <span class="hljs-keyword">private</span> List&lt;Node&gt; shortPath = <span class="hljs-keyword">null</span>;
  <span class="hljs-keyword">private</span> <span class="hljs-keyword">int</span>[][] dir = {{<span class="hljs-number">0</span>, <span class="hljs-number">1</span>}, {<span class="hljs-number">0</span>, -<span class="hljs-number">1</span>}, {<span class="hljs-number">1</span>, <span class="hljs-number">0</span>}, {-<span class="hljs-number">1</span>, <span class="hljs-number">0</span>}};
  <span class="hljs-comment">// 深度clone一个java list.</span>
  <span class="hljs-function"><span class="hljs-keyword">private</span> List&lt;Node&gt; <span class="hljs-title">Clone</span><span class="hljs-params">(List&lt;Node&gt; a)</span> </span>{
    List&lt;Node&gt; ans = <span class="hljs-keyword">new</span> ArrayList&lt;Node&gt;();
    <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> i = <span class="hljs-number">0</span>; i &lt; a.size(); i++) {
      Node x = a.get(i);
      ans.add(<span class="hljs-keyword">new</span> Node(x.r, x.c));
    }
    <span class="hljs-keyword">return</span> ans;
  }
  <span class="hljs-comment">/**
   * <span class="hljs-doctag">@param</span> A     迷宫图
   * <span class="hljs-doctag">@param</span> vis   访问记录
   * <span class="hljs-doctag">@param</span> r     出发点(r, c)
   * <span class="hljs-doctag">@param</span> c
   * <span class="hljs-doctag">@param</span> tmp   走到r,c的路径
   */</span>
  <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">void</span> <span class="hljs-title">dfs</span><span class="hljs-params">(<span class="hljs-keyword">int</span>[][] A, <span class="hljs-keyword">boolean</span>[][] vis, <span class="hljs-keyword">int</span> r, <span class="hljs-keyword">int</span> c, List&lt;Node&gt; tmp)</span> </span>{
    <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> R = A.length;
    <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> C = A[<span class="hljs-number">0</span>].length;
    <span class="hljs-comment">// 如果已经走到终点</span>
    <span class="hljs-keyword">if</span> (r == R - <span class="hljs-number">1</span> &amp;&amp; c == C - <span class="hljs-number">1</span>) {
      <span class="hljs-keyword">if</span> (shortPath == <span class="hljs-keyword">null</span> || shortPath.size() &gt; tmp.size()) {
        shortPath = Clone(tmp);
      }
      <span class="hljs-keyword">return</span>;
    }
    <span class="hljs-comment">// 接下来看当前出发点的四个选择</span>
    <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> d = <span class="hljs-number">0</span>; d &lt; <span class="hljs-number">4</span>; d++) {
      <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> nr = r + dir[d][<span class="hljs-number">0</span>];
      <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> nc = c + dir[d][<span class="hljs-number">1</span>];
      <span class="hljs-comment">// 如果是越界的</span>
      <span class="hljs-keyword">if</span> (nr &lt; <span class="hljs-number">0</span> || nr &gt;= R || nc &lt; <span class="hljs-number">0</span> || nc &gt;= C) {
        <span class="hljs-keyword">continue</span>;
      }
      <span class="hljs-comment">// 如果是不能访问的</span>
      <span class="hljs-comment">// 或者说已经访问过了</span>
      <span class="hljs-keyword">if</span> (A[nr][nc] == <span class="hljs-number">1</span> || vis[nr][nc] == <span class="hljs-keyword">true</span>) {
        <span class="hljs-keyword">continue</span>;
      }
      vis[nr][nc] = <span class="hljs-keyword">true</span>;
      tmp.add(<span class="hljs-keyword">new</span> Node(nr, nc));
      dfs(A, vis, nr, nc, tmp);
      vis[nr][nc] = <span class="hljs-keyword">false</span>;
      tmp.remove(tmp.size()-<span class="hljs-number">1</span>);
    }
  }
  <span class="hljs-comment">/**
   * <span class="hljs-doctag">@param</span> A     的迷宫图
   * <span class="hljs-doctag">@return</span>      路径的长度，所有的路径会存放在ans
   */</span>
  <span class="hljs-function"><span class="hljs-keyword">public</span> List&lt;Node&gt; <span class="hljs-title">findMinPath</span><span class="hljs-params">(<span class="hljs-keyword">int</span>[][] A)</span> </span>{
    List&lt;Node&gt; ans = <span class="hljs-keyword">null</span>;
    <span class="hljs-keyword">if</span> (A == <span class="hljs-keyword">null</span> || A[<span class="hljs-number">0</span>].length == <span class="hljs-number">0</span>) {
      <span class="hljs-keyword">return</span> ans;
    }
    <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> R = A.length;
    <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> C = A[<span class="hljs-number">0</span>].length;
    <span class="hljs-keyword">boolean</span>[][] vis = <span class="hljs-keyword">new</span> <span class="hljs-keyword">boolean</span>[R][C];
    <span class="hljs-comment">// 路径最长为遍历所有的点</span>
    List&lt;Node&gt; tmp = <span class="hljs-keyword">new</span> ArrayList&lt;Node&gt;();
    <span class="hljs-comment">// 出发点[0, 0]</span>
    tmp.add(<span class="hljs-keyword">new</span> Node(<span class="hljs-number">0</span>, <span class="hljs-number">0</span>));
    vis[<span class="hljs-number">0</span>][<span class="hljs-number">0</span>] = <span class="hljs-keyword">true</span>;
    dfs(A, vis, <span class="hljs-number">0</span>, <span class="hljs-number">0</span>, tmp);
    tmp.remove(tmp.size() - <span class="hljs-number">1</span>);
    vis[<span class="hljs-number">0</span>][<span class="hljs-number">0</span>] = <span class="hljs-keyword">false</span>;
    <span class="hljs-keyword">return</span> shortPath;
  }
}
</code></pre>
<blockquote data-nodeid="6809">
<p data-nodeid="6810">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/P3984.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7395">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/P3984.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7399">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/P3984.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7403">Python</a></p>
</blockquote>
<p data-nodeid="6811"><strong data-nodeid="7410">复杂度分析</strong>：在最差情况下，一个 N x N 的图中，如果没有任何墙，那么所有的行走路径就是一个组合问题，这里可以简单归为 O(N!)，空间复杂度为 O(N)。</p>
<p data-nodeid="6812">【<strong data-nodeid="7420">小结</strong>】在这个简单的题目中，我们尝试使用 DFS + 回溯的思路来求解最优解的问题。有时候，这种一个一个遍历所有解，然后再从里面找到最优解的算法，也被叫作<strong data-nodeid="7421">暴力搜索</strong>。</p>
<p data-nodeid="6813">暴力搜索本质上与回溯的复杂度非常接近。因此，在可能的情况下，我们要尽可能地进行剪枝。所谓<strong data-nodeid="7427">剪枝</strong>，就是通过一些信息，提前判断出当前这条求解路径不可能是最优解，此时就应该及时放弃这条路径。</p>
<p data-nodeid="6814">这里我给出<strong data-nodeid="7433">剪枝 1</strong>：比如，在暴力搜索的时候，我们已经遍历了很多条路径，并且更新了 ans 的情况下。如果发现，当前路径的长度已经 &gt;= ans.size()，那么当前解肯定不能成为最优解，所以我们应该迅速返回，不要再继续寻找下去了。</p>
<p data-nodeid="6815">经过上述分析，代码可以更新如下（代码其他部分仍然一样）：</p>
<pre class="lang-java" data-nodeid="6816"><code data-language="java">  <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">void</span> <span class="hljs-title">dfs</span><span class="hljs-params">()</span> </span>{
    <span class="hljs-comment">// ... </span>
    <span class="hljs-comment">// 如果已经走到终点</span>
    <span class="hljs-keyword">if</span> (r == R - <span class="hljs-number">1</span> &amp;&amp; c == C - <span class="hljs-number">1</span>) {
      <span class="hljs-keyword">if</span> (shortPath == <span class="hljs-keyword">null</span> || shortPath.size() &gt; tmp.size()) {
        shortPath = Clone(tmp);
      }
      <span class="hljs-keyword">return</span>;
    }
    <span class="hljs-comment">// 剪枝1</span>
    <span class="hljs-keyword">if</span> (shortPath != <span class="hljs-keyword">null</span> &amp;&amp; tmp.size() &gt;= shortPath.size()) <span class="hljs-keyword">return</span>;
    <span class="hljs-comment">// 接下来看当前出发点的四个选择</span>
    <span class="hljs-comment">// ...</span>
}
</code></pre>
<p data-nodeid="6817">另外，我们还可以进行如下<strong data-nodeid="7444">剪枝 2</strong>：虽然我们要找出到<strong data-nodeid="7445">终点</strong>的最短路径，在这个过程中，可以把能走到每个位置的最少步数的情况都记录下来，当发现走到的位置的步数已经很大的时候，就可以直接返回。</p>
<p data-nodeid="6818">经过上述分析，代码可以优化如下：</p>
<pre class="lang-java" data-nodeid="6819"><code data-language="java"><span class="hljs-comment">// 初始化</span>
    <span class="hljs-comment">// 记录每个点的从出发点走的最小的步数，一开始为 R * C</span>
    <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> r = <span class="hljs-number">0</span>; r &lt; R; r++) {
      <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> c = <span class="hljs-number">0</span>; c &lt; C; c++) {
        step[r][c] = R * C + <span class="hljs-number">1</span>;
      }
    }
<span class="hljs-comment">// dfs()</span>
<span class="hljs-function"><span class="hljs-keyword">void</span> <span class="hljs-title">dfs</span><span class="hljs-params">()</span> </span>{
    <span class="hljs-comment">// 如果已经走到终点</span>
    <span class="hljs-comment">// ....</span>
    <span class="hljs-comment">// 剪枝1</span>
    <span class="hljs-keyword">if</span> (shortPath != <span class="hljs-keyword">null</span> &amp;&amp; tmp.size() &gt;= shortPath.size()) <span class="hljs-keyword">return</span>;

    <span class="hljs-comment">// 剪枝2</span>
    <span class="hljs-comment">// 如果发现走到step[r][c]比以前用了更多的步数，那么直接返回</span>
    <span class="hljs-keyword">if</span> (tmp.size() - <span class="hljs-number">1</span> &gt; step[r][c]) {
      <span class="hljs-keyword">return</span>;
    }
    step[r][c] = tmp.size() - <span class="hljs-number">1</span>;
    <span class="hljs-comment">// 接下来看当前出发点的四个选择</span>
    <span class="hljs-comment">// ... </span>
}
</code></pre>
<blockquote data-nodeid="6820">
<p data-nodeid="6821">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/P3984.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7450">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/P3984.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7454">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/P3984.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7458">Python</a></p>
</blockquote>
<p data-nodeid="6822">下面我们再看一个经典的国际象棋“皇后问题”。你可以通过下面这个练习题想一想，如何有效地进行剪枝吗？</p>
<p data-nodeid="6823"><strong data-nodeid="7464">练习题 3</strong>：给定一个 n x n 的棋盘，里面要放置 n 个皇后。使它们不能相互攻击。</p>
<p data-nodeid="6824">输入：n = 4</p>
<p data-nodeid="6825">输出：</p>
<p data-nodeid="6826">[</p>
<p data-nodeid="6827">[".Q..", // 解法 1</p>
<p data-nodeid="6828">"...Q",</p>
<p data-nodeid="6829">"Q...",</p>
<p data-nodeid="6830">"..Q."],</p>
<p data-nodeid="6831">["..Q.", // 解法 2</p>
<p data-nodeid="6832">"Q...",</p>
<p data-nodeid="6833">"...Q",</p>
<p data-nodeid="6834">".Q.."]</p>
<p data-nodeid="6835">]</p>
<p data-nodeid="6836">解释：当棋盘为 4 x 4 的时候，只有这两种解。</p>
<blockquote data-nodeid="6837">
<p data-nodeid="6838">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/%E5%85%AB%E7%9A%87%E5%90%8E.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7508">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/%E5%85%AB%E7%9A%87%E5%90%8E.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7512">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/%E5%85%AB%E7%9A%87%E5%90%8E.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7516">Python</a></p>
</blockquote>
<p data-nodeid="6839"><strong data-nodeid="7521">练习题 4</strong>：给定一个字符串，需要把这个字符串切分为很多子串，还需满足：每个子串都是回文串。返回所有的切分方式。</p>
<p data-nodeid="6840">输入：s = "aab"</p>
<p data-nodeid="6841">输出: ans = ['a', 'a', 'b'], ['aa', 'b']</p>
<blockquote data-nodeid="6842">
<p data-nodeid="6843">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/131.%E5%88%86%E5%89%B2%E5%9B%9E%E6%96%87%E4%B8%B2.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7553">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/131.%E5%88%86%E5%89%B2%E5%9B%9E%E6%96%87%E4%B8%B2.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7557">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/131.%E5%88%86%E5%89%B2%E5%9B%9E%E6%96%87%E4%B8%B2.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7561">Python</a></p>
</blockquote>
<h3 data-nodeid="6844">DFS 记忆化搜索</h3>
<p data-nodeid="6845">关于记忆化搜索，依然从一个简单的例子讲起：斐波那契数列。我们都知道这个数列的通项公式为：</p>
<blockquote data-nodeid="6846">
<p data-nodeid="6847">F(0) = 0, F(1) = 1, F[n] = F[n-1] + F[n-2]</p>
</blockquote>
<p data-nodeid="6848">现在要写一个函数求 F(x)。直接根据公式，可以得到递归代码如下（当然，我们也可以认为 DFS 是一种递归）：</p>
<pre class="lang-java" data-nodeid="6849"><code data-language="java"><span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">Solution</span> </span>{
    <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">int</span> <span class="hljs-title">fib</span><span class="hljs-params">(<span class="hljs-keyword">int</span> n)</span> </span>{
        <span class="hljs-keyword">return</span> n &lt;= <span class="hljs-number">1</span> ? n : fib(n-<span class="hljs-number">1</span>) + fib(n-<span class="hljs-number">2</span>);
    }
}
</code></pre>
<p data-nodeid="6850">但是这个算法存在<strong data-nodeid="7582">重复计算</strong>，导致复杂度极高。比如，如下图所示，我们发现 fib(5) 实际上是会被重复计算的。</p>
<p data-nodeid="6851"><img src="https://s0.lgstatic.com/i/image6/M01/34/23/CioPOWBwLOWAcfi0AABecQ3YNpQ910.png" alt="Drawing 8.png" data-nodeid="7585"></p>
<p data-nodeid="6852">为了减少这种重复计算，可以有两种办法：</p>
<ul data-nodeid="6853">
<li data-nodeid="6854">
<p data-nodeid="6855">把计算的结果存下来，后面遇到的时候，就直接返回；</p>
</li>
<li data-nodeid="6856">
<p data-nodeid="6857">使用动态规划。</p>
</li>
</ul>
<p data-nodeid="6858">在这里我们采用的方式是把计算的结果存下来。那么代码可以更新如下：</p>
<pre class="lang-java" data-nodeid="6859"><code data-language="java"><span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">Solution</span> </span>{
    <span class="hljs-keyword">int</span>[] mem = <span class="hljs-keyword">new</span> <span class="hljs-keyword">int</span>[<span class="hljs-number">100</span>];
    <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">int</span> <span class="hljs-title">fib</span><span class="hljs-params">(<span class="hljs-keyword">int</span> n)</span> </span>{
        <span class="hljs-keyword">if</span> (n &lt;= <span class="hljs-number">1</span>) {
            <span class="hljs-keyword">return</span> n;
        }
        <span class="hljs-keyword">if</span> (mem[n] &gt; <span class="hljs-number">0</span>) {
            <span class="hljs-keyword">return</span> mem[n];
        }
        <span class="hljs-keyword">return</span> mem[n] = fib(n-<span class="hljs-number">1</span>) + fib(n-<span class="hljs-number">2</span>);
    }
}
</code></pre>
<p data-nodeid="6860">采用“把计算结果存下来”的方法，思路清晰，比较容易想到，代码也比较容易实现。因此，当你遇到有的动态规划的题目无法打开思路的时候，不妨尝试采用这种思路。</p>
<h4 data-nodeid="6861">例 3：整数拆分</h4>
<p data-nodeid="6862">【<strong data-nodeid="7597">题目</strong>】给定一个数组，表示钱的面额，每种面额，你都有无穷多张钱。再给定一个整数 T，你需要用最少的钞票来表示这个整数。无法表示的时候，输出 -1。</p>
<p data-nodeid="6863">输入：A = [1, 2], T = 3</p>
<p data-nodeid="6864">输出：2</p>
<p data-nodeid="6865">解释：只需要1 + 2 = 3，所以最少你需要 2 张钞票。</p>
<p data-nodeid="6866">【<strong data-nodeid="7610">分析</strong>】首先，我们可以只考虑 DFS 递归的情况，代码如下：</p>
<pre class="lang-java" data-nodeid="6867"><code data-language="java"><span class="hljs-function"><span class="hljs-keyword">int</span> <span class="hljs-title">dfs</span><span class="hljs-params">(<span class="hljs-keyword">int</span> []A, <span class="hljs-keyword">int</span> T)</span> </span>{ <span class="hljs-comment">// 在调用dfs的程序里面处理-1的问题</span>
  <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> x: A)
    <span class="hljs-keyword">if</span> (T == x) <span class="hljs-keyword">return</span> <span class="hljs-number">1</span>;
  <span class="hljs-keyword">int</span> ans = INF;
  <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> x: A) {
    <span class="hljs-keyword">if</span> (x &lt;= T) ans = min(ans, dfs(A,T-x) + <span class="hljs-number">1</span>);
  }
  <span class="hljs-keyword">return</span> ans;
}
</code></pre>
<p data-nodeid="6868">在给定 A = [1, 2]，T= 5 情况下，那么伪代码展开如下：</p>
<p data-nodeid="6869"><img src="https://s0.lgstatic.com/i/image6/M01/34/23/CioPOWBwLO2AJ8fuAACFHV631AQ678.png" alt="Drawing 9.png" data-nodeid="7618"></p>
<p data-nodeid="6870">我们可以发现，在不断地求解的过程，总是有很多数会被重复地计算。因此，很容易想到，把一些中间的结果存下来，以便后面使用。</p>
<p data-nodeid="6871"><strong data-nodeid="7624">边界</strong>：这个题的思路本身不是特别难。但是在写代码的时候，要考虑到各种特殊情况，比如：</p>
<ul data-nodeid="6872">
<li data-nodeid="6873">
<p data-nodeid="6874">T 小于等于 0</p>
</li>
<li data-nodeid="6875">
<p data-nodeid="6876">DFS 返回值的设计</p>
</li>
</ul>
<p data-nodeid="6877">【<strong data-nodeid="7632">代码</strong>】根据上面的分析，我们就可以写出如下代码了：</p>
<pre class="lang-java" data-nodeid="6878"><code data-language="java"><span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">Solution</span> </span>{
    <span class="hljs-keyword">private</span> <span class="hljs-keyword">int</span> INF = Integer.MAX_VALUE &gt;&gt; <span class="hljs-number">2</span>;
    <span class="hljs-keyword">private</span> Set&lt;Integer&gt; has = <span class="hljs-keyword">new</span> HashSet&lt;&gt;();
    <span class="hljs-keyword">private</span> Map&lt;Integer, Integer&gt; H = <span class="hljs-keyword">new</span> HashMap&lt;&gt;();
    <span class="hljs-function"><span class="hljs-keyword">private</span> <span class="hljs-keyword">void</span> <span class="hljs-title">Build</span><span class="hljs-params">(<span class="hljs-keyword">int</span>[] A)</span> </span>{
        <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> x : A) {
            has.add(x);
            H.put(x, <span class="hljs-number">1</span>);
        }
    }
    <span class="hljs-function"><span class="hljs-keyword">private</span> <span class="hljs-keyword">int</span> <span class="hljs-title">dfs</span><span class="hljs-params">(<span class="hljs-keyword">int</span>[] A, <span class="hljs-keyword">int</span> T)</span> </span>{
        <span class="hljs-keyword">if</span> (T &lt; <span class="hljs-number">0</span>) {
            <span class="hljs-keyword">return</span> INF;
        }
        <span class="hljs-keyword">if</span> (H.containsKey(T)) {
            <span class="hljs-keyword">return</span> H.get(T);
        }
        <span class="hljs-keyword">int</span> ans = INF;
        <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> x : A) {
            ans = Math.min(ans, dfs(A, T - x) + <span class="hljs-number">1</span>);
        }
        H.put(T, ans);
        <span class="hljs-keyword">return</span> ans;
    }
    <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">int</span> <span class="hljs-title">coinChange</span><span class="hljs-params">(<span class="hljs-keyword">int</span>[] A, <span class="hljs-keyword">int</span> T)</span> </span>{
        <span class="hljs-keyword">if</span> (T &lt; <span class="hljs-number">0</span>)
            <span class="hljs-keyword">return</span> -<span class="hljs-number">1</span>;
        <span class="hljs-keyword">if</span> (T == <span class="hljs-number">0</span>)
            <span class="hljs-keyword">return</span> <span class="hljs-number">0</span>;
        Build(A);
        <span class="hljs-keyword">int</span> ans = dfs(A, T);
        <span class="hljs-keyword">return</span> ans &gt;= INF ? -<span class="hljs-number">1</span> : ans;
    }
}
</code></pre>
<blockquote data-nodeid="6879">
<p data-nodeid="6880">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/322.%E9%9B%B6%E9%92%B1%E5%85%91%E6%8D%A2.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7636">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/322.%E9%9B%B6%E9%92%B1%E5%85%91%E6%8D%A2.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7640">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/322.%E9%9B%B6%E9%92%B1%E5%85%91%E6%8D%A2.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7644">Python</a></p>
</blockquote>
<p data-nodeid="6881"><strong data-nodeid="7649">复杂度分析</strong>：当给定的数为 T 时，最大递归深度为 T，每次递归需要依次遍历数组 A 的每个元素。因此，时间复杂度为 O(TN)，其中 N 为数组中元素的个数，空间复杂度为 O(T)。</p>
<p data-nodeid="6882">【<strong data-nodeid="7655">小结</strong>】在这里，每次搜索的时候，都要尽可能把相应的结果记录下来。不过在处理的细节上，有以下几点需要注意：</p>
<ul data-nodeid="6883">
<li data-nodeid="6884">
<p data-nodeid="6885">优先处理容易返回的路径，比如 T 小于 0，T 等于 0；</p>
</li>
<li data-nodeid="6886">
<p data-nodeid="6887">把不能求解的答案也进行了标记；</p>
</li>
<li data-nodeid="6888">
<p data-nodeid="6889">DFS 的返回值设置为 INF，在调用方再根据 DFS 的返回值决定是否返回 -1。</p>
</li>
</ul>
<p data-nodeid="6890"><strong data-nodeid="7663">练习题 5</strong>：给定一个三角形的整数排列，返回从上往下的路径的最小和。</p>
<p data-nodeid="6891">输入：triangle = [[2],[3,4],[6,5,7],[4,1,8,3]]</p>
<p data-nodeid="6892">输出：11</p>
<p data-nodeid="6893">请参见如下简图：</p>
<p data-nodeid="6894"><img src="https://s0.lgstatic.com/i/image6/M01/34/1B/Cgp9HWBwLPeAOH86AAAlXdhkCDc684.png" alt="Drawing 10.png" data-nodeid="7686"></p>
<p data-nodeid="6895">自顶向下的最小路径和为 11（即 2 + 3 + 5 + 1 = 11）</p>
<blockquote data-nodeid="6896">
<p data-nodeid="6897">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/120.%E4%B8%89%E8%A7%92%E5%BD%A2%E6%9C%80%E5%B0%8F%E8%B7%AF%E5%BE%84%E5%92%8C.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7691">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/120.%E4%B8%89%E8%A7%92%E5%BD%A2%E6%9C%80%E5%B0%8F%E8%B7%AF%E5%BE%84%E5%92%8C.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7695">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/120.%E4%B8%89%E8%A7%92%E5%BD%A2%E6%9C%80%E5%B0%8F%E8%B7%AF%E5%BE%84%E5%92%8C.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7699">Python</a></p>
</blockquote>
<p data-nodeid="6898"><strong data-nodeid="7704">记忆化搜索是动态规划的基础。如果你发现一些题目考察的是动态规划，但却不容易求解的时候，可以尝试使用记忆化搜索来进行破解</strong>。</p>
<h3 data-nodeid="6899">BFS 概述</h3>
<p data-nodeid="6900">DFS 可以帮助我们找到最优解。不过在搜索的时候，若想知道一些关于“最近/最快/最少”之类问题的答案，往往采用 BFS 更加适合。</p>
<p data-nodeid="6901">那么，什么是 BFS？搜索时，BFS 与 DFS 又有什么不同？我们可以利用下图表示：</p>
<p data-nodeid="6902"><img src="https://s0.lgstatic.com/i/image6/M01/34/1B/Cgp9HWBwLQCALyAGAAJmqIpaing759.gif" alt="2.gif" data-nodeid="7710"></p>
<p data-nodeid="6903">实际上，我们在“<a href="https://kaiwu.lagou.com/course/courseInfo.htm?courseId=685#/detail/pc?id=6691&amp;fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7716">02 | 队列：FIFO 队列与单调队列的深挖与扩展</a>”介绍队列时，就已经讲过了 BFS，并且介绍了 BFS 的两种方法与模板。为了方便你复习，将新知识与旧知识联系起来，我把“<a href="https://kaiwu.lagou.com/course/courseInfo.htm?courseId=685#/detail/pc?id=6691&amp;fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7720">第 02 讲</a>”例 1 中介绍的两种方法的代码链接放在这里，你可以再次动手敲一敲。</p>
<blockquote data-nodeid="6904">
<p data-nodeid="6905">二叉树层次遍历解法 1 代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/01.TreeLevelOrder.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7725">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/01.TreeLevelOrder.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7729">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/01.TreeLevelOrder.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7733">Python</a><br>
二叉树层次遍历解法 2 代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/01.2.TreeLevelOrder.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7738">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/01.2.TreeLevelOrder.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7742">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/01.2.TreeLevelOrder.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7746">Python</a></p>
</blockquote>
<p data-nodeid="6906">通过把“<a href="https://kaiwu.lagou.com/course/courseInfo.htm?courseId=685#/detail/pc?id=6691&amp;fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7750">第 02 讲</a>”的例 1 进行一个归纳，我整理了较为通用的 BFS 的代码模板供你面试时使用，如下所示：</p>
<pre class="lang-java" data-nodeid="6907"><code data-language="java">bfs(s) { <span class="hljs-comment">// s表示出发点</span>
  q = <span class="hljs-keyword">new</span> queue()
  q.push(s), visited[s] = <span class="hljs-keyword">true</span> <span class="hljs-comment">// 标记s为已访问</span>
  <span class="hljs-keyword">while</span> (!q.empty()) {
    u = q.pop() <span class="hljs-comment">// 拿到当前结点 </span>
    <span class="hljs-function"><span class="hljs-keyword">for</span> next in <span class="hljs-title">getNext</span><span class="hljs-params">(u)</span> </span>{ <span class="hljs-comment">// 拿到u的后继next</span>
      <span class="hljs-keyword">if</span> (!visited[next]) { <span class="hljs-comment">// 如果next还没有访问过 </span>
        q.push(next)
        visited[next] = <span class="hljs-keyword">true</span>
      }
    }
  }
}
</code></pre>
<p data-nodeid="6908">接下来，我们看一些可以利用 BFS 解决的面试的题目。</p>
<h4 data-nodeid="6909">例 4：最短路径</h4>
<p data-nodeid="6910">【<strong data-nodeid="7759">题目</strong>】给定一个矩阵，矩阵中只有 0，1，其中 0 表示可以通行的路径，1 表示墙，请返回从左上角走到右下角的最短路径。（注意：这个题里面有 8 个方向可以走，也就是可以斜着走），如果不存在这样的路径，那么返回 -1。</p>
<p data-nodeid="6911">输入：grid = [[0,0,0],[1,1,0],[1,1,0]]</p>
<p data-nodeid="6912">输出：4</p>
<p data-nodeid="6913">解释：行走路线如下图所示，只需要走 4 个格子。（注意有个位置走了斜线）。</p>
<p data-nodeid="6914"><img src="https://s0.lgstatic.com/i/image6/M01/34/24/CioPOWBwLQuAQTCsAACOuVJFPZQ600.png" alt="Drawing 12.png" data-nodeid="7778"></p>
<p data-nodeid="6915">【<strong data-nodeid="7788">分析</strong>】用 BFS 求解问题的时候：<strong data-nodeid="7789">只需要注意一个点的选择</strong>。</p>
<p data-nodeid="6916">对于矩阵中的某个点，由于可以斜线走，那么一共有 8 个方向，如下图所示：</p>
<p data-nodeid="6917"><img src="https://s0.lgstatic.com/i/image6/M01/34/24/CioPOWBwLRGAbDsbAABwTsMVzOo426.png" alt="Drawing 13.png" data-nodeid="7793"></p>
<p data-nodeid="6918">那么找下一个点的时候，可以这样写代码：</p>
<pre class="lang-java" data-nodeid="6919"><code data-language="java"><span class="hljs-keyword">int</span>[][] dir = {
    {<span class="hljs-number">0</span>, <span class="hljs-number">1</span>}  <span class="hljs-comment">/*右*/</span>,
    {<span class="hljs-number">0</span>, -<span class="hljs-number">1</span>} <span class="hljs-comment">/*左*/</span>,
    {<span class="hljs-number">1</span>, <span class="hljs-number">0</span>}  <span class="hljs-comment">/*下*/</span>,
    {-<span class="hljs-number">1</span>, <span class="hljs-number">0</span>} <span class="hljs-comment">/*上*/</span>,
    {-<span class="hljs-number">1</span>,-<span class="hljs-number">1</span>} <span class="hljs-comment">/*左上*/</span>,
    {-<span class="hljs-number">1</span>,<span class="hljs-number">1</span>}  <span class="hljs-comment">/*右上*/</span>,
    {<span class="hljs-number">1</span>,-<span class="hljs-number">1</span>}  <span class="hljs-comment">/*左下*/</span>,
    {<span class="hljs-number">1</span>,<span class="hljs-number">1</span>}   <span class="hljs-comment">/*右下*/</span>,
};
<span class="hljs-keyword">for</span>(<span class="hljs-keyword">int</span> d = <span class="hljs-number">0</span>;d&lt;<span class="hljs-number">8</span>;d++) {
    <span class="hljs-keyword">int</span> nr = r + dir[d][<span class="hljs-number">0</span>];
    <span class="hljs-keyword">int</span> nc = c + dir[d][<span class="hljs-number">1</span>];
    <span class="hljs-keyword">if</span> (!(nr &lt; <span class="hljs-number">0</span> || nc &lt; <span class="hljs-number">0</span> || nr &gt;= R || nc &gt;= C)) {
      <span class="hljs-comment">// 处理点 (nr, nc)</span>
    }
}
</code></pre>
<p data-nodeid="6920">这就轻松解决获取下一个点的问题。此外，我们还需要把已经访问过的点进行标记，以防止重复访问。不过，这里可以采用原地标记的方式，直接将给定的数组里面的 0 改成 1，表示已经访问过了。</p>
<p data-nodeid="6921">【<strong data-nodeid="7801">代码</strong>】再根据前面给定的模板我们可以得到如下的代码：</p>
<pre class="lang-java" data-nodeid="6922"><code data-language="java"><span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">Solution</span> </span>{
    <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">int</span> <span class="hljs-title">shortestPathBinaryMatrix</span><span class="hljs-params">(<span class="hljs-keyword">int</span>[][] A)</span> </span>{
        <span class="hljs-keyword">int</span>[][] dir = {
            {<span class="hljs-number">0</span>, <span class="hljs-number">1</span>}  <span class="hljs-comment">/*右*/</span>,
            {<span class="hljs-number">0</span>, -<span class="hljs-number">1</span>} <span class="hljs-comment">/*左*/</span>,
            {<span class="hljs-number">1</span>, <span class="hljs-number">0</span>}  <span class="hljs-comment">/*下*/</span>,
            {-<span class="hljs-number">1</span>, <span class="hljs-number">0</span>} <span class="hljs-comment">/*上*/</span>,
            {-<span class="hljs-number">1</span>,-<span class="hljs-number">1</span>} <span class="hljs-comment">/*左上*/</span>,
            {-<span class="hljs-number">1</span>,<span class="hljs-number">1</span>}  <span class="hljs-comment">/*右上*/</span>,
            {<span class="hljs-number">1</span>,-<span class="hljs-number">1</span>}  <span class="hljs-comment">/*左下*/</span>,
            {<span class="hljs-number">1</span>,<span class="hljs-number">1</span>}   <span class="hljs-comment">/*右下*/</span>,
        };
        <span class="hljs-comment">// 拿到矩阵的Row, Col</span>
        <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> R = A == <span class="hljs-keyword">null</span> ? <span class="hljs-number">0</span> : A.length;
        <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> C = R &gt; <span class="hljs-number">0</span> ? (A[<span class="hljs-number">0</span>] == <span class="hljs-keyword">null</span> ? <span class="hljs-number">0</span> : A[<span class="hljs-number">0</span>].length) : <span class="hljs-number">0</span>;
        <span class="hljs-comment">// 首先处理特殊情况</span>
        <span class="hljs-comment">// 为空，或者只有一个格子</span>
        <span class="hljs-keyword">if</span> (R &lt;= <span class="hljs-number">1</span> || C &lt;= <span class="hljs-number">1</span>) {
            <span class="hljs-keyword">return</span> Math.min(R, C);
        }
        <span class="hljs-comment">// 首先处理起始点</span>
        <span class="hljs-comment">// 如果起始点或者说终点已经是1</span>
        <span class="hljs-comment">// 那么返回-1</span>
        <span class="hljs-keyword">if</span> (A[<span class="hljs-number">0</span>][<span class="hljs-number">0</span>] == <span class="hljs-number">1</span> || A[R - <span class="hljs-number">1</span>][C - <span class="hljs-number">1</span>] == <span class="hljs-number">1</span>) {
            <span class="hljs-keyword">return</span> -<span class="hljs-number">1</span>;
        }
        Queue&lt;<span class="hljs-keyword">int</span>[]&gt; Q = <span class="hljs-keyword">new</span> LinkedList&lt;&gt;();
        <span class="hljs-keyword">int</span>[] cur = <span class="hljs-keyword">new</span> <span class="hljs-keyword">int</span>[<span class="hljs-number">2</span>]; <span class="hljs-comment">// {0,0}</span>
        <span class="hljs-comment">// 将起始点 入队， 并且标记为已访问</span>
        Q.add(cur);
        A[cur[<span class="hljs-number">0</span>]][cur[<span class="hljs-number">1</span>]] = <span class="hljs-number">1</span>;
        <span class="hljs-comment">// 一开始就会占用一个格子</span>
        <span class="hljs-keyword">int</span> ans = <span class="hljs-number">0</span>;
        <span class="hljs-keyword">while</span> (!Q.isEmpty()) {
            ans++;
            <span class="hljs-comment">// 注意这里类似二叉树层次遍历的做法，取出qSize</span>
            <span class="hljs-comment">// 可以一层一层的遍历。</span>
            <span class="hljs-keyword">int</span> QSize = Q.size();
            <span class="hljs-keyword">while</span> (QSize-- &gt; <span class="hljs-number">0</span>) {
                cur = Q.remove();
                <span class="hljs-comment">// 如果已经走到了目的地</span>
                <span class="hljs-keyword">if</span> (cur[<span class="hljs-number">0</span>] == (R - <span class="hljs-number">1</span>) &amp;&amp; cur[<span class="hljs-number">1</span>] == (C - <span class="hljs-number">1</span>)) {
                    <span class="hljs-keyword">return</span> ans;
                }
                <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> d = <span class="hljs-number">0</span>; d &lt; <span class="hljs-number">8</span>; d++) {
                    <span class="hljs-keyword">int</span> nr = cur[<span class="hljs-number">0</span>] + dir[d][<span class="hljs-number">0</span>];
                    <span class="hljs-keyword">int</span> nc = cur[<span class="hljs-number">1</span>] + dir[d][<span class="hljs-number">1</span>];
                    <span class="hljs-keyword">if</span> (!(nr &lt; <span class="hljs-number">0</span> || nc &lt; <span class="hljs-number">0</span> || nr &gt;= R || nc &gt;= C)) {
                        <span class="hljs-keyword">if</span> (A[nr][nc] != <span class="hljs-number">1</span>) {
                            A[nr][nc] = <span class="hljs-number">1</span>;
                            Q.add(<span class="hljs-keyword">new</span> <span class="hljs-keyword">int</span>[] { nr, nc });
                        }
                    }
                }
            }
        }
        <span class="hljs-keyword">return</span> -<span class="hljs-number">1</span>;
    }
}
</code></pre>
<blockquote data-nodeid="6923">
<p data-nodeid="6924">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/1091.%E4%BA%8C%E8%BF%9B%E5%88%B6%E7%9F%A9%E9%98%B5%E4%B8%AD%E7%9A%84%E6%9C%80%E7%9F%AD%E8%B7%AF%E5%BE%84.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7805">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/1091.%E4%BA%8C%E8%BF%9B%E5%88%B6%E7%9F%A9%E9%98%B5%E4%B8%AD%E7%9A%84%E6%9C%80%E7%9F%AD%E8%B7%AF%E5%BE%84.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7809">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/1091.%E4%BA%8C%E8%BF%9B%E5%88%B6%E7%9F%A9%E9%98%B5%E4%B8%AD%E7%9A%84%E6%9C%80%E7%9F%AD%E8%B7%AF%E5%BE%84.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7813">Python</a></p>
</blockquote>
<p data-nodeid="6925"><strong data-nodeid="7818">复杂度分析</strong>：最差情况下，每个点都需要入队出队一次，这里我们使用的是 FIFO 队列，出队入队时间复杂度为 O(1)，如果有 N 个点，时间复杂度为 O(N)。最差情况下所有的点都在队列中，那么空间复杂度为 O(N)。</p>
<p data-nodeid="6926">【<strong data-nodeid="7824">小结</strong>】注意这个题与例 2 的区别在于：例 2 中，每次行走的时候只有 4 个方向，上下左右。而这道题目有 8 个方向可以行走。</p>
<p data-nodeid="6927">这里我们发现了“<strong data-nodeid="7830">最短</strong>”两个关键字，因此，决定使用 BFS 进行搜索。不过实际上，例 2 也可以使用 BFS 来搜索，而例 4 也可以使用 DFS 进行求解。</p>
<p data-nodeid="6928">接下来，我们看另外一类 BFS 可以求解的题目。</p>
<h4 data-nodeid="6929">例 5：最安全的路径</h4>
<p data-nodeid="6930">【<strong data-nodeid="7874">题目</strong>】在一个无向图上，给定点个数 n，编号从 [0~n]，再给定边的个数 m。其中每条边由x[i], y[i], w[i] 表示。x[i], y[i] 分别表示边上两点的编号而 w[i] 表示这边条的危险系数。现在我们想找到一条路径从 0~n，使得这条<strong data-nodeid="7875">路径上最大危险系数最小</strong>。（注意：不是路径和最小，而是路径上的最大值最小）。</p>
<p data-nodeid="6931">输入：n = 2, m = 2, x[] = [0, 1], y[] = [1,2], w[]=[1,2]</p>
<p data-nodeid="6932">输出：2</p>
<p data-nodeid="6933">解释：注意两条边的表示：边 1：(x[0]=0, y[0]=1, w[0]=1), 边 2：（x[1] = 1, y[1] =2, w[1]=2)。所以形成了下图：</p>
<p data-nodeid="6934"><img src="https://s0.lgstatic.com/i/image6/M01/34/1C/Cgp9HWBwLR6ABiN2AABX1UDDRPI404.png" alt="Drawing 14.png" data-nodeid="7925"></p>
<p data-nodeid="6935">形成的路径为 0 → 1 → 2，路径最大危险系数为 2，所以输出 2。</p>
<p data-nodeid="6936">注意：后面用 &lt;x, y, c&gt; 表示 x 到 y 这条边上的危险系数为 c。</p>
<p data-nodeid="6937">【<strong data-nodeid="7937">分析</strong>】当我们看到“最 X"这样的词语的时候，应该条件反射地想到用 BFS。</p>
<p data-nodeid="6938"><img src="https://s0.lgstatic.com/i/image6/M01/34/1C/Cgp9HWBwLSaAX_SNAAB80QBZWDQ335.png" alt="Drawing 15.png" data-nodeid="7940"></p>
<p data-nodeid="6939">不过，在用 BFS 的时候，我们需要先进行一个简单的模拟。</p>
<p data-nodeid="6940">第一轮的时候，如果我们还使用 FIFO 队列。那么有<strong data-nodeid="7949">走法 1</strong>：从 0 出发，走边 &lt;0, 2, 6&gt; 到达 2。</p>
<p data-nodeid="6941"><img src="https://s0.lgstatic.com/i/image6/M01/34/1C/Cgp9HWBwLSyAf36tAACQmcVkKzc136.png" alt="Drawing 16.png" data-nodeid="7952"></p>
<p data-nodeid="6942">但实际上，还有<strong data-nodeid="7965">走法 2</strong>：从结点 0 走到结点 1，再从结点 1 走到结点 2，路径为 [&lt;0,1,1&gt;, &lt;1,2,2&gt;]。</p>
<p data-nodeid="6943"><img src="https://s0.lgstatic.com/i/image6/M01/34/24/CioPOWBwLTSAWneeAACOornImaQ886.png" alt="Drawing 17.png" data-nodeid="7968"></p>
<p data-nodeid="6944">这种走法，危险系数仅为 2。</p>
<p data-nodeid="6945">如果我们在 BFS 的时候，先遍历到<strong data-nodeid="7979">走法 1</strong>，再遍历到<strong data-nodeid="7980">走法 2</strong>。此时，走到结点 2 的危险系数需要更新 2 次。</p>
<p data-nodeid="6946">那么，出现这种反复更新的情况的根本原因为：我们将更差劲的走法安排在了前面。</p>
<p data-nodeid="6947">那么，有没有什么办法可以把更好的走法安排在前面呢？这个时候，就需要使用我们“<a href="https://kaiwu.lagou.com/course/courseInfo.htm?courseId=685#/detail/pc?id=6692&amp;fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7987">03 | 优先级队列：堆与优先级队列，筛选最优元素</a>”学过的数据结构了：优先级队列。</p>
<p data-nodeid="6948">我们可以把优先级队列想象成一个袋子，每次从袋子里面拿东西的时候，总是从里面拿出优先级最高的结果。</p>
<p data-nodeid="6949">【<strong data-nodeid="7995">代码</strong>】基于这样的思路，可以写出代码如下：</p>
<pre class="lang-java" data-nodeid="6950"><code data-language="java"><span class="hljs-keyword">public</span> <span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">Solution</span> </span>{
  <span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">Node</span> </span>{
    <span class="hljs-keyword">public</span> <span class="hljs-keyword">int</span> node = <span class="hljs-number">0</span>;
    <span class="hljs-keyword">public</span> <span class="hljs-keyword">int</span> risk = <span class="hljs-number">0</span>;
    <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-title">Node</span><span class="hljs-params">()</span> </span>{
    }
    <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-title">Node</span><span class="hljs-params">(<span class="hljs-keyword">int</span> a, <span class="hljs-keyword">int</span> b)</span> </span>{
      node = a;
      risk = b;
    }
  }
  <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">int</span> <span class="hljs-title">getMinRiskValue</span><span class="hljs-params">(<span class="hljs-keyword">int</span> n, <span class="hljs-keyword">int</span> m,
                             <span class="hljs-keyword">int</span>[] x, <span class="hljs-keyword">int</span>[] y, <span class="hljs-keyword">int</span>[] w)</span> </span>{
    <span class="hljs-comment">// 构建图的表示</span>
    List&lt;Node&gt; G[] = <span class="hljs-keyword">new</span> ArrayList[n + <span class="hljs-number">1</span>];
    <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> i = <span class="hljs-number">0</span>; i &lt; n + <span class="hljs-number">1</span>; i++) {
      G[i] = <span class="hljs-keyword">new</span> ArrayList&lt;&gt;();
    }
    <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> i = <span class="hljs-number">0</span>; i &lt; m; i++) {
      <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> a = x[i], b = y[i], c = w[i];
      G[a].add(<span class="hljs-keyword">new</span> Node(b, c));
      G[b].add(<span class="hljs-keyword">new</span> Node(a, c));
    }
    <span class="hljs-keyword">int</span>[] risk = <span class="hljs-keyword">new</span> <span class="hljs-keyword">int</span>[n + <span class="hljs-number">1</span>];
    <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> i = <span class="hljs-number">0</span>; i &lt;= n; i++) {
      risk[i] = Integer.MAX_VALUE;
    }
    <span class="hljs-comment">// java小堆</span>
    Queue&lt;Integer&gt; Q = <span class="hljs-keyword">new</span> PriorityQueue&lt;&gt;(
                (v1, v2) -&gt; risk[v1] - risk[v2]);
    <span class="hljs-comment">// 把起始点入堆</span>
    Q.offer(<span class="hljs-number">0</span>);
    risk[<span class="hljs-number">0</span>] = <span class="hljs-number">0</span>;
    <span class="hljs-keyword">while</span> (!Q.isEmpty()) {
      <span class="hljs-keyword">int</span> cur = Q.poll();
      <span class="hljs-keyword">for</span> (Node next : G[cur]) {
        <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> back = next.node;
        <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> backRisk = Math.max(risk[cur], next.risk);
        <span class="hljs-keyword">if</span> (backRisk &lt; risk[back]) {
          risk[back] = backRisk;
          Q.offer(back);
        }
      }
    }
    <span class="hljs-keyword">return</span> risk[n];
  }
}
</code></pre>
<blockquote data-nodeid="6951">
<p data-nodeid="6952">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/783._Minimum_Risk_Path.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="7999">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/783._Minimum_Risk_Path.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8003">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/783._Minimum_Risk_Path.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8007">Python</a></p>
</blockquote>
<p data-nodeid="6953"><strong data-nodeid="8012">复杂度分析</strong>：最差情况下，一共有 N 个点，所有的结点都需要入队，出队一次。每次出入队的时间复杂度为 O(lgN)，所以整个算法的时间复杂度为 O(NlgN)。</p>
<p data-nodeid="6954">【<strong data-nodeid="8018">小结</strong>】通过这个题，我们可以发现：</p>
<ul data-nodeid="6955">
<li data-nodeid="6956">
<p data-nodeid="6957">路径之间，需要<strong data-nodeid="8024">优先处理</strong>的情况，直接用优先级队列替换 FIFO 队列；</p>
</li>
<li data-nodeid="6958">
<p data-nodeid="6959">有重复更新的情况，使用优先级队列。</p>
</li>
</ul>
<p data-nodeid="6960">为了练习这个技巧，我再给你留了一道练习题，请你尝试自己求解一下。</p>
<p data-nodeid="6961"><strong data-nodeid="8058">练习题 6</strong>：在一个 N x N 的坐标方格 grid 中，每一个方格的值 grid[i][j] 表示在位置 (i,j) 的平台高度。现在开始下雨了。当时间为 t 时，此时雨水导致水池中任意位置的水位为 t 。你可以从一个平台游向四周相邻的任意一个平台，但是前提是此时水位必须同时淹没这两个平台。假定你可以瞬间移动无限距离，也就是默认在方格内部游动是不耗时的。当然，在你游泳的时候你必须待在坐标方格里面。你从坐标方格的左上平台 (0，0) 出发。最少耗时多久你才能到达坐标方格的右下平台 (N-1, N-1)？</p>
<blockquote data-nodeid="6962">
<p data-nodeid="6963">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/778.%E6%B0%B4%E4%BD%8D%E4%B8%8A%E5%8D%87%E7%9A%84%E6%B3%B3%E6%B1%A0%E4%B8%AD%E6%B8%B8%E6%B3%B3.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8062">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/778.%E6%B0%B4%E4%BD%8D%E4%B8%8A%E5%8D%87%E7%9A%84%E6%B3%B3%E6%B1%A0%E4%B8%AD%E6%B8%B8%E6%B3%B3.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8066">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/778.%E6%B0%B4%E4%BD%8D%E4%B8%8A%E5%8D%87%E7%9A%84%E6%B3%B3%E6%B1%A0%E4%B8%AD%E6%B8%B8%E6%B3%B3.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8070">Python</a></p>
</blockquote>
<h3 data-nodeid="6964">总结</h3>
<p data-nodeid="6965">在本讲中，介绍了两种搜索：DFS 和 BFS。不过这里我们还没有讲遇到什么样的题目的时候，应该使用什么样的搜索？</p>
<p data-nodeid="6966">这需要你根据不同情况，结合今天所讲的内容综合分析。最后，我凭借一些自己积累的经验，带你总结一下 DFS 和 BFS 这两种搜索的区别，</p>
<ol data-nodeid="6967">
<li data-nodeid="6968">
<p data-nodeid="6969">如果要像回溯似的处理每一种可能性，那么用 DFS 更加方便，也更加节省内存。因为 BFS 相当于是会存储下所有的解，在某些时候，内存占用率会比较可观。</p>
</li>
<li data-nodeid="6970">
<p data-nodeid="6971">一些开放式搜索问题，使用 BFS 则更加方便，比如：在一个无边界的二维平面上，要从某个点 Start 出发，按照一定规则走到另外一个点 End，求最小路径。由于是开放式的边界，那么使用 DFS，会一直递归下去。</p>
</li>
<li data-nodeid="6972">
<p data-nodeid="6973">条件的选择具有优先级的时候，使用 BFS + 优先级队列更加方便。</p>
</li>
<li data-nodeid="6974">
<p data-nodeid="6975">一些类似动态规划的题目，使用 DFS + 记忆化搜索更加方便。</p>
</li>
</ol>
<p data-nodeid="6976">为了方便你复习，我将本讲的知识点总结如下：</p>
<p data-nodeid="6977"><img src="https://s0.lgstatic.com/i/image6/M01/34/24/CioPOWBwLT-ABq5WAADkE8e9C7Y414.png" alt="Drawing 18.png" data-nodeid="8081"></p>
<h3 data-nodeid="6978">思考题</h3>
<p data-nodeid="6979">最后我再给你留一个思考题。</p>
<p data-nodeid="6980">数字<code data-backticks="1" data-nodeid="8085">n</code>代表生成括号的对数，请你设计一个函数，用于能够生成所有可能的并且<strong data-nodeid="8091">有效的</strong>括号组合。</p>
<p data-nodeid="6981">输入：n = 3</p>
<p data-nodeid="6982">输出：["((()))","(()())","(())()","()(())","()()()"]</p>
<blockquote data-nodeid="6983">
<p data-nodeid="6984">DP 解法：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.DP/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8118">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.DP/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8122">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.DP/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8126">Python</a><br>
BFS 解法 1：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.%E4%B8%A4%E6%AE%B5%E5%87%BB/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8131">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.%E4%B8%A4%E6%AE%B5%E5%87%BB/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8135">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.%E4%B8%A4%E6%AE%B5%E5%87%BB/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8139">Python</a><br>
BFS 解法 2：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.%E9%98%9F%E5%88%97/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8144">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.%E9%98%9F%E5%88%97/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8148">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.%E9%98%9F%E5%88%97/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8152">Python</a><br>
DFS 解法：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.%E5%9B%9E%E6%BA%AF/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8157">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.%E5%9B%9E%E6%BA%AF/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8161">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.%E5%9B%9E%E6%BA%AF/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8165">Python</a></p>
</blockquote>
<p data-nodeid="6985">关于 DFS 和 BFS 我们就介绍到这里，后面我们将要学习“14 | DP：我是怎么治好“DP 头痛症”的？”。让我们继续前进。</p>
<h3 data-nodeid="6986">附：题目出处和代码汇总</h3>
<table data-nodeid="6988">
<thead data-nodeid="6989">
<tr data-nodeid="6990">
<th data-nodeid="6992">例 1：替换字母</th>
<th data-nodeid="6993"><a href="https://leetcode-cn.com/problems/surrounded-regions/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8173">测试平台</a></th>
<th data-nodeid="6994">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/130.%E8%A2%AB%E5%9B%B4%E7%BB%95%E7%9A%84%E5%8C%BA%E5%9F%9F.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8177">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/130.%E8%A2%AB%E5%9B%B4%E7%BB%95%E7%9A%84%E5%8C%BA%E5%9F%9F.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8181">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/130.%E8%A2%AB%E5%9B%B4%E7%BB%95%E7%9A%84%E5%8C%BA%E5%9F%9F.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8185">Python</a></th>
</tr>
</thead>
<tbody data-nodeid="6998">
<tr data-nodeid="6999">
<td data-nodeid="7000">练习题 1</td>
<td data-nodeid="7001"><a href="https://leetcode-cn.com/problems/number-of-islands/description/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8189">测试平台</a></td>
<td data-nodeid="7002">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/200.%E5%B2%9B%E5%B1%BF%E6%95%B0%E9%87%8F.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8193">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/200.%E5%B2%9B%E5%B1%BF%E6%95%B0%E9%87%8F.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8197">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/200.%E5%B2%9B%E5%B1%BF%E6%95%B0%E9%87%8F.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8201">Python</a></td>
</tr>
<tr data-nodeid="7003">
<td data-nodeid="7004">练习题 2</td>
<td data-nodeid="7005"><a href="https://leetcode-cn.com/problems/number-of-provinces/description/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8205">测试平台</a></td>
<td data-nodeid="7006">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/547.%E7%9C%81%E4%BB%BD%E6%95%B0%E9%87%8F.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8209">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/547.%E7%9C%81%E4%BB%BD%E6%95%B0%E9%87%8F.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8213">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/547.%E7%9C%81%E4%BB%BD%E6%95%B0%E9%87%8F.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8217">Python</a></td>
</tr>
<tr data-nodeid="7007">
<td data-nodeid="7008">例 2：最短路径</td>
<td data-nodeid="7009"><a href="http://poj.org/problem?id=3984&amp;fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8221">测试平台</a></td>
<td data-nodeid="7010">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/P3984.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8225">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/P3984.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8229">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/P3984.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8233">Python</a></td>
</tr>
<tr data-nodeid="7011">
<td data-nodeid="7012">练习题 3：n 皇后</td>
<td data-nodeid="7013"><a href="https://leetcode-cn.com/problems/eight-queens-lcci/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8237">测试平台</a></td>
<td data-nodeid="7014">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/%E5%85%AB%E7%9A%87%E5%90%8E.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8241">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/%E5%85%AB%E7%9A%87%E5%90%8E.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8245">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/%E5%85%AB%E7%9A%87%E5%90%8E.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8249">Python</a></td>
</tr>
<tr data-nodeid="7015">
<td data-nodeid="7016">练习题 4：分割回文串</td>
<td data-nodeid="7017"><a href="https://leetcode-cn.com/problems/palindrome-partitioning/description/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8253">测试平台</a></td>
<td data-nodeid="7018">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/131.%E5%88%86%E5%89%B2%E5%9B%9E%E6%96%87%E4%B8%B2.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8257">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/131.%E5%88%86%E5%89%B2%E5%9B%9E%E6%96%87%E4%B8%B2.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8261">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/131.%E5%88%86%E5%89%B2%E5%9B%9E%E6%96%87%E4%B8%B2.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8265">Python</a></td>
</tr>
<tr data-nodeid="7019">
<td data-nodeid="7020">例 3：整数拆分</td>
<td data-nodeid="7021"><a href="https://leetcode-cn.com/problems/coin-change/description/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8269">测试平台</a></td>
<td data-nodeid="7022">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/322.%E9%9B%B6%E9%92%B1%E5%85%91%E6%8D%A2.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8273">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/322.%E9%9B%B6%E9%92%B1%E5%85%91%E6%8D%A2.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8277">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/322.%E9%9B%B6%E9%92%B1%E5%85%91%E6%8D%A2.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8281">Python</a></td>
</tr>
<tr data-nodeid="7023">
<td data-nodeid="7024">练习题 5：最小路径和</td>
<td data-nodeid="7025"><a href="https://leetcode-cn.com/problems/triangle/description/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8285">测试平台</a></td>
<td data-nodeid="7026">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/120.%E4%B8%89%E8%A7%92%E5%BD%A2%E6%9C%80%E5%B0%8F%E8%B7%AF%E5%BE%84%E5%92%8C.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8289">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/120.%E4%B8%89%E8%A7%92%E5%BD%A2%E6%9C%80%E5%B0%8F%E8%B7%AF%E5%BE%84%E5%92%8C.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8293">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/120.%E4%B8%89%E8%A7%92%E5%BD%A2%E6%9C%80%E5%B0%8F%E8%B7%AF%E5%BE%84%E5%92%8C.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8297">Pytho</a></td>
</tr>
<tr data-nodeid="7027">
<td data-nodeid="7028">例 4：最短路径</td>
<td data-nodeid="7029"><a href="https://leetcode-cn.com/problems/shortest-path-in-binary-matrix/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8301">测试平台</a></td>
<td data-nodeid="7030">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/1091.%E4%BA%8C%E8%BF%9B%E5%88%B6%E7%9F%A9%E9%98%B5%E4%B8%AD%E7%9A%84%E6%9C%80%E7%9F%AD%E8%B7%AF%E5%BE%84.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8305">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/1091.%E4%BA%8C%E8%BF%9B%E5%88%B6%E7%9F%A9%E9%98%B5%E4%B8%AD%E7%9A%84%E6%9C%80%E7%9F%AD%E8%B7%AF%E5%BE%84.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8309">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/1091.%E4%BA%8C%E8%BF%9B%E5%88%B6%E7%9F%A9%E9%98%B5%E4%B8%AD%E7%9A%84%E6%9C%80%E7%9F%AD%E8%B7%AF%E5%BE%84.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8313">Python</a></td>
</tr>
<tr data-nodeid="7031">
<td data-nodeid="7032">例 5：最安全的路径</td>
<td data-nodeid="7033"><a href="https://www.lintcode.com/problem/minimum-risk-path/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8317">测试平台</a></td>
<td data-nodeid="7034">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/783._Minimum_Risk_Path.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8321">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/783._Minimum_Risk_Path.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8325">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/783._Minimum_Risk_Path.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8329">Python</a></td>
</tr>
<tr data-nodeid="7035">
<td data-nodeid="7036">练习题 6：水位线</td>
<td data-nodeid="7037"><a href="https://leetcode-cn.com/problems/swim-in-rising-water/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8333">测试平台</a></td>
<td data-nodeid="7038">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/778.%E6%B0%B4%E4%BD%8D%E4%B8%8A%E5%8D%87%E7%9A%84%E6%B3%B3%E6%B1%A0%E4%B8%AD%E6%B8%B8%E6%B3%B3.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8337">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/778.%E6%B0%B4%E4%BD%8D%E4%B8%8A%E5%8D%87%E7%9A%84%E6%B3%B3%E6%B1%A0%E4%B8%AD%E6%B8%B8%E6%B3%B3.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8341">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/778.%E6%B0%B4%E4%BD%8D%E4%B8%8A%E5%8D%87%E7%9A%84%E6%B3%B3%E6%B1%A0%E4%B8%AD%E6%B8%B8%E6%B3%B3.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8345">Python</a></td>
</tr>
<tr data-nodeid="7039">
<td data-nodeid="7040">思考题</td>
<td data-nodeid="7041"><a href="https://leetcode-cn.com/problems/generate-parentheses/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8349">测试平台</a></td>
<td data-nodeid="7042" class="">DP 解法：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.DP/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8353">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.DP/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8357">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.DP/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8361">Python</a><br>BFS 解法 1：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.%E4%B8%A4%E6%AE%B5%E5%87%BB/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8366">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.%E4%B8%A4%E6%AE%B5%E5%87%BB/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8370">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.%E4%B8%A4%E6%AE%B5%E5%87%BB/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8374">Python</a><br>BFS 解法 2：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.%E9%98%9F%E5%88%97/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8379">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.%E9%98%9F%E5%88%97/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8383">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.%E9%98%9F%E5%88%97/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8387">Python</a><br>DFS 解法：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.%E5%9B%9E%E6%BA%AF/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8392">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.%E5%9B%9E%E6%BA%AF/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8396">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/13.DFS.BFS/22.%E5%9B%9E%E6%BA%AF/22.%E6%8B%AC%E5%8F%B7%E7%94%9F%E6%88%90.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="8400">Python</a></td>
</tr>
</tbody>
</table>