### 本资源由 Java学习者论坛 收集整理
<p data-nodeid="21979">上一讲我们介绍了 etcd 的整体架构，学习客户端与 etcd 服务端的通信以及 etcd 集群节点的内部通信接口能帮助我们更好地掌握和使用 etcd 组件，这也是你必须了解的内容。这一讲我们继续介绍 etcd 的 gRPC 通信接口以及客户端的实践。</p>
<h3 data-nodeid="21980">client 定义</h3>
<p data-nodeid="21981">首先我们来看一下 client 的定义：</p>
<pre class="lang-java" data-nodeid="21982"><code data-language="java">type Client struct {
    Cluster
    KV
    Lease
    Watcher
    Auth
    Maintenance
    <span class="hljs-comment">// 认证的用户名</span>
    Username string
    <span class="hljs-comment">// 认证的密码</span>
    Password string
}
</code></pre>
<p data-nodeid="21983">注意，这里显示的都是可导出的模块结构字段，代表了客户端能够使用的几大核心模块，具体功能介绍如下。</p>
<ul data-nodeid="21984">
<li data-nodeid="21985">
<p data-nodeid="21986">Cluster：向集群里增加 etcd 服务端节点之类，属于管理员操作。</p>
</li>
<li data-nodeid="21987">
<p data-nodeid="21988">KV：我们主要使用的功能，即操作 K-V。</p>
</li>
<li data-nodeid="21989">
<p data-nodeid="21990">Lease：租约相关操作，比如申请一个 TTL=10 秒的租约。</p>
</li>
<li data-nodeid="21991">
<p data-nodeid="21992">Watcher：观察订阅，从而监听最新的数据变化。</p>
</li>
<li data-nodeid="21993">
<p data-nodeid="21994">Auth：管理 etcd 的用户和权限，属于管理员操作。</p>
</li>
<li data-nodeid="21995">
<p data-nodeid="21996">Maintenance：维护 etcd，比如主动迁移 etcd 的 leader 节点，属于管理员操作。</p>
</li>
</ul>
<h4 data-nodeid="21997">gRPC 服务</h4>
<p data-nodeid="21998">etcd v3 的通信基于 gRPC，proto 文件是定义服务端和客户端通信接口的标准。包括：</p>
<ul data-nodeid="21999">
<li data-nodeid="22000">
<p data-nodeid="22001">客户端该传什么样的参数</p>
</li>
<li data-nodeid="22002">
<p data-nodeid="22003">服务端该返回什么参数</p>
</li>
<li data-nodeid="22004">
<p data-nodeid="22005">客户端该怎么调用</p>
</li>
<li data-nodeid="22006">
<p data-nodeid="22007">是阻塞还是非阻塞</p>
</li>
<li data-nodeid="22008">
<p data-nodeid="22009">是同步还是异步</p>
</li>
</ul>
<p data-nodeid="22010">gRPC 推荐使用 proto3 消息格式，在进行核心 API 的学习之前，我们需要对 proto3 的基本语法有初步的了解。<strong data-nodeid="22174">proto3 是原有 Protocol Buffer 2（被称为 proto2）的升级版本，删除了一部分特性，优化了对移动设备的支持</strong>。</p>
<p data-nodeid="22011">发送到 etcd 服务器的每个 API 请求都是一个 gRPC 远程过程调用。etcd 中的 RPC 接口定义根据功能分类到服务中。</p>
<p data-nodeid="22012">处理 etcd 键值的重要服务包括：</p>
<ul data-nodeid="22013">
<li data-nodeid="22014">
<p data-nodeid="22015">KV Service，创建、更新、获取和删除键值对。</p>
</li>
<li data-nodeid="22016">
<p data-nodeid="22017">Watch Service，监视键的更改。</p>
</li>
<li data-nodeid="22018">
<p data-nodeid="22019">Lease Service，实现键值对过期，客户端用来续租、保持心跳。</p>
</li>
<li data-nodeid="22020">
<p data-nodeid="22021">Lock Service，etcd 提供分布式共享锁的支持。</p>
</li>
<li data-nodeid="22022">
<p data-nodeid="22023">Election Service，暴露客户端选举机制。</p>
</li>
</ul>
<p data-nodeid="23879" class=""><img src="https://s0.lgstatic.com/i/image6/M00/07/55/Cgp9HWAzYzCATpxiAABwpS8GraQ616.png" alt="Drawing 1.png" data-nodeid="23882"></p>


<h4 data-nodeid="22026">请求和响应</h4>
<p data-nodeid="22027">etcd3 中的所有 RPC 都遵循相同的格式。每个 RPC 都有一个函数名，该函数将 NameRequest 作为参数并返回 NameResponse 作为响应。例如，这是 Range RPC 描述：</p>
<pre class="lang-java" data-nodeid="22028"><code data-language="java">service KV {
  Range(RangeRequest) returns (RangeResponse)
  ...
}
</code></pre>
<h4 data-nodeid="22029">响应头</h4>
<p data-nodeid="22030">etcd API 的所有响应都有一个附加的响应标头，其中包括响应的集群元数据：</p>
<pre class="lang-java" data-nodeid="22031"><code data-language="java">message ResponseHeader {
  uint64 cluster_id = <span class="hljs-number">1</span>;
  uint64 member_id = <span class="hljs-number">2</span>;
  int64 revision = <span class="hljs-number">3</span>;
  uint64 raft_term = <span class="hljs-number">4</span>;
}
</code></pre>
<ul data-nodeid="22032">
<li data-nodeid="22033">
<p data-nodeid="22034">Cluster_ID：产生响应的集群的 ID。</p>
</li>
<li data-nodeid="22035">
<p data-nodeid="22036">Member_ID：产生响应的成员的 ID。</p>
</li>
</ul>
<p data-nodeid="22037">应用服务可以通过 Cluster_ID 和 Member_ID 字段来确保，当前与之通信的正是预期的那个集群或者成员。</p>
<ul data-nodeid="22038">
<li data-nodeid="22039">
<p data-nodeid="22040">Revision：产生响应时键值存储的修订版本号。</p>
</li>
</ul>
<p data-nodeid="22041">应用服务可以使用<strong data-nodeid="22209">修订号字段</strong>来获得当前键值存储库最新的修订号。应用程序指定历史修订版以进行查询，如果希望在请求时知道最新修订版，此功能特别有用。</p>
<ul data-nodeid="22042">
<li data-nodeid="22043">
<p data-nodeid="22044">Raft_Term：产生响应时，成员的 Raft 称谓。</p>
</li>
</ul>
<p data-nodeid="22045">应用服务可以使用 Raft_Term 来检测集群何时完成一个新的 leader 选举。</p>
<h3 data-nodeid="22046">etcd clientv3 客户端</h3>
<p data-nodeid="22047">etcd 客户端 clientv3 接入的示例将会以 Go 客户端为主，你需要准备好基本的开发环境。</p>
<p data-nodeid="22048">首先是 etcd clientv3 的初始化，我们根据指定的 etcd 节点，建立客户端与 etcd 集群的连接：</p>
<pre class="lang-java" data-nodeid="22049"><code data-language="java">cli,err := clientv3.New(clientv3.Config{
    Endpoints:[]string{<span class="hljs-string">"localhost:2379"</span>},
    DialTimeout: <span class="hljs-number">5</span> * time.Second,
})
</code></pre>
<p data-nodeid="22050">如上的代码实例化了一个 client，这里需要传入两个参数。</p>
<ul data-nodeid="22051">
<li data-nodeid="22052">
<p data-nodeid="22053">Endpoints：etcd 的多个节点服务地址，因为我是单点本机测试，所以只传 1 个。</p>
</li>
<li data-nodeid="22054">
<p data-nodeid="22055">DialTimeout：创建 client 的首次连接超时，这里传了 5 秒，如果 5 秒都没有连接成功就会返回 err。需要注意的是，<strong data-nodeid="22226">一旦 client 创建成功，我们就不用再关心后续底层连接的状态了，client 内部会重连</strong>。</p>
</li>
</ul>
<h3 data-nodeid="22056">etcd 客户端初始化</h3>
<p data-nodeid="22057">解决完包依赖后，我们初始化 etcd 客户端。客户端初始化代码如下所示：</p>
<pre class="lang-go" data-nodeid="22058"><code data-language="go"><span class="hljs-comment">// client_init_test.go</span>
<span class="hljs-keyword">package</span> client
<span class="hljs-keyword">import</span> (
	<span class="hljs-string">"context"</span>
	<span class="hljs-string">"fmt"</span>
	<span class="hljs-string">"go.etcd.io/etcd/clientv3"</span>
	<span class="hljs-string">"testing"</span>
	<span class="hljs-string">"time"</span>
)
<span class="hljs-comment">// 测试客户端连接</span>
<span class="hljs-function"><span class="hljs-keyword">func</span> <span class="hljs-title">TestEtcdClientInit</span><span class="hljs-params">(t *testing.T)</span></span> {
	<span class="hljs-keyword">var</span> (
		config clientv3.Config
		client *clientv3.Client
		err    error
	)
	<span class="hljs-comment">// 客户端配置</span>
	config = clientv3.Config{
		<span class="hljs-comment">// 节点配置</span>
		Endpoints:   []<span class="hljs-keyword">string</span>{<span class="hljs-string">"localhost:2379"</span>},
		DialTimeout: <span class="hljs-number">5</span> * time.Second,
	}
	<span class="hljs-comment">// 建立连接</span>
	<span class="hljs-keyword">if</span> client, err = clientv3.New(config); err != <span class="hljs-literal">nil</span> {
		fmt.Println(err)
	} <span class="hljs-keyword">else</span> {
		<span class="hljs-comment">// 输出集群信息</span>
		fmt.Println(client.Cluster.MemberList(context.TODO()))
	}
	client.Close()
}
</code></pre>
<p data-nodeid="22059">参考上述代码，预期的执行结果如下：</p>
<pre class="lang-java" data-nodeid="22060"><code data-language="java">=== RUN   TestEtcdClientInit
&amp;{cluster_id:<span class="hljs-number">14841639068965178418</span> member_id:<span class="hljs-number">10276657743932975437</span> raft_term:<span class="hljs-number">3</span>  [ID:<span class="hljs-number">10276657743932975437</span> name:<span class="hljs-string">"default"</span> peerURLs:<span class="hljs-string">"http://localhost:2380"</span> clientURLs:<span class="hljs-string">"http://0.0.0.0:2379"</span> ] {} [] <span class="hljs-number">0</span>} &lt;nil&gt;
--- PASS: TestEtcdClientInit (<span class="hljs-number">0.08</span>s)
PASS
</code></pre>
<p data-nodeid="22061">可以看到 clientv3 与 etcd Server 的节点 localhost:2379 成功建立了连接，并且输出了集群的信息，下面我们介绍 etcd 中几个重要的服务和接口，对 etcd 进行操作。</p>
<h3 data-nodeid="22062">KV 存储</h3>
<p data-nodeid="22063">KV 对象的实例获取通过如下的方式：</p>
<pre class="lang-java" data-nodeid="22064"><code data-language="java">kv := clientev3.NewKV(client)
</code></pre>
<p data-nodeid="22065">我们来看一下 KV 接口的具体定义：</p>
<pre class="lang-java" data-nodeid="22066"><code data-language="java">type KV <span class="hljs-class"><span class="hljs-keyword">interface</span> </span>{
    Put(ctx context.Context, key, val string, opts ...OpOption) (*PutResponse, error)
    <span class="hljs-comment">// 检索 keys</span>
    Get(ctx context.Context, key string, opts ...OpOption) (*GetResponse, error)
    <span class="hljs-comment">// 删除 key，可以使用 WithRange(end), [key, end) 的方式</span>
    Delete(ctx context.Context, key string, opts ...OpOption) (*DeleteResponse, error)
    <span class="hljs-comment">// 压缩给定版本之前的 KV 历史</span>
    Compact(ctx context.Context, rev int64, opts ...CompactOption) (*CompactResponse, error)
    <span class="hljs-comment">// 指定某种没有事务的操作</span>
    Do(ctx context.Context, op Op) (OpResponse, error)
    <span class="hljs-comment">// Txn 创建一个事务</span>
    Txn(ctx context.Context) Txn
}
</code></pre>
<p data-nodeid="22067">从 KV 对象的定义我们可知，它就是一个接口对象，包含以下几个主要的 KV 操作方法。</p>
<h4 data-nodeid="22068">KV 存储 Put</h4>
<p data-nodeid="22069">Put 的定义如下：</p>
<pre class="lang-java" data-nodeid="22070"><code data-language="java">Put(ctx context.Context, key, val string, opts ...OpOption) (*PutResponse, error)
</code></pre>
<p data-nodeid="22071">其中的参数</p>
<ul data-nodeid="22072">
<li data-nodeid="22073">
<p data-nodeid="22074">ctx：Context 包对象，用来跟踪上下文，比如超时控制。</p>
</li>
<li data-nodeid="22075">
<p data-nodeid="22076">key：存储对象的 key。</p>
</li>
<li data-nodeid="22077">
<p data-nodeid="22078">val：存储对象的 value。</p>
</li>
<li data-nodeid="22079">
<p data-nodeid="22080">opts：可变参数，额外选项。</p>
</li>
</ul>
<p data-nodeid="22081">Put 将一个键值对放入 etcd 中。请注意，<strong data-nodeid="22249">键值可以是纯字节数组，字符串是该字节数组的不可变表示形式</strong>。要获取字节字符串，请执行<code data-backticks="1" data-nodeid="22247">string([] byte {0x10，0x20})</code>。</p>
<p data-nodeid="22082">Put 的使用方法如下所示：</p>
<pre class="lang-java" data-nodeid="22083"><code data-language="java">putResp, err := kv.Put(context.TODO(),<span class="hljs-string">"aa"</span>, <span class="hljs-string">"hello-world!"</span>)
</code></pre>
<h4 data-nodeid="22084">KV 查询 Get</h4>
<p data-nodeid="22085">现在可以对存储的数据进行取值了。默认情况下，Get 将返回“key”对应的值。</p>
<pre class="lang-java" data-nodeid="22086"><code data-language="java">Get(ctx context.Context, key string, opts ...OpOption) (*GetResponse, error)
</code></pre>
<p data-nodeid="22087">OpOption 为可选的函数传参，传参为<code data-backticks="1" data-nodeid="22254">WithRange(end)</code>时，Get 将返回 [key，end) 范围内的键；传参为 <code data-backticks="1" data-nodeid="22258">WithFromKey()</code> 时，Get 返回大于或等于 key 的键；当通过 rev&gt; 0 传递 <code data-backticks="1" data-nodeid="22260">WithRev(rev)</code> 时，Get 查询给定修订版本的键；如果压缩了所查找的修订版本，则返回请求失败，并显示 ErrCompacted。 传递 <code data-backticks="1" data-nodeid="22262">WithLimit(limit)</code> 时，返回的 key 数量受 limit 限制；传参为 <code data-backticks="1" data-nodeid="22264">WithSort</code> 时，将对键进行排序。</p>
<p data-nodeid="22088">对应的使用方法如下：</p>
<pre class="lang-java" data-nodeid="22089"><code data-language="java">getResp, err := kv.Get(context.TODO(), <span class="hljs-string">"aa"</span>)
</code></pre>
<p data-nodeid="22090">从以上数据的存储和取值，我们知道：Put 返回 PutResponse，Get 返回 GetResponse。注意：<strong data-nodeid="22272">不同的 KV 操作对应不同的 Response 结构</strong>，定义如下：</p>
<pre class="lang-java" data-nodeid="22091"><code data-language="java">type (
    CompactResponse pb.CompactionResponse
    PutResponse     pb.PutResponse
    GetResponse     pb.RangeResponse
    DeleteResponse  pb.DeleteRangeResponse
    TxnResponse     pb.TxnResponse
)
</code></pre>
<p data-nodeid="22092">下面我们分别来看一看 PutResponse 和 GetResponse 映射的 RangeResponse 结构的定义：</p>
<pre class="lang-java" data-nodeid="22093"><code data-language="java">type PutResponse struct {
    Header *ResponseHeader `protobuf:<span class="hljs-string">"bytes,1,opt,name=header"</span> json:<span class="hljs-string">"header,omitempty"</span>`
    <span class="hljs-comment">// 请求中如有 prev_kv，响应时也会携带 prev_kv </span>
    PrevKv *mvccpb.KeyValue `protobuf:<span class="hljs-string">"bytes,2,opt,name=prev_kv,json=prevKv"</span> json:<span class="hljs-string">"prev_kv,omitempty"</span>`
}
<span class="hljs-comment">//Header 里保存的主要是本次更新的 revision 信息</span>
type RangeResponse struct {
    Header *ResponseHeader `protobuf:<span class="hljs-string">"bytes,1,opt,name=header"</span> json:<span class="hljs-string">"header,omitempty"</span>`
    <span class="hljs-comment">// kvs 是一个匹配 range 请求的键值对列表</span>
    Kvs []*mvccpb.KeyValue `protobuf:<span class="hljs-string">"bytes,2,rep,name=kvs"</span> json:<span class="hljs-string">"kvs,omitempty"</span>`
    <span class="hljs-comment">// more 用以分页 </span>
    More bool `protobuf:<span class="hljs-string">"varint,3,opt,name=more,proto3"</span> json:<span class="hljs-string">"more,omitempty"</span>`
    <span class="hljs-comment">// count 表示 range 的键值对数量</span>
    Count int64 `protobuf:<span class="hljs-string">"varint,4,opt,name=count,proto3"</span> json:<span class="hljs-string">"count,omitempty"</span>`
}
</code></pre>
<p data-nodeid="22094">KVS 字段，保存了本次 Get 查询到的所有 KV 对，我们继续看一下 mvccpb.KeyValue 对象的定义：</p>
<pre class="lang-java" data-nodeid="22095"><code data-language="java">type KeyValue struct {
    Key []<span class="hljs-keyword">byte</span> `protobuf:<span class="hljs-string">"bytes,1,opt,name=key,proto3"</span> json:<span class="hljs-string">"key,omitempty"</span>`
    <span class="hljs-comment">// create_revision 是当前 key 的最后创建版本</span>
    CreateRevision int64 `protobuf:<span class="hljs-string">"varint,2,opt,name=create_revision,json=createRevision,proto3"</span> json:<span class="hljs-string">"create_revision,omitempty"</span>`
    <span class="hljs-comment">// mod_revision 是指当前 key 的最新修订版本</span>
    ModRevision int64 `protobuf:<span class="hljs-string">"varint,3,opt,name=mod_revision,json=modRevision,proto3"</span> json:<span class="hljs-string">"mod_revision,omitempty"</span>`
    <span class="hljs-comment">// key 的版本，每次更新都会增加版本号</span>
    Version int64 `protobuf:<span class="hljs-string">"varint,4,opt,name=version,proto3"</span> json:<span class="hljs-string">"version,omitempty"</span>`
    Value []<span class="hljs-keyword">byte</span> `protobuf:<span class="hljs-string">"bytes,5,opt,name=value,proto3"</span> json:<span class="hljs-string">"value,omitempty"</span>`
    <span class="hljs-comment">// 绑定了 key 的租期 Id，当 lease 为 0 ，则表明没有绑定 key；租期过期，则会删除 key</span>
    Lease int64 `protobuf:<span class="hljs-string">"varint,6,opt,name=lease,proto3"</span> json:<span class="hljs-string">"lease,omitempty"</span>`
}
</code></pre>
<p data-nodeid="22096">至于 RangeResponse.More 和 Count，当我们使用 withLimit() 选项进行 Get 时会发挥作用，相当于分页查询。</p>
<p data-nodeid="22097">接下来，我们通过一个特别的 Get 选项，获取 aa 目录下的所有子目录：</p>
<pre class="lang-java" data-nodeid="22098"><code data-language="java">rangeResp, err := kv.Get(context.TODO(), <span class="hljs-string">"/aa"</span>, clientv3.WithPrefix())
</code></pre>
<p data-nodeid="22099"><code data-backticks="1" data-nodeid="22277">WithPrefix()</code>用于查找以<code data-backticks="1" data-nodeid="22279">/aa</code>为前缀的所有 key，因此可以模拟出查找子目录的效果。我们知道 etcd 是一个有序的 KV 存储，因此<code data-backticks="1" data-nodeid="22281">/aa</code>为前缀的 key 总是顺序排列在一起。</p>
<p data-nodeid="22100">WithPrefix 实际上会转化为范围查询，它根据前缀<code data-backticks="1" data-nodeid="22284">/aa</code>生成了一个 key range，[“/aa/”, “/aa0”)，这是因为比 <code data-backticks="1" data-nodeid="22288">/</code> 大的字符是 <code data-backticks="1" data-nodeid="22290">0</code>，所以以 <code data-backticks="1" data-nodeid="22292">/aa0</code> 作为范围的末尾，就可以扫描到所有的 <code data-backticks="1" data-nodeid="22294">/aa/</code> 打头的 key 了。</p>
<h4 data-nodeid="22101">KV 操作实践</h4>
<p data-nodeid="22102">键值对的操作是 etcd 中最基本、最常用的功能，主要包括读、写、删除三种基本的操作。在 etcd 中定义了 KV 接口，用来对外提供这些操作，下面我们进行具体测试：</p>
<pre class="lang-java" data-nodeid="22103"><code data-language="java"><span class="hljs-function"><span class="hljs-keyword">package</span> client
<span class="hljs-title">import</span> <span class="hljs-params">(
	<span class="hljs-string">"context"</span>
	<span class="hljs-string">"fmt"</span>
	<span class="hljs-string">"github.com/google/uuid"</span>
	<span class="hljs-string">"go.etcd.io/etcd/clientv3"</span>
	<span class="hljs-string">"testing"</span>
	<span class="hljs-string">"time"</span>
)</span>
func <span class="hljs-title">TestKV</span><span class="hljs-params">(t *testing.T)</span> </span>{
	rootContext := context.Background()
	<span class="hljs-comment">// 客户端初始化</span>
	cli, err := clientv3.New(clientv3.Config{
		Endpoints:   []string{<span class="hljs-string">"localhost:2379"</span>},
		DialTimeout: <span class="hljs-number">2</span> * time.Second,
	})
	<span class="hljs-comment">// etcd clientv3 &gt;= v3.2.10, grpc/grpc-go &gt;= v1.7.3</span>
	<span class="hljs-keyword">if</span> cli == nil || err == context.DeadlineExceeded {
		<span class="hljs-comment">// handle errors</span>
		fmt.Println(err)
		panic(<span class="hljs-string">"invalid connection!"</span>)
	}
	<span class="hljs-comment">// 客户端断开连接</span>
	defer cli.Close()
	<span class="hljs-comment">// 初始化 kv</span>
	kvc := clientv3.NewKV(cli)
	<span class="hljs-comment">//获取值</span>
	ctx, cancelFunc := context.WithTimeout(rootContext, time.Duration(<span class="hljs-number">2</span>)*time.Second)
	response, err := kvc.Get(ctx, <span class="hljs-string">"cc"</span>)
	cancelFunc()
	<span class="hljs-keyword">if</span> err != nil {
		fmt.Println(err)
	}
	kvs := response.Kvs
	<span class="hljs-comment">// 输出获取的 key</span>
	<span class="hljs-function"><span class="hljs-keyword">if</span> <span class="hljs-title">len</span><span class="hljs-params">(kvs)</span> &gt; 0 </span>{
		fmt.Printf(<span class="hljs-string">"last value is :%s\r\n"</span>, string(kvs[<span class="hljs-number">0</span>].Value))
	} <span class="hljs-keyword">else</span> {
		fmt.Printf(<span class="hljs-string">"empty key for %s\n"</span>, <span class="hljs-string">"cc"</span>)
	}
	<span class="hljs-comment">//设置值</span>
	uuid := uuid.New().String()
	fmt.Printf(<span class="hljs-string">"new value is :%s\r\n"</span>, uuid)
	ctx2, cancelFunc2 := context.WithTimeout(rootContext, time.Duration(<span class="hljs-number">2</span>)*time.Second)
	_, err = kvc.Put(ctx2, <span class="hljs-string">"cc"</span>, uuid)
	<span class="hljs-comment">// 设置成功后，将该 key 对应的键值删除</span>
	<span class="hljs-keyword">if</span> delRes, err := kvc.Delete(ctx2, <span class="hljs-string">"cc"</span>); err != nil {
		fmt.Println(err)
	} <span class="hljs-keyword">else</span> {
		fmt.Printf(<span class="hljs-string">"delete %s for %t\n"</span>, <span class="hljs-string">"cc"</span>, delRes.Deleted &gt; <span class="hljs-number">0</span>)
	}
	cancelFunc2()
	<span class="hljs-keyword">if</span> err != nil {
		fmt.Println(err)
	}
}
</code></pre>
<p data-nodeid="22104">如上的测试用例，主要是针对 KV 的操作，依次获取 key，即 Get()，对应 etcd 底层实现的 range 接口；其次是写入键值对，即 put 操作；最后删除刚刚写入的键值对。预期的执行结果如下所示：</p>
<pre class="lang-java" data-nodeid="22105"><code data-language="java">=== RUN   Test
empty key <span class="hljs-keyword">for</span> cc
<span class="hljs-keyword">new</span> value is: <span class="hljs-number">41e1362</span>a-<span class="hljs-number">28</span>a7-<span class="hljs-number">4</span>ac9-abf5-fe1474d93f84
delete cc <span class="hljs-keyword">for</span> <span class="hljs-keyword">true</span>
--- PASS: Test (<span class="hljs-number">0.11</span>s)
PASS
</code></pre>
<p data-nodeid="22106">可以看到，刚开始 etcd 并没有存储键<code data-backticks="1" data-nodeid="22300">cc</code>的值，随后写入新的键值对并测试将其删除。</p>
<h3 data-nodeid="22107">其他通信接口</h3>
<p data-nodeid="22108">其他常用的接口还有 Txn、Compact、Watch、Lease、Lock 等。我们依次看看这些接口的定义。</p>
<h4 data-nodeid="22109">事务 Txn</h4>
<p data-nodeid="22110">Txn 方法在单个事务中处理多个请求。Txn 请求增加键值存储的修订版本，并为每个完成的请求生成带有相同修订版本的事件，<strong data-nodeid="22310">etcd 不容许在一个 Txn 中多次修改同一个 key</strong>。Txn 接口定义如下：</p>
<pre class="lang-java" data-nodeid="22111"><code data-language="java"><span class="hljs-function">rpc <span class="hljs-title">Txn</span><span class="hljs-params">(TxnRequest)</span> <span class="hljs-title">returns</span> <span class="hljs-params">(TxnResponse)</span> </span>{}
</code></pre>
<h4 data-nodeid="22112">Compact</h4>
<p data-nodeid="22113">Compact 方法压缩 etcd 键值对存储中的事件历史。键值对存储应该<strong data-nodeid="22317">定期压缩</strong>，否则事件历史会无限制地持续增长。Compact 接口定义如下：</p>
<pre class="lang-java" data-nodeid="22114"><code data-language="java"><span class="hljs-function">rpc <span class="hljs-title">Compact</span><span class="hljs-params">(CompactionRequest)</span> <span class="hljs-title">returns</span> <span class="hljs-params">(CompactionResponse)</span> </span>{}
</code></pre>
<p data-nodeid="22115">请求的消息体是 CompactionRequest， CompactionRequest 压缩键值对存储到给定修订版本，所有修订版本比压缩修订版本小的键都将被删除。</p>
<h4 data-nodeid="22116">Watch</h4>
<p data-nodeid="22117">Watch API 提供了一个基于事件的接口，用于<strong data-nodeid="22325">异步监视键的更改</strong>。etcd 监视程序通过给定的修订版本（当前版本或历史版本）持续监视 key 更改，并将 key 更新流回客户端。</p>
<p data-nodeid="22118">在 rpc.proto 中 Watch Service 定义如下：</p>
<pre class="lang-java" data-nodeid="22119"><code data-language="java">service Watch {
  <span class="hljs-function">rpc <span class="hljs-title">Watch</span><span class="hljs-params">(stream WatchRequest)</span> <span class="hljs-title">returns</span> <span class="hljs-params">(stream WatchResponse)</span> </span>{}
}
</code></pre>
<p data-nodeid="22120">Watch 观察将要发生或者已经发生的事件。输入和输出都是流，输入流用于创建和取消观察，而输出流发送事件。一个观察 RPC 可以一次性在多个 key 范围上观察，并为多个观察流化事件。整个事件历史可以从最后压缩修订版本开始观察。Watch Service 只有一个 Watch 方法。</p>
<h4 data-nodeid="22121">Lease Service</h4>
<p data-nodeid="22122">Lease Service 提供租约的支持。Lease 是一种<strong data-nodeid="22334">检测客户端存活状况</strong>的机制。集群授予客户端具有生存时间的租约。如果 etcd 集群在给定的 TTL 时间内未收到 keepAlive，则租约到期。</p>
<p data-nodeid="22123">为了将租约绑定到键值存储中，每个 key 最多可以附加一个租约。当租约到期或被撤销时，该租约依附的所有 key 都将被删除，每个过期的密钥都会在事件历史记录中生成一个删除事件。</p>
<p data-nodeid="22124">在 rpc.proto 中 Lease Service 定义的接口如下：</p>
<pre class="lang-java" data-nodeid="22125"><code data-language="java">service Lease {
  <span class="hljs-function">rpc <span class="hljs-title">LeaseGrant</span><span class="hljs-params">(LeaseGrantRequest)</span> <span class="hljs-title">returns</span> <span class="hljs-params">(LeaseGrantResponse)</span> </span>{}
  <span class="hljs-function">rpc <span class="hljs-title">LeaseRevoke</span><span class="hljs-params">(LeaseRevokeRequest)</span> <span class="hljs-title">returns</span> <span class="hljs-params">(LeaseRevokeResponse)</span> </span>{}
  <span class="hljs-function">rpc <span class="hljs-title">LeaseKeepAlive</span><span class="hljs-params">(stream LeaseKeepAliveRequest)</span> <span class="hljs-title">returns</span> <span class="hljs-params">(stream LeaseKeepAliveResponse)</span> </span>{}
  <span class="hljs-function">rpc <span class="hljs-title">LeaseTimeToLive</span><span class="hljs-params">(LeaseTimeToLiveRequest)</span> <span class="hljs-title">returns</span> <span class="hljs-params">(LeaseTimeToLiveResponse)</span> </span>{}
}
</code></pre>
<p data-nodeid="22126">其中：</p>
<ul data-nodeid="22127">
<li data-nodeid="22128">
<p data-nodeid="22129">LeaseGrant，创建一个租约；</p>
</li>
<li data-nodeid="22130">
<p data-nodeid="22131">LeaseRevoke，撤销一个租约；</p>
</li>
<li data-nodeid="22132">
<p data-nodeid="22133">LeaseKeepAlive，用于维持租约；</p>
</li>
<li data-nodeid="22134">
<p data-nodeid="22135">LeaseTimeToLive，获取租约信息。</p>
</li>
</ul>
<h4 data-nodeid="22136">Lock Service</h4>
<p data-nodeid="22137">Lock Service 提供<strong data-nodeid="22348">分布式共享锁</strong>的支持。Lock Service 以 gRPC 接口的方式暴露客户端锁机制。在 v3lock.proto 中 Lock Service 定义如下：</p>
<pre class="lang-java" data-nodeid="22138"><code data-language="java">service Lock {
  <span class="hljs-function">rpc <span class="hljs-title">Lock</span><span class="hljs-params">(LockRequest)</span> <span class="hljs-title">returns</span> <span class="hljs-params">(LockResponse)</span> </span>{}
  <span class="hljs-function">rpc <span class="hljs-title">Unlock</span><span class="hljs-params">(UnlockRequest)</span> <span class="hljs-title">returns</span> <span class="hljs-params">(UnlockResponse)</span> </span>{}
}
</code></pre>
<p data-nodeid="22139">其中：</p>
<ul data-nodeid="22140">
<li data-nodeid="22141">
<p data-nodeid="22142">Lock 方法，在给定命令锁上获得分布式共享锁；</p>
</li>
<li data-nodeid="22143">
<p data-nodeid="22144">Unlock 使用 Lock 返回的 key 并释放对锁的持有。</p>
</li>
</ul>
<h3 data-nodeid="22145">小结</h3>
<p data-nodeid="22146">这一讲我们主要介绍了 etcd 的 gRPC 通信接口以及 clientv3 客户端的实践，主要包括键值对操作（增删改查）、Watch、Lease、锁和 Compact 等接口。通过这一讲的学习，了解 etcd 客户端的使用以及常用功能的接口定义，对于我们在日常工作中能够得心应手地使用 etcd，实现相应的功能大有助益。</p>
<p data-nodeid="22147">本讲内容总结如下：</p>
<p data-nodeid="24631" class="te-preview-highlight"><img src="https://s0.lgstatic.com/i/image6/M00/07/53/CioPOWAzZK6AYd3XAAK0402aytE269.png" alt="Drawing 2.png" data-nodeid="24634"></p>

<p data-nodeid="22149">当然，由于篇幅所限，这一讲我们只是介绍了常用的几个通信接口，如果你对其他的接口还有疑问，欢迎在留言区提出。下一课时我们将介绍 etcd 的存储：如何实现键值对的读写操作。</p>

---

### 精选评论


