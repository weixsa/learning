### 本资源由 itjc8.com 收集整理
<p data-nodeid="11761" class="">动态规划（Dynamic Programming，DP）是求解决策过程最优化的过程，通过把原问题分解为相对简单的子问题的方式求解复杂问题，在数学、管理科学、计算机科学、经济学和生物信息学等领域被广泛使用。</p>
<p data-nodeid="11762">它的基本思想非常简单，若要求解一个给定问题，我们需要求解其不同部分（即<strong data-nodeid="12468">子问题</strong>），再根据<strong data-nodeid="12469">子问题的解得出原问题的解</strong>。</p>
<p data-nodeid="11763">通常许多子问题非常相似，为了减少计算量，<strong data-nodeid="12479">动态规划法试图每个子问题仅解决一次</strong>，一旦算出某个给定<strong data-nodeid="12480">子问题的解，则将其记忆化存储</strong>，以便下次求解同一个子问题解时可以直接查表。因此具有天然剪枝的功能。</p>
<h3 data-nodeid="11764">DP 题目的特点</h3>
<p data-nodeid="11765">首先我们一起来看一下，什么样的题目可能需要使用动态规划。一般而言（并不绝对），如果题目如出现以下特点，你就可以考虑（有一定概率）使用动态规划。</p>
<p data-nodeid="11766"><strong data-nodeid="12486">特点一：计数</strong></p>
<ul data-nodeid="11767">
<li data-nodeid="11768">
<p data-nodeid="11769">题目问：有<strong data-nodeid="12496">多少种</strong>方法？有<strong data-nodeid="12497">多少种</strong>走法？</p>
</li>
<li data-nodeid="11770">
<p data-nodeid="11771">关键字：<strong data-nodeid="12503">多少</strong>！</p>
</li>
</ul>
<p data-nodeid="11772"><strong data-nodeid="12507">特点二：最大值/最小值</strong></p>
<ul data-nodeid="11773">
<li data-nodeid="11774">
<p data-nodeid="11775">题目问：某种选择的最大值是什么？完成任务的最小时间是什么？数组的最长子序列是什么？达到目标最少操作多少次等。</p>
</li>
<li data-nodeid="11776">
<p data-nodeid="11777">关键字：<strong data-nodeid="12513">最！</strong></p>
</li>
</ul>
<p data-nodeid="11778"><strong data-nodeid="12517">特点三：可能性</strong></p>
<ul data-nodeid="11779">
<li data-nodeid="11780">
<p data-nodeid="11781">题目问：是否有可能出现某种情况？是否有可能在游戏中胜出？是否可以取出 k 个数满足条件？</p>
</li>
<li data-nodeid="11782">
<p data-nodeid="11783">关键字：<strong data-nodeid="12524">是否</strong>！</p>
</li>
</ul>
<p data-nodeid="11784">通常而言，看到这三类题目，就可以尝试往 DP 解法上靠。</p>
<h3 data-nodeid="11785">DP 的 6 步破题法</h3>
<p data-nodeid="11786">找到题目的特点，确定可以使用 DP 之后，接下来就可以准备逐步破题了。</p>
<p data-nodeid="11787">下面我们以一道题目为例，详细介绍破解 DP 问题的思考过程与解题步骤。其实这道题不难，我相信你们都见过，不过我还是希望你能跟着我的思维重新再思考一遍。</p>
<p data-nodeid="11788">【<strong data-nodeid="12534">题目</strong>】给定不同面额的硬币 coins 和一个总金额 amount，需要你编写一个函数计算可以凑成总金额所需的最少的硬币个数。如果没有任何一种硬币组合能组成总金额，则返回 -1。你可以认为每种硬币的数量是无限的。</p>
<p data-nodeid="11789">输入：coins = [1, 2, 5]，amount = 11</p>
<p data-nodeid="11790">输出：3</p>
<p data-nodeid="11791">解释：11 元可以拆分为 5 + 5 + 1，这是最少的硬币数目。</p>
<p data-nodeid="11792">【<strong data-nodeid="12555">分析</strong>】首先我们看到关键字“<strong data-nodeid="12556">最少</strong>”，因此可以尝试往 DP 上面想。在 DP 问题上，很多人都存在一个思维误区，这里我们称为<strong data-nodeid="12557">误区 1</strong>：</p>
<blockquote data-nodeid="11793">
<p data-nodeid="11794">利用 DP 求解问题时，一开始就去想第一步具体做什么！</p>
</blockquote>
<p data-nodeid="11795">你之所以没有思路，往往是因为采用了一种顺应题意的方法去求解问题。比如题目问：</p>
<blockquote data-nodeid="11796">
<p data-nodeid="11797">如何求“最少步数”，你就去想“从头开始怎么走”；<br>
如何选择可以“达到最大收益”，你就真的开始去想“怎么选择”。</p>
</blockquote>
<p data-nodeid="11798">这恰恰是 DP 题目给你下的一个“套”，这样思考很容易带你陷入暴力求解的方法，找不到优化的思路。因此，<strong data-nodeid="12568">千万不要从第一步开始思考</strong>。就这道题而言，就是不要去想，我的第一个硬币怎么选！</p>
<p data-nodeid="11799">那么我们应该从哪里着手呢？答案是：<strong data-nodeid="12574">最后一步</strong>！</p>
<h4 data-nodeid="11800">1. 最后一步</h4>
<p data-nodeid="11801">以这道题为例，最后一步指的是：兑换硬币的时候，假设每一步操作总是选择一个硬币，那么我们看一下最后一步如何达到 amount？</p>
<p data-nodeid="11802">以给定的输入为例：</p>
<blockquote data-nodeid="11803">
<p data-nodeid="11804">coins = [1, 2, 5], amount = 11</p>
</blockquote>
<p data-nodeid="11805">最后一步可以通过以下 3 个选项得到：</p>
<ul data-nodeid="11806">
<li data-nodeid="11807">
<p data-nodeid="11808">已经用硬币兑换好了 10 元，再添加 1 个 1 元的硬币，凑成 11 元；</p>
</li>
<li data-nodeid="11809">
<p data-nodeid="11810">已经用硬币兑换好了 9 元，再添加 1 个 2 元的硬币，凑成 11 元；</p>
</li>
<li data-nodeid="11811">
<p data-nodeid="11812">已经用硬币兑换好了 6 元，再添加 1 个 5 元的硬币，凑成 11 元。</p>
</li>
</ul>
<p data-nodeid="11813">接下来，应该立即将以上 3 个选项中的<strong data-nodeid="12598">未知项</strong>展开成<strong data-nodeid="12599">子问题</strong>！</p>
<p data-nodeid="11814">注意：如果你找的最后一步，待处理的问题规模仍然没有减小，那么说明你只找到了<strong data-nodeid="12605">原始问题的等价问题</strong>，并没有找到真正的最后一步。</p>
<h4 data-nodeid="11815">2. 子问题</h4>
<p data-nodeid="11816">拿到 3 个选项之后，你可能会想：[10元，9元，6元] 是如何得到？到此时，一定<strong data-nodeid="12618">不要尝试递归</strong>地去求解 10 元、9 元、6 元，正确的做法是将它们表达为 3 个子问题：</p>
<ul data-nodeid="11817">
<li data-nodeid="11818">
<p data-nodeid="11819">如何利用最少的硬币组成 10 元？</p>
</li>
<li data-nodeid="11820">
<p data-nodeid="11821">如何利用最少的硬币组成 9 元？</p>
</li>
<li data-nodeid="11822">
<p data-nodeid="11823">如何利用最少的硬币组成 6 元？</p>
</li>
</ul>
<p data-nodeid="11824">我们原来的问题是，如何用最少的硬币组成 11 元。</p>
<p data-nodeid="11825">不难发现，如果用 f(x) 表示如何利用最少的硬币组成 x 元，就可以用 f(x) 将原问题与 3 个子问题统一起来，得到如下内容：</p>
<ul data-nodeid="11826">
<li data-nodeid="11827">
<p data-nodeid="11828">原问题表达为 f(11)；</p>
</li>
<li data-nodeid="11829">
<p data-nodeid="11830">3 个子问题分别表达为 f(10)、f(9)、f(6)。</p>
</li>
</ul>
<p data-nodeid="11831">接下来我们再利用 f(x) 表示<strong data-nodeid="12631">最后一步</strong>的 3 个选项：</p>
<ul data-nodeid="11832">
<li data-nodeid="11833">
<p data-nodeid="11834">f(10) + 1 个 1 元得到 f(11)；</p>
</li>
<li data-nodeid="11835">
<p data-nodeid="11836">f(9) + 1 个 2 元得到 f(11)；</p>
</li>
<li data-nodeid="11837">
<p data-nodeid="11838">f(6) + 1 个 5 元得到 f(11)。</p>
</li>
</ul>
<h4 data-nodeid="11839">3. 递推关系</h4>
<p data-nodeid="11840">递推关系，一般需要通过<strong data-nodeid="12643">两次替换</strong>得到。</p>
<p data-nodeid="11841">最后一步，可以通过 3 个选项得到。哪一个选项才是最少的步骤呢？这个时候，我们可以采用一个 min 函数来从这 3 个选项中得到最小值。</p>
<blockquote data-nodeid="11842">
<p data-nodeid="11843">f(11) = min(f(11-1), f(11-2), f(11-5)) + 1</p>
</blockquote>
<p data-nodeid="11844">接下来，<strong data-nodeid="12651">第一次替换</strong>：只需要将 11 换成一个更普通的值，就可以得到更加通用的递推关系：</p>
<blockquote data-nodeid="11845">
<p data-nodeid="11846">f(x) = min(f(x-1), f(x-2), f(x-5)) + 1</p>
</blockquote>
<p data-nodeid="11847">当然，这里 [1, 2, 5] 我们依然使用的是输入示例，进行<strong data-nodeid="12662">第二次</strong>替换：</p>
<blockquote data-nodeid="11848">
<p data-nodeid="11849">f(x) = min(f(x-y), y in coins) + 1</p>
</blockquote>
<p data-nodeid="11850">写成伪代码就是：</p>
<pre class="lang-java" data-nodeid="11851"><code data-language="java">f(x) = inf
<span class="hljs-keyword">for</span> y in coins:
    f(x) = min(f(x), f(x-y) + <span class="hljs-number">1</span>)
</code></pre>
<h4 data-nodeid="11852">4. f(x) 的表达</h4>
<p data-nodeid="11853">接下来我们要做的就是在写代码的时候，如何表达 f(x)？</p>
<p data-nodeid="11854">这里有一个<strong data-nodeid="12678">小窍门</strong>。</p>
<blockquote data-nodeid="11855">
<p data-nodeid="11856">直接把 f(x) 当成一个哈希函数。那么 f 就是一个 HashMap。</p>
</blockquote>
<p data-nodeid="11857">对于大部分 DP 题目而言，如果用 HashMap 替换 f 函数都是可以工作的。如果遇到 f(x, y) 类似的函数，就需要用 Map&lt;Integer/<em data-nodeid="12693">x</em>/, Map&lt;Integer/<em data-nodeid="12694">y</em>/, Integer&gt;&gt; 这种嵌套的方式来表达 f(x, y)。</p>
<p data-nodeid="11858"><strong data-nodeid="12699">当然，有时候，用数组作为哈希函数是一种更加简单高效的做法</strong>。具体来说：</p>
<ul data-nodeid="11859">
<li data-nodeid="11860">
<p data-nodeid="11861">如果要表达的是一维的信息，就用一维数组 dp[] 表示 f(x)；</p>
</li>
<li data-nodeid="11862">
<p data-nodeid="11863">如果要表达的是二维的信息，就用二维数组 dp[][] 表示 f(x, y)</p>
</li>
</ul>
<p data-nodeid="11864">这就是为什么很多 DP 代码里面可以看到很多dp数组的原因。但是，现在你<strong data-nodeid="12720">要知道</strong>：</p>
<blockquote data-nodeid="11865">
<p data-nodeid="11866">用 dp[] 数组并不是求解 DP 问题的核心。</p>
</blockquote>
<p data-nodeid="11867"><strong data-nodeid="12729">因为，数组只是信息表达的一种方式。而题目总是千万变化的，有时候可能还需要使用其他数据结构来表达 f(x)、f(x, y) 这些信息</strong>。比如：</p>
<blockquote data-nodeid="11868">
<p data-nodeid="11869">f(x)、f(x, y) 里面的 x, y 都不是整数怎么办？是字符串怎么办？是结构体怎么办？</p>
</blockquote>
<p data-nodeid="11870">当然，就这个题而言，可以发现有两个特点：</p>
<p data-nodeid="11871">1）f(x) 中的 x 是一个整数；</p>
<p data-nodeid="11872">2）f(x) 要表达的信息是一维信息。</p>
<p data-nodeid="11873">那么，针对这道题而言言，我们可以使用一维数组，如下所示：</p>
<pre class="lang-java" data-nodeid="11874"><code data-language="java"><span class="hljs-keyword">int</span>[] dp = <span class="hljs-keyword">new</span> <span class="hljs-keyword">int</span>[amount + <span class="hljs-number">1</span>];
</code></pre>
<p data-nodeid="11875">数组下标 i 表示 x，而数组元素的值 dp[i] 就表示 f(x)。</p>
<p data-nodeid="11876">那么递推关系可以表示如下：</p>
<pre class="lang-java" data-nodeid="11877"><code data-language="java">dp[x] = inf;
<span class="hljs-keyword">for</span> y in coins:
  dp[x] = min(dp[x], dp[x-y] + <span class="hljs-number">1</span>);
</code></pre>
<h4 data-nodeid="11878">5. 初始条件与边界</h4>
<p data-nodeid="11879">那么，如何得到初始条件与边界呢？这里我分享一个<strong data-nodeid="12753">小技巧：</strong> 你从问题的起始输入开始调用这个递归函数，如果递归函数出现“<strong data-nodeid="12754">不正确/无法计算/越界</strong>”的情况，那么这就是你需要处理的初始条件和边界。</p>
<p data-nodeid="11880">比如，如果我们去调用以下两个递归函数。</p>
<ul data-nodeid="11881">
<li data-nodeid="11882">
<p data-nodeid="11883">coinChange(0)：可以发现给定 0 元的时候，dp[amount-x] 会导致数组越界，因此需要<strong data-nodeid="12769">特别处理</strong>dp[0]。</p>
</li>
<li data-nodeid="11884">
<p data-nodeid="11885">coinChange(-1) 或者 coinChange(-2) 的调用也是会遇到数组越界，说明这些情况都需要做<strong data-nodeid="12775">特别处理</strong>。</p>
</li>
</ul>
<p data-nodeid="11886"><strong data-nodeid="12784">那么什么情况作为初始条件</strong>？<strong data-nodeid="12785">什么情况作为边界</strong>？答案就是：</p>
<ul data-nodeid="11887">
<li data-nodeid="11888">
<p data-nodeid="11889">如果结果本身的存放不越界，只是计算过程中出现越界，那么应该作为初始条件。比如 dp[0]、dp[1]；</p>
</li>
<li data-nodeid="11890">
<p data-nodeid="11891">如果结果本身的存放是越界的，那么需要作为边界来处理，比如 dp[-1]。</p>
</li>
</ul>
<p data-nodeid="11892">当然，就这道题而言，初始条件是 dp[0] = 0，因为当只有 0 元钱需要兑换的时候，应该是只需 0 个硬币。</p>
<h4 data-nodeid="11893">6. 计算顺序</h4>
<p data-nodeid="11894">说来有趣，计算顺序最简单，我们只需要在初始条件的基础上使用<strong data-nodeid="12813">正向推导多走两步</strong>可以了。比如：</p>
<blockquote data-nodeid="11895">
<p data-nodeid="11896">初始条件：dp[0] = 0</p>
</blockquote>
<p data-nodeid="11897">那么接下来的示例中的输入：coins[] = [1, 2, 5]。我们已经知道 dp[0] = 0，再加上可以做的 3 个选项，那么可以得到：</p>
<p data-nodeid="11898">dp[1] = dp[0] + 1 元硬币 = 1</p>
<p data-nodeid="11899">dp[2] = dp[0] + 2 元硬币 = 1</p>
<p data-nodeid="11900">dp[5] = dp[0] + 5 元硬币 = 1</p>
<p data-nodeid="11901">到这里，递推关系好像还没有用到。那什么时候用呢？我们来看下面两种情况：</p>
<ul data-nodeid="11902">
<li data-nodeid="11903">
<p data-nodeid="11904">如下图所示，第一种情况，dp[5] 可以直接通过 dp[0] 得到，值为 1。</p>
</li>
</ul>
<p data-nodeid="11905"><img src="https://s0.lgstatic.com/i/image6/M00/37/60/CioPOWB2zBuAOaffAAB34BpuEyM913.png" alt="Drawing 0.png" data-nodeid="12870"></p>
<ul data-nodeid="11906">
<li data-nodeid="11907">
<p data-nodeid="11908">如下图所示，第二种，dp[5] 可以通过 dp[3] 得到，值为 3。</p>
</li>
</ul>
<p data-nodeid="11909"><img src="https://s0.lgstatic.com/i/image6/M00/37/60/CioPOWB2zCaAHlLsAAB8MadAE-U569.png" alt="Drawing 1.png" data-nodeid="12882"></p>
<p data-nodeid="11910">此时可以发现，判断具体取哪个值时，就需要用到前面的递推关系了。</p>
<blockquote data-nodeid="11911">
<p data-nodeid="11912">f(x) = min(f(x-1), f(x-2), f(x-5)) + 1</p>
</blockquote>
<p data-nodeid="11913">我们只需要取较小的值就可以了。</p>
<p data-nodeid="11914">【<strong data-nodeid="12891">代码</strong>】到这里，你应该可以写出 DP 的代码了：</p>
<pre class="lang-java" data-nodeid="11915"><code data-language="java"><span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">Solution</span>
</span>{
  <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">int</span> <span class="hljs-title">coinChange</span><span class="hljs-params">(<span class="hljs-keyword">int</span>[] coins, <span class="hljs-keyword">int</span> amount)</span>
  </span>{
    <span class="hljs-comment">// 没有解的时候，设置一个较大的值</span>
    <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> INF = Integer.MAX_VALUE / <span class="hljs-number">4</span>;
    <span class="hljs-keyword">int</span>[] dp = <span class="hljs-keyword">new</span> <span class="hljs-keyword">int</span>[amount + <span class="hljs-number">1</span>];
    <span class="hljs-comment">// 一开始给所有的数设置为不可解。</span>
    <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> i = <span class="hljs-number">1</span>; i &lt;= amount; i++) {
      dp[i] = INF;
    }
    <span class="hljs-comment">// DP的初始条件</span>
    dp[<span class="hljs-number">0</span>] = <span class="hljs-number">0</span>;
    <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> i = <span class="hljs-number">0</span>; i &lt; amount; i++) {
      <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> y : coins) {
        <span class="hljs-comment">// 注意边界的处理，不要越界</span>
        <span class="hljs-keyword">if</span> (y &lt;= amount &amp;&amp; i + y &lt; amount + <span class="hljs-number">1</span> &amp;&amp; i + y &gt;= <span class="hljs-number">0</span>) {
          <span class="hljs-comment">// 正向推导时的递推公式!</span>
          dp[i + y] = Math.min(dp[i + y], dp[i] + <span class="hljs-number">1</span>);
        }
      }
    }
    <span class="hljs-keyword">return</span> dp[amount] &gt;= INF ? -<span class="hljs-number">1</span> : dp[amount];
  }
}
</code></pre>
<blockquote data-nodeid="11916">
<p data-nodeid="11917">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/322.%E9%9B%B6%E9%92%B1%E5%85%91%E6%8D%A2.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="12895">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/322.%E9%9B%B6%E9%92%B1%E5%85%91%E6%8D%A2.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="12899">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/322.%E9%9B%B6%E9%92%B1%E5%85%91%E6%8D%A2.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="12903">Python</a></p>
</blockquote>
<p data-nodeid="11918"><strong data-nodeid="12910">复杂度分析</strong>：一共两层循环，外层需要循环 O(Amount) 次，内层需要循环 O(N) 次（如果有 N 种硬币）。那么时间复杂度为 O(Amount * N)。由于申请了数组，那么空间复杂度为 O(Amount)。</p>
<p data-nodeid="11919">这里我利用一个例题，深入地讲解了 DP 的破题法的几个步骤。后面我将利用这个方法带你依次切开每一道难啃的 DP 题。</p>
<p data-nodeid="11920">这里，我再分享一个小技巧，需要注意：</p>
<blockquote data-nodeid="11921">
<p data-nodeid="11922">当求最小值的时候，我们往往将不可能的情况设置为 Integer.MAX_VALUE / 4。</p>
</blockquote>
<p data-nodeid="11923">因为如果设置为 Integer.MAX_VALUE，那么一旦涉及加法，立马就溢出了，导致程序出错。所以我们尽量设置一个足够大的数，避免进行加法的时候溢出。</p>
<p data-nodeid="11924">这里我已经将 DP 的思路整理成如下图中展示的 6 步。尽管我现在处理 DP 问题已经很熟练了，但有时候，碰到一些特别难处理的 DP 题目，依然会回到这 6 步分析法，一步一步踏踏实实地分析。</p>
<p data-nodeid="11925"><img src="https://s0.lgstatic.com/i/image6/M01/37/58/Cgp9HWB2zDKAQUFhAADATI1rcXE556.png" alt="Drawing 2.png" data-nodeid="12922"></p>
<h3 data-nodeid="11926">DP 的分类</h3>
<p data-nodeid="11927">经过前面的讨论，我们学会了 DP 的通用解法，不过 DP 实际上还可以分成很多种类别。比如：</p>
<ul data-nodeid="11928">
<li data-nodeid="11929">
<p data-nodeid="11930">线性 DP</p>
</li>
<li data-nodeid="11931">
<p data-nodeid="11932">区间 DP</p>
</li>
<li data-nodeid="11933">
<p data-nodeid="11934">背包 DP</p>
</li>
<li data-nodeid="11935">
<p data-nodeid="11936">树形 DP</p>
</li>
<li data-nodeid="11937">
<p data-nodeid="11938">状态压缩 DP</p>
</li>
</ul>
<p data-nodeid="11939">在练习和准备面试的时候，多看看这些题型，对面试会很有帮助。下面我们一个一个介绍。</p>
<h4 data-nodeid="11940">线性 DP</h4>
<p data-nodeid="33283" class="te-preview-highlight">我们在读书的时候，遇到的很多 DP 题目，比如最长公共子序列、最长递增子序列等，这类题目实际上都是线性 DP。不过今天我们不再介绍这类经典的 DP 题目，而是介绍一些在面试中经常出现的<strong data-nodeid="33289">线性 DP</strong> 题目。</p>

<h4 data-nodeid="11942">例 1：打劫</h4>
<p data-nodeid="11943">【<strong data-nodeid="12944">题目</strong>】你是一个专业的小偷，计划去沿街的住户家里偷盗。每间房内都藏有一定的现金，影响你偷盗的唯一制约因素就是相邻的房屋装有相互连通的防盗系统，如果两间相邻的房屋在同一晚上被小偷闯入，系统会自动报警。给定一个代表每个房屋存放金额的非负整数数组，要求你计算不触动警报装置的情况下 ，一夜之内能够偷窃到的最高金额。</p>
<p data-nodeid="11944">输入：nums = [1,2,3,1]</p>
<p data-nodeid="11945">输出：4</p>
<p data-nodeid="11946">解释：偷窃 nums[0] 号房屋 （金额 = 1），然后偷窃 nums[2]号房屋（金额 = 3）。偷窃到的最高金额 = 1 + 3 = 4 。</p>
<p data-nodeid="11947">【<strong data-nodeid="12964">分析</strong>】接下来，我们就照着 DP 的 6 步分析法（千万别顺着题意去想要偷那些房间！！）。我们把思维放慢，一步一步分析。</p>
<h4 data-nodeid="11948">1. 最后一步</h4>
<p data-nodeid="11949">就这道题而言，最后一步就是处理第 N-1 个房间（我们假设一共有 N 个房间，并且从 0 开始）。</p>
<p data-nodeid="11950">那么第 N-1 个房间，有两个选项。</p>
<ul data-nodeid="11951">
<li data-nodeid="11952">
<p data-nodeid="11953">偷：如果要偷第 N-1 个房间，那么收益就是处理前 N-3 个房间之后，再偷第 N-1 房间。</p>
</li>
<li data-nodeid="11954">
<p data-nodeid="11955">不偷：那么只需要处理到第 N-2 个房间，那么收益就是处理前 N-2 个房间之后的收益。</p>
</li>
</ul>
<h4 data-nodeid="11956">2. 子问题</h4>
<p data-nodeid="11957">最后一步的 2 个选项中都有未知项，我们可以将它们展开为子问题：</p>
<ul data-nodeid="11958">
<li data-nodeid="11959">
<p data-nodeid="11960">处理完 [0, ..., N-3] 之后，最大收益是多少？</p>
</li>
<li data-nodeid="11961">
<p data-nodeid="11962">处理完 [0, ..., N-2] 之后，最大收益是多少？</p>
</li>
</ul>
<p data-nodeid="11963">下面我们可以统一问题的表示：</p>
<blockquote data-nodeid="11964">
<p data-nodeid="11965">f(x) 表示处理完 [0, ..., x] 这些房间之后的<strong data-nodeid="12996">最高收益</strong>。</p>
</blockquote>
<h4 data-nodeid="11966">3. 递推关系</h4>
<p data-nodeid="11967">统一问题的表示之后，首先来表示一下最后一步：</p>
<blockquote data-nodeid="11968">
<p data-nodeid="11969">f(N-1) = max(f(N-2), f(N-3) + nums[N-1])</p>
</blockquote>
<p data-nodeid="11970">这里需要采用替换法，将 N-1 换为 x。可以得到：</p>
<blockquote data-nodeid="11971">
<p data-nodeid="11972">f(x) = max(f(x-1), f(x-2) + nums[x])</p>
</blockquote>
<h4 data-nodeid="11973">4. f(x) 的表达</h4>
<p data-nodeid="11974">这里 x 表示的是原数组 [0, ..., x] 这个区间范围。由于所有的 x 表示的区间都是从 0 开始的，所以这个区间的起始点信息没有必要保留，因此只需要保存区间端点 x。我们发现：</p>
<ul data-nodeid="11975">
<li data-nodeid="11976">
<p data-nodeid="11977">x 是个整数；</p>
</li>
<li data-nodeid="11978">
<p data-nodeid="11979">x 的范围刚好是 nums 数组的长度。</p>
</li>
</ul>
<p data-nodeid="11980">尽管 f(x) 可以用哈希来表示，但如果用数组来表达这个函数映射关系，更加直接和高效。因此，我们也用 dp[] 数组来表达 f(x)。并且利用元素 i 表示 x，可以让 i 与 nums 数组的下标对应起来。</p>
<h4 data-nodeid="11981">5. 初始条件与边界</h4>
<p data-nodeid="11982"><strong data-nodeid="13041">初始条件</strong>：首先我们看“<strong data-nodeid="13042">无法计算/越界</strong>”的情况：</p>
<pre class="lang-java" data-nodeid="11983"><code data-language="java">dp[<span class="hljs-number">0</span>] = max(dp[<span class="hljs-number">0</span>-<span class="hljs-number">1</span>], dp[<span class="hljs-number">0</span>-<span class="hljs-number">2</span>] + nums[<span class="hljs-number">0</span>]); <span class="hljs-comment">// &lt;-- 越界!</span>
dp[<span class="hljs-number">1</span>] = max(dp[<span class="hljs-number">1</span>-<span class="hljs-number">1</span>], dp[<span class="hljs-number">1</span>-<span class="hljs-number">2</span>] + nums[<span class="hljs-number">1</span>]); <span class="hljs-comment">// &lt;-- 越界 </span>
dp[<span class="hljs-number">2</span>] = max(dp[<span class="hljs-number">2</span>-<span class="hljs-number">1</span>], dp[<span class="hljs-number">2</span>-<span class="hljs-number">2</span>] + nums[<span class="hljs-number">2</span>]);
</code></pre>
<p data-nodeid="11984">我们发现 dp[0], dp[1] 会在计算过程中出现越界，所以需要优先处理这两项。</p>
<ul data-nodeid="11985">
<li data-nodeid="11986">
<p data-nodeid="11987">dp[0]：当只有 nums[0] 可以偷的时候，其值肯定为 max(0, nums[0])。</p>
</li>
</ul>
<blockquote data-nodeid="11988">
<p data-nodeid="11989">注意陷阱，有的题可能会给你的带负数值的情况，不要直接写成 nums[0]。</p>
</blockquote>
<ul data-nodeid="11990">
<li data-nodeid="11991">
<p data-nodeid="11992">dp[1]：当有 0 号，1 号房间可以偷的时候，由于不能连续偷盗，那么只需要在 0、nums[0]、nums[1] 里面选最大值就可以了。所以 dp[1] = max(0, nums[0], nums[1])。</p>
</li>
</ul>
<p data-nodeid="11993"><strong data-nodeid="13099">边界</strong>：要保证不能越过数组的边界！</p>
<h4 data-nodeid="11994">6. 计算顺序</h4>
<p data-nodeid="11995">拿到初始条件与边界之后，只需要再多走两步，就知道代码怎么写了。接下来我们开始求解 dp[2], dp[3]。</p>
<pre class="lang-java" data-nodeid="11996"><code data-language="java">dp[<span class="hljs-number">2</span>] = max(dp[<span class="hljs-number">2</span>-<span class="hljs-number">1</span>], dp[<span class="hljs-number">2</span>-<span class="hljs-number">2</span>] + nums[<span class="hljs-number">2</span>]);
dp[<span class="hljs-number">3</span>] = max(dp[<span class="hljs-number">3</span>-<span class="hljs-number">1</span>], dp[<span class="hljs-number">3</span>-<span class="hljs-number">2</span>] + nums[<span class="hljs-number">3</span>]);
</code></pre>
<p data-nodeid="11997">【<strong data-nodeid="13117">代码</strong>】利用前面分析过的初始条件和递推关系，可以写出如下代码：</p>
<pre class="lang-java" data-nodeid="11998"><code data-language="java"><span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">Solution</span>
</span>{
  <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">int</span> <span class="hljs-title">rob</span><span class="hljs-params">(<span class="hljs-keyword">int</span>[] nums)</span>
  </span>{
    <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> N = nums == <span class="hljs-keyword">null</span> ? <span class="hljs-number">0</span> : nums.length;
    <span class="hljs-keyword">if</span> (N &lt;= <span class="hljs-number">0</span>) {
      <span class="hljs-keyword">return</span> <span class="hljs-number">0</span>;
    }
    <span class="hljs-keyword">int</span>[] dp = <span class="hljs-keyword">new</span> <span class="hljs-keyword">int</span>[N];
    dp[<span class="hljs-number">0</span>] = Math.max(<span class="hljs-number">0</span>, nums[<span class="hljs-number">0</span>]);
    <span class="hljs-keyword">if</span> (N == <span class="hljs-number">1</span>) {
      <span class="hljs-keyword">return</span> dp[<span class="hljs-number">0</span>];
    }
    dp[<span class="hljs-number">1</span>] = Math.max(<span class="hljs-number">0</span>, Math.max(nums[<span class="hljs-number">0</span>], nums[<span class="hljs-number">1</span>]));
    <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> i = <span class="hljs-number">2</span>; i &lt; N; i++) {
      dp[i] = Math.max(dp[i - <span class="hljs-number">1</span>], dp[i - <span class="hljs-number">2</span>] + nums[i]);
    }
    <span class="hljs-keyword">return</span> dp[N - <span class="hljs-number">1</span>];
  }
}
</code></pre>
<blockquote data-nodeid="11999">
<p data-nodeid="12000">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/198.%E6%89%93%E5%AE%B6%E5%8A%AB%E8%88%8D.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13121">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/198.%E6%89%93%E5%AE%B6%E5%8A%AB%E8%88%8D.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13125">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/198.%E6%89%93%E5%AE%B6%E5%8A%AB%E8%88%8D.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13129">Python</a></p>
</blockquote>
<p data-nodeid="12001"><strong data-nodeid="13134">复杂度分析</strong>：时间复杂度 O(N)，空间复杂度 O(N)。</p>
<p data-nodeid="12002">【<strong data-nodeid="13140">小结</strong>】通过 6 步分析法，我们很快就搞定来这道经典的 DP 题目。</p>
<p data-nodeid="12003">这道题还有一个小变形，我想你可以尝试求解下面的练习题 1。</p>
<p data-nodeid="12004"><strong data-nodeid="13146">练习题 1</strong>：你是一个专业的小偷，计划偷窃沿街的房屋，每间房内都藏有一定的现金。这个地方的所有房屋都围成一圈 ，这意味着第一个房屋和最后一个房屋是紧挨着的。同时，相邻的房屋装有相互连通的防盗系统，如果两间相邻的房屋在同一晚上被小偷闯入，系统会自动报警 。给定一个代表每个房屋存放金额的非负整数数组，计算你在不触动警报装置的情况下 ，能够偷窃到的最高金额。</p>
<p data-nodeid="12005">输入：nums = [2,3,2]</p>
<p data-nodeid="12006">输出：3</p>
<p data-nodeid="12007">解释：你不能先偷窃 nums[0] 号房屋（金额 = 2），然后偷窃 nums[2] 号房屋（金额 = 2）, 因为他们是相邻的。最大收益是偷取nums[1]=3。</p>
<blockquote data-nodeid="12008">
<p data-nodeid="12009">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/213.%E6%89%93%E5%AE%B6%E5%8A%AB%E8%88%8D-ii.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13168">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/213.%E6%89%93%E5%AE%B6%E5%8A%AB%E8%88%8D-ii.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13172">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/213.%E6%89%93%E5%AE%B6%E5%8A%AB%E8%88%8D-ii.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13176">Python</a></p>
</blockquote>
<h4 data-nodeid="12010">区间 DP</h4>
<p data-nodeid="12011">还有一类 DP 题目，看起来像是一个线性的数组，但是如果仔细分析，就会发现要处理的却是一个一个的子区间。下面我们依然通过一道例题，使用 6 步破题法进行求解。</p>
<h4 data-nodeid="12012">例 2：扰乱字符串</h4>
<p data-nodeid="12013">【<strong data-nodeid="13185">题目</strong>】使用下面描述的算法可以扰乱字符串 s 得到字符串 t 。</p>
<p data-nodeid="12014">Step 1. 如果字符串的长度为 1 ，算法停止。</p>
<p data-nodeid="12015">Step 2. 如果字符串的长度 &gt; 1 ，执行下述步骤：</p>
<ul data-nodeid="12016">
<li data-nodeid="12017">
<p data-nodeid="12018">在一个随机下标处将字符串分割成两个<strong data-nodeid="13193">非空</strong>的子字符串。即如果已知字符串 s ，则可以将其分成两个子字符串 x 和 y ，且满足 s = x + y 。</p>
</li>
<li data-nodeid="12019">
<p data-nodeid="12020">随机决定是“交换两个子字符串”还是“保持这两个子字符串的顺序不变”。即在执行这一步骤之后，s 可能是 s = x + y 或者 s = y + x 。</p>
</li>
</ul>
<p data-nodeid="12021">Step 3. 在 x 和 y 这两个<strong data-nodeid="13200">子字符串</strong>上继续从 Step 1 开始递归执行此算法。</p>
<p data-nodeid="12022">有两个长度相等的字符串 s1 和 s2，判断 s2 是否是 s1 的扰乱字符串。如果是，返回 true ；否则，返回 false 。</p>
<p data-nodeid="12023">输入：s1 = "great", s2 = "rgeat"</p>
<p data-nodeid="12024">输出：true</p>
<p data-nodeid="12025">解释：经过如下操作即可从 s1 得到 s2：</p>
<p data-nodeid="12026"><img src="https://s0.lgstatic.com/i/image6/M01/37/58/Cgp9HWB2zFWABT97AABr3D8VE1U754.png" alt="Drawing 3.png" data-nodeid="13214"></p>
<p data-nodeid="12027">【<strong data-nodeid="13220">分析</strong>】当拿到这个题目的时候，我们看到 true/false，可以联想到这应该是个 DP 题的信号。因为题目也没有要求输出具体怎么操作。</p>
<p data-nodeid="12028">因此，你可以由此想到使用 6 步破题法，而不是立马跟着题意开始切分字符串。</p>
<h4 data-nodeid="12029">1. 最后一步</h4>
<p data-nodeid="12030">首先看最后一步，题目中给定两个字符串 s1，s2，那么 s1 在最后一步操作之后是否可以得到 s2 呢？（假设 s1 的长度为 N，下标从 0 开始）</p>
<p data-nodeid="12031">我们分析一下，s1 在操作的时候，可以有以下步骤：</p>
<p data-nodeid="12032">1）在位置 p 处进行切分，将 s1 切分为 x = [0, ... p] 和 y = [p + 1, N)；</p>
<p data-nodeid="12033">2）然后再分别处理 s1 = x + y 和 s1 = y + x 能否拼成 s2。</p>
<p data-nodeid="12034">其中 p 的取值范围是 [0 ~ N-2]，所以一共有 N-1 种选项。</p>
<p data-nodeid="12035">但是这样操作并不能降低处理的数据规模，无法将一个大问题切分为更多的小问题，也就是说我们只是找到了原始问题的一个等价问题。</p>
<p data-nodeid="12036">这说明我们最后一步找得不准！需要重新思考。如果 s1 是 s2 的扰乱字符串，那么在最后一步的时候，存在以下 2 种情况（判断的时候，只需要判断对应颜色相同的部分）：</p>
<p data-nodeid="12037"><img src="https://s0.lgstatic.com/i/image6/M01/37/58/Cgp9HWB2zGaANoGhAAeB2NdVgKc054.png" alt="Drawing 4.png" data-nodeid="13246"></p>
<p data-nodeid="12038">Case 1. 找到某个位置，将 s1, s2 都切成两半，其中 s1 = x + y，而 s2 = c + d，那么我们只需要保证 x 是 c 的扰乱字符串，y 是 d 的扰乱字符串。</p>
<p data-nodeid="12039"><img src="https://s0.lgstatic.com/i/image6/M00/37/61/CioPOWB2zGyAOitSAAeBHGBc82w657.png" alt="Drawing 5.png" data-nodeid="13250"></p>
<p data-nodeid="12040">Case 2. 找到某个位置，切分后，使得 s1 = x + y，s2 = c + d，并且 x 是 d 的扰乱字符串，而 y 是 c 的扰乱字符串。</p>
<p data-nodeid="12041">我们发现，找准最后一步之后，原始问题的规模减小了很多。</p>
<h4 data-nodeid="12042">2. 子问题</h4>
<p data-nodeid="12043">起初要求解的问题是：</p>
<blockquote data-nodeid="12044">
<p data-nodeid="12045">判断 s1 是不是 s2 的扰乱字符串。</p>
</blockquote>
<p data-nodeid="12046">经过最后一步的处理之后，需要处理的问题被拆分为两种情况：</p>
<ul data-nodeid="12047">
<li data-nodeid="12048">
<p data-nodeid="12049">Case 1. s1 = x + y, s2 = c + d，判断 &lt;x, c&gt; 和 &lt;y,d&gt; 是不是扰乱字符串；</p>
</li>
<li data-nodeid="12050">
<p data-nodeid="12051">Case 2. s1 = x + y, s2 = c + d，判断 &lt;x, d&gt; 和 &lt; y, c&gt; 是不是扰乱字符串。</p>
</li>
</ul>
<p data-nodeid="12052">到这里，我们可以将原问题表示如下：</p>
<blockquote data-nodeid="12053">
<p data-nodeid="12054">f(s1, s2) = true，表示 s1 是 s2 的扰乱字符串，false 则表示不是。</p>
</blockquote>
<p data-nodeid="12055">那么最后一步就可以表示为：</p>
<blockquote data-nodeid="12056">
<p data-nodeid="12057">f(s1, s2) = f(x, c) &amp;&amp; f(y, d) || f(x, d) &amp;&amp; f(y, c)<br>
其中 s1 = x + y, s2 = c + d</p>
</blockquote>
<h4 data-nodeid="12058">3. 递推关系式</h4>
<p data-nodeid="12059">我们可以用<strong data-nodeid="13325">伪代码表示</strong>一下这个<strong data-nodeid="13326">递推关系式</strong>，代码如下：</p>
<pre class="lang-java" data-nodeid="12060"><code data-language="java"><span class="hljs-function"><span class="hljs-keyword">boolean</span> <span class="hljs-title">isScramble</span><span class="hljs-params">(s1, s2)</span> </span>{
  N = len(s1)
  f(s1, s2) = <span class="hljs-keyword">false</span>;
  <span class="hljs-function"><span class="hljs-keyword">for</span> cutPos in <span class="hljs-title">range</span><span class="hljs-params">(<span class="hljs-number">0</span>, N)</span> </span>{
    <span class="hljs-comment">// 第一种切分方式</span>
    <span class="hljs-comment">// s1 = x + y</span>
    x = s1[<span class="hljs-number">0</span>:cutPos]
    y = s1[cutPos+<span class="hljs-number">1</span>, N)
    <span class="hljs-comment">// s2 = c + d</span>
    c = s2[<span class="hljs-number">0</span>:cutPos]
    d = s2[cutPos+<span class="hljs-number">1</span>,N)
    <span class="hljs-comment">// 看第一种是否满足条件</span>
    f(s1,s2) = f(x,c) &amp;&amp; f(y,d);
    <span class="hljs-keyword">if</span> (f(s1,s2)) <span class="hljs-keyword">break</span>;
    <span class="hljs-comment">// 第二种切分方式</span>
    c = s2[<span class="hljs-number">0</span>:N-cutPos-<span class="hljs-number">1</span>]
    d = s2[N-cutPos:N)
    <span class="hljs-comment">// 看第二种是否满足条件 </span>
    f(s1, s2) = f(x,d) &amp;&amp; f(y, c);
    <span class="hljs-keyword">if</span> (f(s1,s2)) <span class="hljs-keyword">break</span>;
  }
}
</code></pre>
<h4 data-nodeid="12061">4. f(x) 的表示</h4>
<p data-nodeid="12062">接下来，我们需要看一下 f(s1, s2) 的表示。</p>
<p data-nodeid="12063">如果简单一点，我们当然可以使用 HashMap&lt;String,HashMap&lt;String, Boolean&gt;&gt; 双层哈希函数来处理（难办一点，可以用 s1+"#"+s2 作为 key，然后只使用一层哈希函数）。</p>
<p data-nodeid="12064">但是就这道题而言，我们还有更好的表达方式。观察题目可以发现：子问题里面的 &lt;x, y&gt; 和 &lt;c, d&gt; 都是原字符串的子串。</p>
<pre class="lang-java" data-nodeid="12065"><code data-language="java">    <span class="hljs-comment">// s1 = x + y</span>
    x = s1[<span class="hljs-number">0</span>:cutPos]
    y = s1[cutPos+<span class="hljs-number">1</span>, N)
    <span class="hljs-comment">// s2 = c + d</span>
    c = s2[<span class="hljs-number">0</span>:cutPos]
    d = s2[cutPos+<span class="hljs-number">1</span>,N)
</code></pre>
<p data-nodeid="12066">那么可以用起始位置与终止位置来表示：</p>
<pre class="lang-java" data-nodeid="12067"><code data-language="java">f(s1, s2) = f([s1_start, s1_end], [s2_start, s2_end])
</code></pre>
<p data-nodeid="12068">到这里，我们可以认为信息已经变成了 f(s1_start, s1_end, s2_start, s2_end)。针对这个 4 维的信息，可以通过建立一个 4 维数组来处理。比如：dp[s1_start][s1_end][s2_start][s2_end]。</p>
<p data-nodeid="12069">但是，如果 s1 字符串要是 s2 字符串的扰动字符串，那么这两者的长度应该是相等的。因此，应该满足如下的关系：</p>
<blockquote data-nodeid="12070">
<p data-nodeid="12071">s1_end - s1_start = s2_end - s2_start</p>
</blockquote>
<p data-nodeid="12072">也就是说，两个字符串的长度总是相等的，那么我们可以把 4 维的信息压缩为 3 维：</p>
<ul data-nodeid="12073">
<li data-nodeid="12074">
<p data-nodeid="12075">s1_start</p>
</li>
<li data-nodeid="12076">
<p data-nodeid="12077">s2_start</p>
</li>
<li data-nodeid="12078">
<p data-nodeid="12079">length</p>
</li>
</ul>
<p data-nodeid="12080">因为 s1_end = s1_start + length，而 s2_end = s2_start + length。也就是说，3 维的信息与 4 维的信息完全是等价的。那么，我们可以把原来 4 维的数组 dp，更改为 3 维的数组 dp[s1_start][s2_start][length]。</p>
<h4 data-nodeid="12081">5. 初始条件与边界</h4>
<p data-nodeid="12082">虽然有了第 3 步中的递推关系，但是我们很快可以发现，有那么几项需要提前处理，否则无法计算结果。</p>
<ul data-nodeid="12083">
<li data-nodeid="12084">
<p data-nodeid="12085">都是空字符串：s1 = empty，s2 = empty。（就本题而言，题目已给定了不会出现空字符串）。</p>
</li>
<li data-nodeid="12086">
<p data-nodeid="12087">两个字符串长度都是 1：len(s1) = 1, len(s2) = 1。</p>
</li>
</ul>
<p data-nodeid="12088">还有一些可以提前处理的操作，比如 s1 与 s2 的字符串长度不相等，这种直接可以返回 False，因为扰动字符串需要两个字符串长度相等。</p>
<h4 data-nodeid="12089">6. 计算顺序</h4>
<p data-nodeid="12090">我们在初始条件中，已经处理了长度为 0（空字符串），长度为 1 的子串的情况。如果再<strong data-nodeid="13450">接着走两步</strong>，那么应该再去计算长度为 2 的任意子串是不是相互为扰动字符串。然后再计算长度为 3，长度为 4，直到长度为 N 的子串。</p>
<p data-nodeid="12091">可以肯定，当计算到长度为 N 的时候，我们就能得到最终解。</p>
<p data-nodeid="12092">【<strong data-nodeid="13457">分析</strong>】经过了前面的 DP 分析 6 步法，现在应该可以写出如下代码了（解析在注释里）：</p>
<pre class="lang-java" data-nodeid="12093"><code data-language="java"><span class="hljs-function"><span class="hljs-keyword">boolean</span> <span class="hljs-title">isScramble</span><span class="hljs-params">(String s1, String s2)</span> </span>{
  <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> s1len = s1 == <span class="hljs-keyword">null</span> ? <span class="hljs-number">0</span> : s1.length();
  <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> s2len = s2 == <span class="hljs-keyword">null</span> ? <span class="hljs-number">0</span> : s2.length();
  <span class="hljs-keyword">if</span> (s1len != slen2) {
    <span class="hljs-keyword">return</span> <span class="hljs-keyword">false</span>;
  }
  <span class="hljs-comment">// N表示后面字符串的长度</span>
  <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> N = s1len;
  <span class="hljs-keyword">boolean</span>[][][] dp = <span class="hljs-keyword">new</span> <span class="hljs-keyword">boolean</span>[N + <span class="hljs-number">1</span>][N + <span class="hljs-number">1</span>][N + <span class="hljs-number">1</span>];
  <span class="hljs-comment">// 初始条件是长度为1的情况</span>
  <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> s1start = <span class="hljs-number">0</span>; s1start &lt; N; s1start++) {
    <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> s2start = <span class="hljs-number">0</span>; s2start &lt; N; s2start++) {
      dp[s1start][s2start][<span class="hljs-number">1</span>] = s1.charAt(s1start) == s2.charAt(s2start);
    }
  }
  <span class="hljs-comment">// 那么再通过递推公式计算其他长度的情况</span>
  <span class="hljs-comment">// 子串的截取，这里我们采用开闭原则[start, end)</span>
  <span class="hljs-comment">// 也就是说，end是可以取到N的。</span>
  <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> len = <span class="hljs-number">2</span>; len &lt;= N; len++) {
    <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> s1start = <span class="hljs-number">0</span>; s1start + len &lt;= N; s1start++) {
      <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> s2start = <span class="hljs-number">0</span>; s2start + len &lt;= N; s2start++) {
        <span class="hljs-comment">// 现在我们需要计算两个子串</span>
        <span class="hljs-comment">// X = s1[s1start, s1start+len)</span>
        <span class="hljs-comment">// Y = s2[s2start, s2start+len)</span>
        <span class="hljs-comment">// 这两个子串是否是扰动字符串</span>
        <span class="hljs-comment">// 那么根据递推公式，我们需要找切分点</span>
        <span class="hljs-comment">// 切分子串的时候</span>
        <span class="hljs-comment">// X 切分为 X = a + b, 分为左右两半</span>
        <span class="hljs-comment">// Y 切分为 Y = c + d，同样分为左右两半</span>
        <span class="hljs-comment">// 左边的长度为leftLen, 右边的长度就是len - leftLen</span>
        <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> leftLen = <span class="hljs-number">1</span>; leftLen &lt; len &amp;&amp; !dp[s1start][s2start][len];
             leftLen++) {
          <span class="hljs-comment">// 第一种切分，case 1</span>
          <span class="hljs-comment">// X = a + b, Y = c + d</span>
          <span class="hljs-comment">// [s1start, s1start + leftLen) &lt;- a</span>
          <span class="hljs-comment">// [s2start, s2start + leftLen) &lt;- c</span>
          <span class="hljs-comment">// [s1start + leftLen, s1start + len) &lt;- b</span>
          <span class="hljs-comment">// [s2start + leftLen, s2start + len) &lt;- d</span>
          <span class="hljs-keyword">boolean</span> c1 =
            <span class="hljs-comment">// &lt;a, c&gt;</span>
            dp[s1start][s2start][leftLen] &amp;&amp;
            <span class="hljs-comment">// &lt;b, d&gt;</span>
            dp[s1start + leftLen][s2start + leftLen][len - leftLen];
          <span class="hljs-comment">// 第2种切分</span>
          <span class="hljs-comment">// X = a + b, Y = c + d</span>
          <span class="hljs-comment">// [s1start, s1start + leftLen) &lt;- a</span>
          <span class="hljs-comment">// [s2start + len - leftLen, s2start + len) &lt;- d</span>
          <span class="hljs-comment">// [s1start + leftLen, s1start + len) &lt;- b</span>
          <span class="hljs-comment">// [s2start, s2start + len - leftLen) &lt;- c</span>
          <span class="hljs-keyword">boolean</span> c2 =
            <span class="hljs-comment">// &lt;a, d&gt;</span>
            dp[s1start][s2start + len - leftLen][leftLen] &amp;&amp;
            <span class="hljs-comment">// &lt;b, c&gt;</span>
            dp[s1start + leftLen][s2start][len - leftLen];
          dp[s1start][s2start][len] = c1 || c2;
        }
      }
    }
  }
  <span class="hljs-keyword">return</span> dp[<span class="hljs-number">0</span>][<span class="hljs-number">0</span>][N];
}
</code></pre>
<blockquote data-nodeid="12094">
<p data-nodeid="12095">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/87.%E6%89%B0%E4%B9%B1%E5%AD%97%E7%AC%A6%E4%B8%B2.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13461">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/87.%E6%89%B0%E4%B9%B1%E5%AD%97%E7%AC%A6%E4%B8%B2.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13465">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/87.%E6%89%B0%E4%B9%B1%E5%AD%97%E7%AC%A6%E4%B8%B2.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13469">Python</a></p>
</blockquote>
<p data-nodeid="12096"><strong data-nodeid="13482">复杂度分析</strong>：时间复杂度 O(N<sup>4</sup>)，空间复杂度O(N<sup>3</sup>)。</p>
<p data-nodeid="12097">【<strong data-nodeid="13488">小结</strong>】除了前面的 DP 6 步破题法之外，这道题的重点考点在于：</p>
<ul data-nodeid="12098">
<li data-nodeid="12099">
<p data-nodeid="12100">最后一步的正确理解与选择——要保证最后一步得到的<strong data-nodeid="13493">子问题是收缩的；</strong></p>
</li>
<li data-nodeid="12101">
<p data-nodeid="12102">哈希函数空间的优化——我们一步一步推导了从哈希函数到 4 维数组，最后到 3 维数组。</p>
</li>
</ul>
<p data-nodeid="12103">这道题还可以使用记忆化 DFS 来进行搜索，你可以当作练习题试一下吗？</p>
<p data-nodeid="12104"><strong data-nodeid="13500">练习题 2</strong>：请使用记忆化搜索求解例 2。</p>
<blockquote data-nodeid="12105">
<p data-nodeid="12106">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/87.%E6%89%B0%E4%B9%B1%E5%AD%97%E7%AC%A6%E4%B8%B2.rec.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13504">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/87.%E6%89%B0%E4%B9%B1%E5%AD%97%E7%AC%A6%E4%B8%B2.rec.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13508">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/87.%E6%89%B0%E4%B9%B1%E5%AD%97%E7%AC%A6%E4%B8%B2.rec.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13512">Python</a></p>
</blockquote>
<h4 data-nodeid="12107">背包型 DP</h4>
<p data-nodeid="12108">背包型 DP，这个称呼实际上是来自一个比较经典的 DP 问题：“背包问题”，在面试中比较出名的是“背包九讲”。但是我个人认为“背包九讲”对于很多只需要参加面试的同学来说，内容有些偏难，并且大部分面试只会涉及 01 背包和完全背包。因此，接下来我会带你用 6 步分析法处理面试中常常出现的高频背包问题。</p>
<p data-nodeid="12109">注意：如果你没有学习过背包问题，甚至从来没有听说过，也不影响你接下来的学习。</p>
<h4 data-nodeid="12110">例 3：分割等和子集</h4>
<p data-nodeid="12111">【<strong data-nodeid="13522">题目</strong>】一个只包含正整数的非空数组。是否可以将这个数组分割成两个子集，使得两个子集的元素和相等。</p>
<p data-nodeid="12112">注意: 1）每个数组中的元素不会超过 100；2）数组的大小不会超过 200</p>
<p data-nodeid="12113">输入：A = [2, 2]</p>
<p data-nodeid="12114">输出：true</p>
<p data-nodeid="12115">解释：可以将这个数组分成 [2], [2] 这两个子集和是相等的。</p>
<p data-nodeid="12116">【<strong data-nodeid="13543">分析</strong>】由于分出来的两个子集和要求是相等的，如果整个数组和为奇数，那么没有讨论的必要。这里我们只讨论 sum(A) = 2 x V 的情况。也就是分出来的两个子集，其和分别为 V。</p>
<p data-nodeid="12117">这个问题，也可以想象成：</p>
<blockquote data-nodeid="12118">
<p data-nodeid="12119">有一个容量为 V 的背包，给你一些石头，石头的大小放在数组 A[] 中，现在需要捡一些石头，刚好装满容量为 V 的背包。（你可以不去考虑填充的时候的缝隙）</p>
</blockquote>
<p data-nodeid="12120">那么，在这个场景下，每个石头就只有选和不选两种情况。下面我们具体看一下如何利用6 步分析法处理这个问题。</p>
<h4 data-nodeid="12121">1. 最后一步</h4>
<p data-nodeid="12122">这个问题里面，比较难以想到的是最后一步，我们先把最后一步的来龙去脉讲清楚。</p>
<p data-nodeid="12123">首先，假设给定的数组 A[] = {1, 2, 3}，然后看一下利用这个数组可以组合出哪些数。在一开始，如果我们什么元素都不取，肯定可以走到的点为 0。因此，可以将 0 设置为起点。</p>
<p data-nodeid="12124"><img src="https://s0.lgstatic.com/i/image6/M01/37/58/Cgp9HWB2zJmAW8HqAAm_mP67WDc578.gif" alt="1.gif" data-nodeid="13560"></p>
<p data-nodeid="12125">至此，你应该已经分析出最后一步应该如何操作。它依赖两点：</p>
<ul data-nodeid="12126">
<li data-nodeid="12127">
<p data-nodeid="12128">已经可以访问到的点集 X（后面我们把可以访问到的数均称为<strong data-nodeid="13567">点集</strong>）；</p>
</li>
<li data-nodeid="12129">
<p data-nodeid="12130">A[n-1] 元素。</p>
</li>
</ul>
<p data-nodeid="12131">最后一步操作可以用伪代码表示如下（解析在注释里）：</p>
<pre class="lang-java" data-nodeid="12132"><code data-language="java">Y = {....}; <span class="hljs-comment">// 旧有的点集的状态</span>
Z = <span class="hljs-keyword">new</span> HashSet(Y); <span class="hljs-comment">// 新的可以访问的点集</span>
<span class="hljs-comment">// 生成新的可以访问的点</span>
<span class="hljs-keyword">for</span> node in Y:
  Z.insert(node + A[n-<span class="hljs-number">1</span>])
<span class="hljs-comment">// 查看V是否在N点集中</span>
Z.contains(V) -&gt; <span class="hljs-keyword">true</span> / <span class="hljs-keyword">false</span>
</code></pre>
<p data-nodeid="12133">两个点集之间的关系可以简略表示如下：</p>
<p data-nodeid="12134"><img src="https://s0.lgstatic.com/i/image6/M00/37/61/CioPOWB2zMOAbGNlAABqNw0YfrM582.png" alt="Drawing 7.png" data-nodeid="13577"></p>
<h4 data-nodeid="12135">2. 子问题</h4>
<p data-nodeid="12136">通过观察最后一步，可以发现它就是在可访问点集 Y 的基础上，通过<strong data-nodeid="13590">加入边</strong>A[n-1] ，然后生成点集 Z。如果引入更早一点的可访问点集 X，可以将点集的扩展顺序表示如下：</p>
<p data-nodeid="12137"><img src="https://s0.lgstatic.com/i/image6/M01/37/58/Cgp9HWB2zMuAH3SUAABi4JG4bTk857.png" alt="Drawing 8.png" data-nodeid="13593"></p>
<p data-nodeid="12138">那么更进一步，它的子问题就是：</p>
<blockquote data-nodeid="12139">
<p data-nodeid="12140">在一个可访问点集 X 里面，通过加入A[i] 元素之后，<br>
是否可以访问 y1？<br>
是否可以访问 y2？<br>
……<br>
是否可以访问 ym?</p>
</blockquote>
<h4 data-nodeid="12141">3. 递推关系</h4>
<p data-nodeid="12142">如果我们用 f()函数表示这一层关系，可以表示为：</p>
<blockquote data-nodeid="12143">
<p data-nodeid="12144">f(X, A[n-2]) =&gt; Y<br>
f(Y, A[n-1]) =&gt; Z</p>
</blockquote>
<p data-nodeid="12145">需要注意的是， f() 函数并不表示一个数是否可以生成，其输出表示的是一个点集。因此，这个例子告诉我们：有时候，<strong data-nodeid="13628">f(x) 的输出与我们想要的结果并不直接相关</strong>。</p>
<p data-nodeid="12146">比如，在这道题中，我们<strong data-nodeid="13634">最终想要的答案是</strong>：</p>
<blockquote data-nodeid="12147">
<p data-nodeid="12148">值 V 是否出现在了点集 Z 中？</p>
</blockquote>
<p data-nodeid="12149">但是，f() 函数并没有直接回答这个问题，而是通过以下方式来回答最终问题:</p>
<pre class="lang-java" data-nodeid="12150"><code data-language="java">f(Y, A[n-<span class="hljs-number">1</span>]) =&gt; Z
<span class="hljs-keyword">return</span> Z.contains(V)
</code></pre>
<h4 data-nodeid="12151">4. f(x) 的表示</h4>
<p data-nodeid="12152">在这道题目里面，f() 函数更一般的写法为：f(S, A[i])。其中 S 是已知的点集，而这个函数的输出得到的是一个新的点集。</p>
<p data-nodeid="12153">那么，我们在写程序的时候，应该用什么去表达 f() 函数呢？在之前的代码里面，我们要么用数组，要么用哈希函数。但是在这里，S 表示的是可以访问的点集。像这样，如何进行哈希呢？</p>
<p data-nodeid="12154"><strong data-nodeid="13653">优化 1</strong></p>
<p data-nodeid="12155">不过，如果我们根据前面数组 A[] = {1, 2, 3} 给出的示例，可以用 f() 函数表示如下：</p>
<pre class="lang-java" data-nodeid="12156"><code data-language="java">S0 = {<span class="hljs-number">0</span>}
S1 = f(S0, A[<span class="hljs-number">0</span>])
S2 = f(S1, A[<span class="hljs-number">1</span>])
S3 = f(S2, A[<span class="hljs-number">2</span>])
<span class="hljs-keyword">return</span> S3.contains(V)
</code></pre>
<p data-nodeid="12157">我们发现，这个步骤可以很轻松地写成两个点集迭代的形式：</p>
<pre class="lang-java" data-nodeid="12158"><code data-language="java">old = {<span class="hljs-number">0</span>}
<span class="hljs-keyword">for</span> x in A:
    <span class="hljs-keyword">new</span> = f(old, x)
    old = <span class="hljs-keyword">new</span>
<span class="hljs-keyword">return</span> old.contains(V)
</code></pre>
<p data-nodeid="12159"><strong data-nodeid="13662">优化 2</strong></p>
<p data-nodeid="12160">尽管只用两个点集迭代就可以完成计算过程。但是，我们还有一个条件没用上，就是给定的数组里面的元素都是<strong data-nodeid="13668">正整数</strong>。</p>
<p data-nodeid="12161">这就意味着， f(S, A[i]) 在进行迭代的时候，新生成的数，必然会更大。这对于我们的迭代有什么帮助呢？这种递增方向是否可以使我们只使用<strong data-nodeid="13678">一个集合</strong>就完成工作呢？</p>
<p data-nodeid="12162">假设 S = {0, 5}，A[i] = 2 现在要原地完成一个集合的迭代，我们从小到大开始迭代，如下图所示：</p>
<p data-nodeid="12163"><img src="https://s0.lgstatic.com/i/image6/M00/37/61/CioPOWB2zN2Af9neAAQiPWUjU6c193.gif" alt="2.gif" data-nodeid="13686"></p>
<p data-nodeid="12164">但是，如果按上图这样操作，就会出错。因为 A[i] = 2 被使用了两次，而题目要求只能使用一次。</p>
<p data-nodeid="12165">出现这个问题的原因是<strong data-nodeid="13697">我们无法区分旧有的数，新加入的数</strong>。使用另外一个数组标记旧有的数，新生成的数本质上就与两个集合完成迭代没有区别了。那么有什么办法可以帮助我们区分旧有的数和新生成的数呢？</p>
<p data-nodeid="12166">如果我们试试从大往小更新呢？从大往小更新主要是基于这样一个条件：</p>
<blockquote data-nodeid="12167">
<p data-nodeid="12168">新生成的数总是要更大一些的。如果我们先让大的数加上了 A[i]，这些更大的数会放在后面，再次遍历，我们总是不会遇到这些新生成的数。</p>
</blockquote>
<p data-nodeid="12169">迭代步骤如下图所示：</p>
<p data-nodeid="12170"><img src="https://s0.lgstatic.com/i/image6/M00/37/61/CioPOWB2zPGAEM2YAARohJntves709.gif" alt="3.gif" data-nodeid="13707"></p>
<p data-nodeid="12171">我们发现，如果采用从大往小的方向遍历，就可以利用一个点集完成迭代。</p>
<h4 data-nodeid="12172">5. 初始条件与边界</h4>
<p data-nodeid="12173">首先，当我们什么都不选的时候，肯定可以得到 0，所以一开始的点集就是 {0}。</p>
<p data-nodeid="12174">其次，我们要得到的数是 V。如果旧有的点集中，已经有数比 V 大了，比如 R，那么可以直接把 R 扔掉。因为在后面的迭代过程中，A[i] 都是正数，迭代之后，只会让 R 越来越大，所以保留 R 没有意义。</p>
<p data-nodeid="12175">因此动态规划的边界就是 [0, V]。</p>
<h4 data-nodeid="12176">6. 计算顺序</h4>
<p data-nodeid="12177">有两个计算顺序需要注意：</p>
<ul data-nodeid="12178">
<li data-nodeid="12179">
<p data-nodeid="12180">迭代的时候，需要用 A[0], A[1],…, A[n-1] 依次去更新点集；</p>
</li>
<li data-nodeid="12181">
<p data-nodeid="12182">当我们更新点集的时候，需要按从大到小的顺序更新。</p>
</li>
</ul>
<p data-nodeid="12183">当 f() 函数在整个迭代过程中只需要一个点集，并且这个点集的范围已经是固定 [0, V] 的时候，就可以用 boolean 数组来表示这个点集。</p>
<p data-nodeid="12184">【<strong data-nodeid="13751">代码</strong>】经过前面的分析，我们已经可以写出如下代码了（解析在注释里）：</p>
<pre class="lang-java" data-nodeid="12185"><code data-language="java"><span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">Solution</span> </span>{
    <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">boolean</span> <span class="hljs-title">canPartition</span><span class="hljs-params">(<span class="hljs-keyword">int</span>[] A)</span> </span>{
        <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> N = A == <span class="hljs-keyword">null</span> ? <span class="hljs-number">0</span> : A.length;
        <span class="hljs-keyword">if</span> (N &lt;= <span class="hljs-number">0</span>) {
            <span class="hljs-keyword">return</span> <span class="hljs-keyword">true</span>;
        }
        <span class="hljs-comment">// 数组求和</span>
        <span class="hljs-keyword">int</span> s = <span class="hljs-number">0</span>;
        <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> x : A) {
            s += x;
        }
        <span class="hljs-comment">// 如果为奇数， 肯定是没有办法切分</span>
        <span class="hljs-keyword">if</span> ((s &amp; <span class="hljs-number">0x01</span>) == <span class="hljs-number">1</span>) {
            <span class="hljs-keyword">return</span> <span class="hljs-keyword">false</span>;
        }
        <span class="hljs-comment">// 分割为等和，那么相当于要取同值的一半</span>
        <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> V = s &gt;&gt; <span class="hljs-number">1</span>;
        <span class="hljs-comment">// 这个dp表示着一开始可以访问的点集</span>
        <span class="hljs-comment">// 我们用true表示这个点存在于点集中</span>
        <span class="hljs-comment">// false表示这个点不存在点集中</span>
        <span class="hljs-keyword">boolean</span>[] dp = <span class="hljs-keyword">new</span> <span class="hljs-keyword">boolean</span>[V + <span class="hljs-number">1</span>];
        <span class="hljs-comment">// 首先初始集合肯定是s0={0}</span>
        dp[<span class="hljs-number">0</span>] = <span class="hljs-keyword">true</span>;
        <span class="hljs-comment">// 开始利用a[i]来进行推导</span>
        <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> x : A) {
            <span class="hljs-comment">// 注意这里更新的方向</span>
            <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> node = V; node - x &gt;= <span class="hljs-number">0</span>; node--) {
                <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> newNode = node;
                <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> oldExistsNode = node - x;
                <span class="hljs-keyword">if</span> (dp[oldExistsNode]) {
                    dp[newNode] = <span class="hljs-keyword">true</span>;
                }
            }
        }
        <span class="hljs-keyword">return</span> dp[V];
    }
}
</code></pre>
<blockquote data-nodeid="12186">
<p data-nodeid="12187">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/416.%E5%88%86%E5%89%B2%E7%AD%89%E5%92%8C%E5%AD%90%E9%9B%86.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13755">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/416.%E5%88%86%E5%89%B2%E7%AD%89%E5%92%8C%E5%AD%90%E9%9B%86.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13759">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/416.%E5%88%86%E5%89%B2%E7%AD%89%E5%92%8C%E5%AD%90%E9%9B%86.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13763">Python</a></p>
</blockquote>
<p data-nodeid="12188"><strong data-nodeid="13768">复杂度分析</strong>：时间复杂度 O(NV)，空间复杂度 O(V)。</p>
<p data-nodeid="12189">【<strong data-nodeid="13774">小结</strong>】在这道题目里面，我们再次利用 DP 的 6 步分析法求解问题。在求解的过程中，可以发现有两个有意思的地方：</p>
<ul data-nodeid="12190">
<li data-nodeid="12191">
<p data-nodeid="12192">利用 A[i] 逐步进行迭代；</p>
</li>
<li data-nodeid="12193">
<p data-nodeid="12194">dp[] 数组的更新方向，需要从大到小更新的根本原因是数组里面面的数都是正整数。</p>
</li>
</ul>
<p data-nodeid="12195">这个题目，实际上是一个 01 背包问题的变形。那么真正的 01 背包问题是什么样呢？这里我给你留了一道练习题，你可以尝试求解一下。</p>
<p data-nodeid="12196"><strong data-nodeid="13789">练习题 3</strong>：（0/1 背包）有 N 件物品和一个容量是 V 的背包，每件物品只能使用一次。</p>
<p data-nodeid="12197">第 i 件物品的体积是 vi，价值是 wi。求解将哪些物品装入背包，可使这些物品的总体积不超过背包容量，且总价值最大。输出最大价值。</p>
<blockquote data-nodeid="12198">
<p data-nodeid="12199">代码:<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/acwing.01.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13794">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/acwing.01.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13798">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/acwing.01.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13802">Python</a></p>
</blockquote>
<p data-nodeid="12200"><strong data-nodeid="13807">练习题 4</strong>：有 N 种物品和一个容量是 V 的背包，每种物品都有无限件可用。第 i 种物品的体积是 vi，价值是 wi。求解将哪些物品装入背包，可使这些物品的总体积不超过背包容量，且总价值最大。输出最大价值。</p>
<blockquote data-nodeid="12201">
<p data-nodeid="12202">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/acwing.full.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13811">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/acwing.full.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13815">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/acwing.full.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13819">Python</a></p>
</blockquote>
<p data-nodeid="12203"><strong data-nodeid="13824">练习题 5</strong>：给定一个非负整数数组，a1, a2,…, an, 和一个目标数 S。现在你有两个符号 + 和 -。对于数组中的任意一个整数，你都可以从 + 或 - 中选择一个符号添加在前面。返回可以使最终数组和为目标数 S 的所有添加符号的方法数。</p>
<p data-nodeid="12204">输入：nums: [1, 1, 1, 1, 1], S: 3</p>
<p data-nodeid="12205">输出：5</p>
<p data-nodeid="12206">解释：</p>
<p data-nodeid="12207">-1+1+1+1+1 = 3</p>
<p data-nodeid="12208">+1-1+1+1+1 = 3</p>
<p data-nodeid="12209">+1+1-1+1+1 = 3</p>
<p data-nodeid="12210">+1+1+1-1+1 = 3</p>
<p data-nodeid="12211">+1+1+1+1-1 = 3</p>
<blockquote data-nodeid="12212">
<p data-nodeid="12213">解法 1：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/494.%E7%9B%AE%E6%A0%87%E5%92%8C.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13840">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/494.%E7%9B%AE%E6%A0%87%E5%92%8C.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13844">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/494.%E7%9B%AE%E6%A0%87%E5%92%8C.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13848">Python</a><br>
解法 2：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/494.%E7%9B%AE%E6%A0%87%E5%92%8C.backtrace.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13853">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/494.%E7%9B%AE%E6%A0%87%E5%92%8C.backtrace.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13857">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/494.%E7%9B%AE%E6%A0%87%E5%92%8C.backtrace.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13861">Python</a></p>
</blockquote>
<h4 data-nodeid="12214">树型 DP</h4>
<p data-nodeid="12215">树型 DP，顾名思义，这一类题目会在一棵二叉树，或者多叉树上进行 DP。虽然看起来是一个二叉树问题，但本质上需要用到 DP 的知识才能求解。不过有了我们的 6 步破解法，这种树型 DP 题目也没有那么难。接下来我们一起通过题目学习一下。</p>
<h4 data-nodeid="12216">例 4：二叉树抢劫</h4>
<p data-nodeid="12217">【<strong data-nodeid="13870">题目</strong>】在上次打劫完一条街道之后和一圈房屋后，小偷又发现一个新的可行窃的地区。这个地区只有一个入口，我们称为“根”。 除了“根”之外，每栋房子有且只有一个“父”房子与之相连。一番侦察之后，聪明的小偷意识到“这个地方的所有房屋的排列类似于一棵二叉树”。 如果两个直接相连的房子在同一天晚上被打劫，房屋将自动报警。计算在不触动警报的情况下，小偷一晚能够盗取的最高金额。</p>
<p data-nodeid="12218">输入：[3,2,3,null,3,null,1]</p>
<p data-nodeid="12219"><img src="https://s0.lgstatic.com/i/image6/M01/37/58/Cgp9HWB2zQeANJDtAAAi-wCtZjQ178.png" alt="Drawing 11.png" data-nodeid="13877"></p>
<p data-nodeid="12220">输出：7</p>
<p data-nodeid="12221">解释：小偷一晚能够盗取的最高金额 = 3 + 3 + 1 = 7.</p>
<p data-nodeid="12222">【<strong data-nodeid="13885">分析</strong>】我们看到“最高”两字，应该可以想到使用 DP 方法来试一试。首先还是使出我们的绝招，最后一步。</p>
<h4 data-nodeid="12223">1. 最后一步</h4>
<p data-nodeid="12224">假设小偷在抢劫的时候，总是先抢树的子树，那么最后一步肯定就是二叉树的根结点。根结点只有两种可能：</p>
<ul data-nodeid="12225">
<li data-nodeid="12226">
<p data-nodeid="12227">抢根结点</p>
</li>
<li data-nodeid="12228">
<p data-nodeid="12229">不抢根结点</p>
</li>
</ul>
<p data-nodeid="12230">得到这两种可能之后，我们只需要在这两种情况中取最大值就可以了。</p>
<h4 data-nodeid="12231">2. 子问题</h4>
<p data-nodeid="12232">如果我们进一步展开根结点的 2 种情况，可以发现：</p>
<ul data-nodeid="12233">
<li data-nodeid="12234">
<p data-nodeid="12235">抢根结点，此时<strong data-nodeid="13906">不能</strong>抢左右<strong data-nodeid="13907">两棵子树的根结点</strong>；</p>
</li>
<li data-nodeid="12236">
<p data-nodeid="12237">不抢根结点，此时<strong data-nodeid="13920">可以抢</strong>左右<strong data-nodeid="13922">两棵子树的根结点，<strong data-nodeid="13921">也</strong>可以不抢两棵子树的根结点。</strong></p>
</li>
</ul>
<p data-nodeid="12238">我们发现，根结点需要得到两个信息：&lt;抢 root 的最大收益,不抢 root 的最大收益&gt;，并且左右子树也是需要这两个信息。</p>
<p data-nodeid="12239">那么我们可以定义一个函数 f(x)，来描述最后一步的需求，以及子问题的需求：</p>
<blockquote data-nodeid="12240">
<p data-nodeid="12241">f(x) = &lt;抢 x 的最大收益, 不抢 x 的最大收益&gt;</p>
</blockquote>
<p data-nodeid="12242">为了后面描述的方便，我们会用到以下缩写表示上述两个维度的信息：</p>
<blockquote data-nodeid="12243">
<p data-nodeid="12244">f(x) = &lt;抢,不抢&gt; = &lt;抢 x 的最大收益, 不抢 x 的最大收益&gt;<br>
max(f(x)) = max&lt;f(x).抢,f(x).不抢&gt;</p>
</blockquote>
<h4 data-nodeid="12245">3. 递推关系</h4>
<p data-nodeid="12246">到这里，我们可以根据最后一步和子问题写出递推关系：</p>
<blockquote data-nodeid="12247">
<p data-nodeid="12248">f(root).抢 = root.val + f(root.left).不抢 + f(root.right).不抢<br>
f(root).不抢 = max(f(root.left)) + max(f(root.right)))</p>
</blockquote>
<h4 data-nodeid="12249">4. f(x) 的表示</h4>
<p data-nodeid="12250">首先我们看一下 f(x) 的返回值，由于返回值只有两个。这比较好处理，对于 Python 来说，可以直接返回两个值，而对于 Java 来说，可以直接返回 long[2] 数组。</p>
<p data-nodeid="12251">然后再看一下 f(x) 的表示。我们从底层开始往上抢的时候，应该只有相邻的两层才会有相互的依赖，如下图所示：</p>
<p data-nodeid="12252"><img src="https://s0.lgstatic.com/i/image6/M00/37/61/CioPOWB2zTyAErOsAACsCnIj2ck114.png" alt="Drawing 12.png" data-nodeid="13962"></p>
<p data-nodeid="12253">相隔更远的层间信息不需要保留，所以 f(x) 函数并不需要一个哈希或者数组来记录 [x] 的信息。相当于直接使用 DFS，而不需要记忆化 DFS。</p>
<h4 data-nodeid="12254">5. 初始条件与边界</h4>
<p data-nodeid="12255">当遇到一棵空树的时候，只需要返回 long[2] = {0, 0} 就可以了，也就是收益为 0。</p>
<h4 data-nodeid="12256">6. 计算顺序</h4>
<p data-nodeid="12257">这里我们采用的是先抢树的子树，因此，顺序上需要使用后序遍历。</p>
<p data-nodeid="12258">【<strong data-nodeid="13985">代码</strong>】到这里，我们已经可以写出如下代码了（解析在注释里）：</p>
<pre class="lang-java" data-nodeid="12259"><code data-language="java"><span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">Solution</span> </span>{
    <span class="hljs-comment">// 返回值是一个pair</span>
    <span class="hljs-comment">// ans[0]表示抢当前根结点</span>
    <span class="hljs-comment">// ans[1]表示不能抢当前结点</span>
    <span class="hljs-keyword">private</span> <span class="hljs-keyword">long</span>[] postOrder(TreeNode root) {
        <span class="hljs-keyword">if</span> (root == <span class="hljs-keyword">null</span>) {
            <span class="hljs-keyword">return</span> <span class="hljs-keyword">new</span> <span class="hljs-keyword">long</span>[] { <span class="hljs-number">0</span>, <span class="hljs-number">0</span> };
        }
        <span class="hljs-keyword">long</span>[] l = postOrder(root.left);
        <span class="hljs-keyword">long</span>[] r = postOrder(root.right);
        <span class="hljs-comment">// 如果要抢当前结点</span>
        <span class="hljs-keyword">long</span> get = root.val;
        <span class="hljs-comment">// 那么两个子结点必然不能抢</span>
        get += l[<span class="hljs-number">1</span>] + r[<span class="hljs-number">1</span>];
        <span class="hljs-comment">// 如果不抢当前结点</span>
        <span class="hljs-keyword">long</span> skip = <span class="hljs-number">0</span>;
        <span class="hljs-comment">// 那么两个子结点可以抢，也可以不抢</span>
        skip += Math.max(l[<span class="hljs-number">0</span>], l[<span class="hljs-number">1</span>]) + Math.max(r[<span class="hljs-number">0</span>], r[<span class="hljs-number">1</span>]);
        <span class="hljs-keyword">return</span> <span class="hljs-keyword">new</span> <span class="hljs-keyword">long</span>[] { get, skip };
    }
    <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">int</span> <span class="hljs-title">rob</span><span class="hljs-params">(TreeNode root)</span> </span>{
        <span class="hljs-keyword">long</span>[] ans = postOrder(root);
        <span class="hljs-keyword">return</span> (<span class="hljs-keyword">int</span>) Math.max(ans[<span class="hljs-number">0</span>], ans[<span class="hljs-number">1</span>]);
    }
}
</code></pre>
<blockquote data-nodeid="12260">
<p data-nodeid="12261">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/337.%E6%89%93%E5%AE%B6%E5%8A%AB%E8%88%8D-iii.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13989">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/337.%E6%89%93%E5%AE%B6%E5%8A%AB%E8%88%8D-iii.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13993">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/337.%E6%89%93%E5%AE%B6%E5%8A%AB%E8%88%8D-iii.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="13997">Python</a></p>
</blockquote>
<p data-nodeid="12262"><strong data-nodeid="14002">复杂度分析</strong>：时间复杂度，本质上这就是一个后序遍历，所以为 O(N)。算上栈占用的空间，空间复杂度为 O(H)，其中 H 表示树的高度。</p>
<p data-nodeid="12263">【<strong data-nodeid="14008">小结</strong>】最后我们再总结一下这个题目的考点：</p>
<ul data-nodeid="12264">
<li data-nodeid="12265">
<p data-nodeid="12266">DP 的 6 步分析法</p>
</li>
<li data-nodeid="12267">
<p data-nodeid="12268">后序遍历</p>
</li>
</ul>
<p data-nodeid="12269">此外，在处理这道题的最后返回值时，后序遍历的返回值并不是直接返回了我们想要的答案，而是带上了子树的信息，然后留给根结点把这部分信息做整合。你可以联系到我们在“<a href="https://kaiwu.lagou.com/course/courseInfo.htm?courseId=685#/detail/pc?id=6695&amp;fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="14016">06 | 树：如何深度运用树的遍历？</a>”里，学习二叉树的后序遍历时讲过的“项庄舞剑，意在沛公”解法，不难发现，树型 DP 与**后序遍历中“项庄舞剑，意在沛公”**的解法基本上是一样的。</p>
<p data-nodeid="12270">接下来，我给你留了一道练习题，你可以再体会一下树型 DP 方法。</p>
<p data-nodeid="12271"><strong data-nodeid="14029">练习题 6</strong>：给定一棵二叉树，你需要计算它的直径长度。一棵二叉树的直径长度是任意两个结点路径长度中的最大值。这条路径可能穿过也可能不穿过根结点。</p>
<p data-nodeid="12272">示例 :</p>
<p data-nodeid="12273">给定二叉树</p>
<p data-nodeid="12274">1</p>
<p data-nodeid="12275">/ \</p>
<p data-nodeid="12276">2 3<br>
/ \</p>
<p data-nodeid="12277">4 5</p>
<p data-nodeid="12278">返回 3, 它的长度是路径 [4,2,1,3] 或者 [5,2,1,3]。</p>
<blockquote data-nodeid="12279">
<p data-nodeid="12280">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/543.%E4%BA%8C%E5%8F%89%E6%A0%91%E7%9A%84%E7%9B%B4%E5%BE%84.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="14052">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/543.%E4%BA%8C%E5%8F%89%E6%A0%91%E7%9A%84%E7%9B%B4%E5%BE%84.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="14056">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/543.%E4%BA%8C%E5%8F%89%E6%A0%91%E7%9A%84%E7%9B%B4%E5%BE%84.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="14060">Python</a></p>
</blockquote>
<h4 data-nodeid="12281">状态压缩型 DP</h4>
<p data-nodeid="12282">状态压缩型 DP 的关键就是如何表达 f(x) 函数。这类题目有几个特点：</p>
<ul data-nodeid="12283">
<li data-nodeid="12284">
<p data-nodeid="12285">x 往往表示一个数组，并且这个数组是原始数组 A[] 的一个子集：即 A[] 数组中的每个元素可以选，也可以不选；</p>
</li>
<li data-nodeid="12286">
<p data-nodeid="12287">直接用哈希或者数组表达 f(x) 都不是特别方便；</p>
</li>
<li data-nodeid="12288">
<p data-nodeid="12289">原始数组 A[] 并不会特别长。</p>
</li>
</ul>
<p data-nodeid="12290">基于这样的一个特点，我们在设计 f(x) 函数的时候，就需要根据以下两个点进行破题：</p>
<ul data-nodeid="12291">
<li data-nodeid="12292">
<p data-nodeid="12293">A[i] 元素可以选，也可以不选；</p>
</li>
<li data-nodeid="12294">
<p data-nodeid="12295">原始数组 A[] 不会特别长。</p>
</li>
</ul>
<p data-nodeid="12296">选和不选，可以用 0/1 来表示，虽然 x 表示的是一个数组，但是我们可以用一个与原始数组等长（或者更长一些）的二进制整数 y 来表示<strong data-nodeid="14097">第 i 个 bit 位：0 表示不选 A[i]，1 表示选 A[i]</strong>。</p>
<p data-nodeid="12297">这样，就可以通过一个整数 y 表达 x 数组，然后利用数组 dp[y] 表达 f(x) 的状态。下面我们看一下例题。这里用了一个非常简单的整数表示一个数组的信息，所以这种 DP 也被叫作状态压缩 DP。</p>
<h4 data-nodeid="12298">例 5：N 次操作的最大分数和</h4>
<p data-nodeid="12299">【<strong data-nodeid="14114">题目</strong>】给你 A[] ，它是一个大小为 2 * n 的正整数数组。你必须对这个数组执行 n 次操作。在第 i 次操作时（操作编号从 1 开始），你需要：</p>
<p data-nodeid="12300">Step 1. 选择两个元素 x 和 y 。</p>
<p data-nodeid="12301">Step 2. 获得分数 i * gcd(x, y) 。</p>
<p data-nodeid="12302">Step 3. 将 x 和 y 从 A[] 中删除。</p>
<p data-nodeid="12303">返回 n 次操作后，请你求解获得的分数和最大为多少。函数 gcd(x, y) 是 x 和 y 的最大公约数。</p>
<p data-nodeid="12304">输入：A = [3,4,6,8]</p>
<p data-nodeid="12305">输出：11</p>
<p data-nodeid="12306">解释：最优操作是：</p>
<p data-nodeid="12307">(1 * gcd(3, 6)) + (2 * gcd(4, 8)) = 3 + 8 = 11</p>
<p data-nodeid="12308"><strong data-nodeid="14139">注意</strong>：数组最大长度为 14。</p>
<p data-nodeid="12309">【<strong data-nodeid="14145">分析</strong>】当拿到这道题的时候，我们首先进行一下简化，把这个问题转化为一个等价的问题。</p>
<p data-nodeid="12310">虽然题目中给定的是删除操作，我们可以把这个删除之后的元素，放到一个数组 C[] 中，操作步骤如下：</p>
<blockquote data-nodeid="12311">
<p data-nodeid="12312">(1 * gcd(3, 6)) + (2 * gcd(4, 8)) = 3 + 8 = 11</p>
</blockquote>
<p data-nodeid="12313">也可以认为是：</p>
<blockquote data-nodeid="12314">
<p data-nodeid="12315">第 1 次添加：&lt;3, 6&gt; = 1 * gcd(3, 6)), C = [3, 6]<br>
第 2 次添加：&lt;4, 8&gt; = (2 * gcd(4, 8), C = [3, 6, 4, 8]<br>
最终收益 = 11</p>
</blockquote>
<p data-nodeid="12316">题目就可以简化成如下这样。</p>
<blockquote data-nodeid="12317">
<p data-nodeid="12318">一开始你有一个空数组 C，以及有元素的数组 A[]，你需要如下操作：</p>
<ol data-nodeid="12319">
<li data-nodeid="12320">
<p data-nodeid="12321">从 A 数组中选择两个数 x,y，然后将这两个数从 A[] 中删除；</p>
</li>
<li data-nodeid="12322">
<p data-nodeid="12323">将这两个数放到 C 中；</p>
</li>
<li data-nodeid="12324">
<p data-nodeid="12325">获得分数 len(C) / 2 * gcd(x, y)。</p>
</li>
</ol>
<blockquote data-nodeid="12326">
<p data-nodeid="12327">求如何操作，得到最大分数。</p>
</blockquote>
</blockquote>
<p data-nodeid="12328">这样<strong data-nodeid="14194">处理的好处</strong>在于：我们不再需要记录步数信息，只需要看当前数组 C 的大小，就可以得到当前是第几步。即步数 = C 数组大小 / 2。</p>
<p data-nodeid="12329">接下来，我们就基于这个稍做改动的等价题目来分析。需要注意两个信息：</p>
<ul data-nodeid="12330">
<li data-nodeid="12331">
<p data-nodeid="12332">最大值</p>
</li>
<li data-nodeid="12333">
<p data-nodeid="12334">数组本身不会太大</p>
</li>
</ul>
<p data-nodeid="12335">我们首先分析第一个信息，求<strong data-nodeid="14207">最大值</strong>，那么这里我们尝试一下 DP。而第二个信息告诉我们，如果进行暴力搜索，其实状态空间也只有 2<sup>N</sup> 种。并不算特别大。</p>
<p data-nodeid="12336">下面我们看一下如何运用好题意给出的这两个重要信息。</p>
<h4 data-nodeid="12337">1. 最后一步</h4>
<p data-nodeid="12338">当我们执行到最后一步的时候，数组中肯定只会剩下两个数了。假设这两个数是 &lt;x, y&gt;，那么<strong data-nodeid="14219">最后一步</strong>，得到的收益就是：</p>
<blockquote data-nodeid="12339">
<p data-nodeid="12340">last_step = len(C) + 2 / 2；<br>
last_income = 形成数组 C[] 的最大收益 + last_step * gcd(x,y)。</p>
</blockquote>
<p data-nodeid="12341">但是，最终余下的两个数 &lt;x, y&gt;，可以是原始数组 A[] 的任意的两个数。所以我们可以用伪代码表示如下：</p>
<pre class="lang-java" data-nodeid="12342"><code data-language="java">last_income = <span class="hljs-number">0</span>;
<span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> j = <span class="hljs-number">0</span>; j &lt; N; j++): <span class="hljs-comment">//  x = a[j]</span>
  <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> k = j + <span class="hljs-number">1</span>; k &lt; N; k++): <span class="hljs-comment">// y = A[k] </span>
    <span class="hljs-comment">// 数组C[], 再加上最后一步加入的&lt;x,y&gt;，那么长度必然与原始数组A一样长</span>
    last_step = len(C) + <span class="hljs-number">2</span> / <span class="hljs-number">2</span> 即 len(A) / <span class="hljs-number">2</span>
    last_income = max((计算C[]数组的收益 + last_step * gcd(A[j], A[k]), 
                       last_income);
</code></pre>
<h4 data-nodeid="12343">2. 子问题</h4>
<p data-nodeid="12344">研究最后一步之后，可以发现，要递归计算的是数组 C[] 和数组 A[] 的最大收益，那么子问题可以表示如下：</p>
<blockquote data-nodeid="12345">
<p data-nodeid="12346">f(A) 表示数组 A[] 的最大收益；<br>
f(C) 表示数组 C[] 的最大收益。</p>
</blockquote>
<p data-nodeid="12347">我们可以统一用 f(x) 表示最终问题与子问题：</p>
<blockquote data-nodeid="12348">
<p data-nodeid="12349">f(x) 表示 x[] 数组的最大收益；<br>
其中，x[] 是原始数组 A[ ]的子序列。</p>
</blockquote>
<h4 data-nodeid="12350">3. 递推关系</h4>
<p data-nodeid="12351">我们可以利用伪代码，重新表达一下这个递推关系，代码如下（解析在注释里）：</p>
<pre class="lang-java" data-nodeid="12352"><code data-language="java"><span class="hljs-function"><span class="hljs-keyword">int</span> <span class="hljs-title">f</span><span class="hljs-params">(x[])</span> </span>{ <span class="hljs-comment">// 形成数组x[]的最大收益</span>
  ans = <span class="hljs-number">0</span>;
  <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> j = <span class="hljs-number">0</span>; j &lt; N; j++):
    <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> k = j + <span class="hljs-number">1</span>; k &lt; N; k++):
      C[] = x.remove_index_item(j, k)
      L = len(x) / <span class="hljs-number">2</span>; <span class="hljs-comment">// C[]数组加入&lt;x,y&gt;之后形成x数组</span>
      ans = max((f(C) + L * gcd(A[j], A[k]), ans);
  <span class="hljs-keyword">return</span> ans;
}
</code></pre>
<h4 data-nodeid="12353">4. f(x) 的表达</h4>
<p data-nodeid="12354">由于 x 数组肯定是 A 数组的一个子集，并且 A 数组并不是特别大。那么我们可以用二进制串来表示 A[i] 元素是否存在于 x 数组这个关系：</p>
<ul data-nodeid="12355">
<li data-nodeid="12356">
<p data-nodeid="12357">1 表示 A[i] 存在于 x 数组中；</p>
</li>
<li data-nodeid="12358">
<p data-nodeid="12359">0 表示 A[i] 不存在于 x 数组中。</p>
</li>
</ul>
<p data-nodeid="12360">在这种情况下，我们可以申请一个数组：</p>
<pre class="lang-java" data-nodeid="12361"><code data-language="java"><span class="hljs-keyword">int</span>[] dp = <span class="hljs-keyword">new</span> <span class="hljs-keyword">int</span>[<span class="hljs-number">1</span>&lt;&lt;(len(A))];
</code></pre>
<p data-nodeid="12362">然后用 dp[i] 表示 f(x)。其中i这个整数的二进制串表示：A[] 数组的子序列 x[]。</p>
<h4 data-nodeid="12363">5. 初始条件与边界</h4>
<p data-nodeid="12364">首先，当数组为空的时候，肯定是没有什么收益的。所以此时 dp[0] = 0。并且，由于我们总是成对地添加元素，所以当 dp[i] 中的下标 i 里面的 bit 1 的个数为奇数（表示 x[] 数组有奇数个元素），这种情况应该是不可能出现的，不需要进行处理。</p>
<h4 data-nodeid="12365">6. 计算顺序</h4>
<p data-nodeid="12366">当我们使用更改之后的题目进行处理的时候，就可以直接从 dp[0] 开始计算了。</p>
<p data-nodeid="12367">【<strong data-nodeid="14339">代码</strong>】得到状态压缩之后，我们可以写出代码如下（解析在注释里）：</p>
<pre class="lang-java" data-nodeid="12368"><code data-language="java"><span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">Solution</span></span>{
  <span class="hljs-function"><span class="hljs-keyword">private</span> <span class="hljs-keyword">int</span> <span class="hljs-title">bitCount</span><span class="hljs-params">(<span class="hljs-keyword">int</span> x)</span> </span>{
    <span class="hljs-keyword">int</span> ret = <span class="hljs-number">0</span>;
    <span class="hljs-keyword">while</span> (x != <span class="hljs-number">0</span>) {
      ret += (x &amp; <span class="hljs-number">0x01</span>) == <span class="hljs-number">1</span> ? <span class="hljs-number">1</span> : <span class="hljs-number">0</span>;
      x &gt;&gt;= <span class="hljs-number">1</span>;
    }
    <span class="hljs-keyword">return</span> ret;
  }
  <span class="hljs-function"><span class="hljs-keyword">private</span> <span class="hljs-keyword">int</span> <span class="hljs-title">gcd</span><span class="hljs-params">(<span class="hljs-keyword">int</span> a, <span class="hljs-keyword">int</span> b)</span> </span>{ <span class="hljs-keyword">return</span> b == <span class="hljs-number">0</span> ? a : gcd(b, a % b); }
  <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">int</span> <span class="hljs-title">maxScore</span><span class="hljs-params">(<span class="hljs-keyword">int</span>[] A)</span> </span>{
    <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> N = A == <span class="hljs-keyword">null</span> ? <span class="hljs-number">0</span> : A.length;
    <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> total_steps = N &gt;&gt; <span class="hljs-number">1</span>;
    <span class="hljs-comment">// 一共有N个数</span>
    <span class="hljs-comment">// 每个数可以表示存在，或者不存在</span>
    <span class="hljs-comment">// 那么只有两种状态0/1</span>
    <span class="hljs-comment">// 因此，我们可以用二进制位来进行表示</span>
    <span class="hljs-comment">// 由于题目中已经说明n &lt;= 7</span>
    <span class="hljs-comment">// 所以，最多只需要14 bits</span>
    <span class="hljs-comment">// 那么用一个int位，我们就可以表示了</span>
    <span class="hljs-comment">// 所以这里我们申请dp[array_size]</span>
    <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> array_size = <span class="hljs-number">1</span> &lt;&lt; N;
    <span class="hljs-keyword">int</span>[] dp = <span class="hljs-keyword">new</span> <span class="hljs-keyword">int</span>[array_size];
    <span class="hljs-comment">// dp[0] = 0</span>
    <span class="hljs-comment">// 表示当没有任何数的时候，那么收益肯定为0</span>
    <span class="hljs-comment">// 已经设置过了，这里不用再设置</span>
    <span class="hljs-comment">// 那么接下来就是从余下两个数的时候开始</span>
    <span class="hljs-comment">// 往前推导</span>
    <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> i = <span class="hljs-number">3</span>; i &lt; array_size; i++) {
      <span class="hljs-comment">// 这里利用GCC内置的计算整的二进制中1的个数的函数</span>
      <span class="hljs-keyword">int</span> cnt = bitCount(i);
      <span class="hljs-comment">// 由于每次需要去掉两个数，当i里面的二进制1的数目为</span>
      <span class="hljs-comment">// 奇数的时候，没有必要计算!</span>
      <span class="hljs-keyword">if</span> ((cnt &amp; <span class="hljs-number">0x01</span>) == <span class="hljs-number">1</span>) {
        <span class="hljs-keyword">continue</span>;
      }
      <span class="hljs-comment">// 当前步数</span>
      <span class="hljs-comment">// 即: 当前我是第几步</span>
      <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> cur_step = cnt &gt;&gt;&gt; <span class="hljs-number">1</span>;
      <span class="hljs-comment">// 那么我们需要从i里面选两个数</span>
      <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> j = <span class="hljs-number">0</span>; j &lt; N; j++) {
        <span class="hljs-comment">// 如果i中没有A[j]这个数</span>
        <span class="hljs-keyword">if</span> ((i &amp; (<span class="hljs-number">1</span> &lt;&lt; j)) == <span class="hljs-number">0</span>)
          <span class="hljs-keyword">continue</span>;
        <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> k = j + <span class="hljs-number">1</span>; k &lt; N; k++) {
          <span class="hljs-comment">// 如果i中没有A[k]这个数</span>
          <span class="hljs-keyword">if</span> ((i &amp; (<span class="hljs-number">1</span> &lt;&lt; k)) == <span class="hljs-number">0</span>)
            <span class="hljs-keyword">continue</span>;
          <span class="hljs-comment">// 这里我们选择A[j], A[k]</span>
          <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> g = gcd(A[j], A[k]);
          <span class="hljs-comment">// 得分</span>
          <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> score = cur_step * g;
          <span class="hljs-comment">// 得到去掉i,j之后的状态</span>
          <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> mask = (<span class="hljs-number">1</span> &lt;&lt; j) | (<span class="hljs-number">1</span> &lt;&lt; k);
          <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> pre_status = i &amp; ~mask;
          <span class="hljs-keyword">final</span> <span class="hljs-keyword">int</span> total = dp[pre_status] + score;
          <span class="hljs-comment">// 选择最大值dp[i]</span>
          dp[i] = Math.max(dp[i], total);
        }
      }
    }
    <span class="hljs-keyword">return</span> dp[array_size - <span class="hljs-number">1</span>];
  }
}
</code></pre>
<blockquote data-nodeid="12369">
<p data-nodeid="12370">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/1799.n-%E6%AC%A1%E6%93%8D%E4%BD%9C%E5%90%8E%E7%9A%84%E6%9C%80%E5%A4%A7%E5%88%86%E6%95%B0%E5%92%8C.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="14343">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/1799.n-%E6%AC%A1%E6%93%8D%E4%BD%9C%E5%90%8E%E7%9A%84%E6%9C%80%E5%A4%A7%E5%88%86%E6%95%B0%E5%92%8C.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="14347">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/1799.n-%E6%AC%A1%E6%93%8D%E4%BD%9C%E5%90%8E%E7%9A%84%E6%9C%80%E5%A4%A7%E5%88%86%E6%95%B0%E5%92%8C.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="14351">Python</a></p>
</blockquote>
<p data-nodeid="12371"><strong data-nodeid="14370">复杂度分析</strong>：当给定 N 个数的时候，一共需要表达 2<sup>N</sup> 种状态，而每种状态在处理时候，需要遍历 N x N 次，所以时间复杂度为 O(2<sup>N</sup> x N x N)，空间复杂度为 O(2<sup>N</sup>)。虽然看起来很大，但是题目中已经明确说了数组的长度 &lt;= 14（最多只有 7 对数）。</p>
<p data-nodeid="12372">【<strong data-nodeid="14376">小结</strong>】如果你已经掌握了 6 步破解法，相信你可以明白，这道 DP 题目的关键就是 f(x) 的表示。</p>
<p data-nodeid="12373">实际上，所有状态压缩题的核心与关键都是在 f (x) 的表示上。为了让你深入学习这种方法，这里我还给你留了一道练习题，希望你可以尝试思考并动手解答。</p>
<p data-nodeid="12374"><strong data-nodeid="14396">练习题 7</strong>：给你一个 m * n 的矩阵 seats 表示教室中的座位分布。如果座位是坏的（不可用），就用 '#' 表示；否则，用 '.' 表示。学生可以看到<strong data-nodeid="14397">左侧、右侧、左上、右上</strong>这四个方向上紧邻他的学生的答卷，但是看不到直接坐在他前面或者后面的学生的答卷。请你计算并返回该考场可以容纳的一起参加考试且无法作弊的最大学生人数。学生必须坐在状况良好的座位上。</p>
<p data-nodeid="12375"><img src="https://s0.lgstatic.com/i/image6/M00/37/61/CioPOWB2zYiAaRzEAAAr6bp4N30004.png" alt="Drawing 13.png" data-nodeid="14400"></p>
<p data-nodeid="12376">输出：4</p>
<p data-nodeid="12377">解释：教师最多可以让 4 个学生坐在可用的座位上，这样他们就无法在考试中作弊。</p>
<blockquote data-nodeid="12378">
<p data-nodeid="12379">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/1349.%E5%8F%82%E5%8A%A0%E8%80%83%E8%AF%95%E7%9A%84%E6%9C%80%E5%A4%A7%E5%AD%A6%E7%94%9F%E6%95%B0.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="14406">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/1349.%E5%8F%82%E5%8A%A0%E8%80%83%E8%AF%95%E7%9A%84%E6%9C%80%E5%A4%A7%E5%AD%A6%E7%94%9F%E6%95%B0.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="14410">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/1349.%E5%8F%82%E5%8A%A0%E8%80%83%E8%AF%95%E7%9A%84%E6%9C%80%E5%A4%A7%E5%AD%A6%E7%94%9F%E6%95%B0.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="14414">Python</a></p>
</blockquote>
<h3 data-nodeid="12380">总结</h3>
<p data-nodeid="12381">在本讲中，我们介绍了通用的 DP 的 6 步破解法，并且罗列了面试中常出现的几种 DP 型题目。这里我还总结了其他一些类型的 DP 题目，你可以参考下图进行专项练习，逐一击破个类型的DP 问题。</p>
<p data-nodeid="12382"><img src="https://s0.lgstatic.com/i/image6/M00/37/61/CioPOWB2zZ2AJiVSAARePu3Wkh8895.png" alt="Drawing 14.png" data-nodeid="14419"></p>
<p data-nodeid="12383">DP 求解的套路基本就是 6 步。不过要熟练运用这种求解方法，你还需要花更多的时间练习。</p>
<h3 data-nodeid="12384">思考题</h3>
<p data-nodeid="12385">在这里，我再给你留一道思考题。</p>
<p data-nodeid="12386"><strong data-nodeid="14431">思考题</strong>：爱丽丝参与一个大致基于纸牌游戏 “21 点” 规则的游戏，描述如下：爱丽丝以 0 分开始，并在她的得分少于 K 分时抽取数字。 抽取时，她从 [1, W] 的范围中随机获得一个整数作为分数进行累计，其中 W 是整数。 每次抽取都是独立的，其结果具有相同的概率。当爱丽丝获得不少于 K 分时，她就停止抽取数字。 爱丽丝的分数不超过 N 的概率是多少？</p>
<p data-nodeid="12387">输入：N = 10, K = 1, W = 10</p>
<p data-nodeid="12388">输出：1.00000</p>
<p data-nodeid="12389">说明：爱丽丝得到一张卡，然后停止。</p>
<blockquote data-nodeid="12390">
<p data-nodeid="12391">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/837.%E6%96%B0-21-%E7%82%B9.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="14438">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/837.%E6%96%B0-21-%E7%82%B9.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="14442">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/837.%E6%96%B0-21-%E7%82%B9.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="14446">Python</a></p>
</blockquote>
<p data-nodeid="12392">DP 虽然看起来很难，不过掌握我们的 6 步破解法之后，学习起来是不是要更轻松一点了呢？接下来我们将要学习15 | 字符串查找：为什么我最终选择了 BM 算法？记得按时来探险。</p>
<h3 data-nodeid="12393">附录：题目出处和代码汇总</h3>
<table data-nodeid="27090">
<thead data-nodeid="27091">
<tr data-nodeid="27092">
<th data-nodeid="27094">兑换硬币</th>
<th data-nodeid="27095"><a href="https://leetcode-cn.com/problems/coin-change/description/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27156">测试平台</a></th>
<th data-nodeid="27096">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/322.%E9%9B%B6%E9%92%B1%E5%85%91%E6%8D%A2.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27160">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/322.%E9%9B%B6%E9%92%B1%E5%85%91%E6%8D%A2.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27164">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/322.%E9%9B%B6%E9%92%B1%E5%85%91%E6%8D%A2.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27168">Python</a></th>
</tr>
</thead>
<tbody data-nodeid="27100">
<tr data-nodeid="27101">
<td data-nodeid="27102">例 1：打劫</td>
<td data-nodeid="27103"><a href="https://leetcode-cn.com/problems/house-robber/description/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27172">测试平台</a></td>
<td data-nodeid="27104">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/198.%E6%89%93%E5%AE%B6%E5%8A%AB%E8%88%8D.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27176">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/198.%E6%89%93%E5%AE%B6%E5%8A%AB%E8%88%8D.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27180">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/198.%E6%89%93%E5%AE%B6%E5%8A%AB%E8%88%8D.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27184">Python</a></td>
</tr>
<tr data-nodeid="27105">
<td data-nodeid="27106">练习题 1</td>
<td data-nodeid="27107"><a href="https://leetcode-cn.com/problems/house-robber-ii/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27188">测试平台</a></td>
<td data-nodeid="27108">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/213.%E6%89%93%E5%AE%B6%E5%8A%AB%E8%88%8D-ii.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27192">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/213.%E6%89%93%E5%AE%B6%E5%8A%AB%E8%88%8D-ii.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27196">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/213.%E6%89%93%E5%AE%B6%E5%8A%AB%E8%88%8D-ii.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27200">Python</a></td>
</tr>
<tr data-nodeid="27109">
<td data-nodeid="27110">例 2：扰乱字符串</td>
<td data-nodeid="27111"><a href="https://leetcode-cn.com/problems/scramble-string/description/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27204">测试平台</a></td>
<td data-nodeid="27112">解法 1：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/87.%E6%89%B0%E4%B9%B1%E5%AD%97%E7%AC%A6%E4%B8%B2.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27208">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/87.%E6%89%B0%E4%B9%B1%E5%AD%97%E7%AC%A6%E4%B8%B2.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27212">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/87.%E6%89%B0%E4%B9%B1%E5%AD%97%E7%AC%A6%E4%B8%B2.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27216">Python</a><br>解法 2：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/87.%E6%89%B0%E4%B9%B1%E5%AD%97%E7%AC%A6%E4%B8%B2.rec.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27221">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/87.%E6%89%B0%E4%B9%B1%E5%AD%97%E7%AC%A6%E4%B8%B2.rec.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27225">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/87.%E6%89%B0%E4%B9%B1%E5%AD%97%E7%AC%A6%E4%B8%B2.rec.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27229">Python</a></td>
</tr>
<tr data-nodeid="27113">
<td data-nodeid="27114">练习题 2</td>
<td data-nodeid="27115"><a href="https://leetcode-cn.com/problems/scramble-string/description/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27233">测试平台</a></td>
<td data-nodeid="27116">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/87.%E6%89%B0%E4%B9%B1%E5%AD%97%E7%AC%A6%E4%B8%B2.rec.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27237">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/87.%E6%89%B0%E4%B9%B1%E5%AD%97%E7%AC%A6%E4%B8%B2.rec.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27241">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/87.%E6%89%B0%E4%B9%B1%E5%AD%97%E7%AC%A6%E4%B8%B2.rec.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27245">Python</a></td>
</tr>
<tr data-nodeid="27117">
<td data-nodeid="27118">例 3</td>
<td data-nodeid="27119"><a href="https://www.acwing.com/problem/content/2/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27249">测试平台</a></td>
<td data-nodeid="27120">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/416.%E5%88%86%E5%89%B2%E7%AD%89%E5%92%8C%E5%AD%90%E9%9B%86.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27253">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/416.%E5%88%86%E5%89%B2%E7%AD%89%E5%92%8C%E5%AD%90%E9%9B%86.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27257">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/416.%E5%88%86%E5%89%B2%E7%AD%89%E5%92%8C%E5%AD%90%E9%9B%86.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27261">Python</a></td>
</tr>
<tr data-nodeid="27121">
<td data-nodeid="27122">练习题 4</td>
<td data-nodeid="27123"><a href="https://www.acwing.com/problem/content/2/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27265">测试平台</a></td>
<td data-nodeid="27124">代码:<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/acwing.01.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27269">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/acwing.01.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27273">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/acwing.01.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27277">Python</a></td>
</tr>
<tr data-nodeid="27125">
<td data-nodeid="27126" class="">练习题 5</td>
<td data-nodeid="27127"><a href="https://www.acwing.com/problem/content/3/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27281">测试平台</a></td>
<td data-nodeid="27128">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/acwing.full.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27285">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/acwing.full.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27289">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/acwing.full.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27293">Python</a></td>
</tr>
<tr data-nodeid="27129">
<td data-nodeid="27130">练习题 6</td>
<td data-nodeid="27131"><a href="https://leetcode-cn.com/problems/target-sum/description/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27297">测试平台</a></td>
<td data-nodeid="27132">解法 1：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/494.%E7%9B%AE%E6%A0%87%E5%92%8C.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27301">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/494.%E7%9B%AE%E6%A0%87%E5%92%8C.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27305">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/494.%E7%9B%AE%E6%A0%87%E5%92%8C.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27309">Python</a><br>解法 2：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/494.%E7%9B%AE%E6%A0%87%E5%92%8C.backtrace.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27314">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/494.%E7%9B%AE%E6%A0%87%E5%92%8C.backtrace.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27318">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/494.%E7%9B%AE%E6%A0%87%E5%92%8C.backtrace.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27322">Python</a></td>
</tr>
<tr data-nodeid="27133">
<td data-nodeid="27134">例 4</td>
<td data-nodeid="27135"><a href="https://leetcode-cn.com/problems/house-robber-iii/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27326">测试平台</a></td>
<td data-nodeid="27136">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/337.%E6%89%93%E5%AE%B6%E5%8A%AB%E8%88%8D-iii.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27330">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/337.%E6%89%93%E5%AE%B6%E5%8A%AB%E8%88%8D-iii.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27334">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/337.%E6%89%93%E5%AE%B6%E5%8A%AB%E8%88%8D-iii.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27338">Python</a></td>
</tr>
<tr data-nodeid="27137">
<td data-nodeid="27138">练习题 7</td>
<td data-nodeid="27139"><a href="https://leetcode-cn.com/problems/diameter-of-binary-tree/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27342">测试平台</a></td>
<td data-nodeid="27140">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/543.%E4%BA%8C%E5%8F%89%E6%A0%91%E7%9A%84%E7%9B%B4%E5%BE%84.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27346">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/543.%E4%BA%8C%E5%8F%89%E6%A0%91%E7%9A%84%E7%9B%B4%E5%BE%84.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27350">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/543.%E4%BA%8C%E5%8F%89%E6%A0%91%E7%9A%84%E7%9B%B4%E5%BE%84.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27354">Python</a></td>
</tr>
<tr data-nodeid="27141">
<td data-nodeid="27142">例 5</td>
<td data-nodeid="27143"><a href="https://leetcode-cn.com/problems/maximize-score-after-n-operations/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27358">测试平台</a></td>
<td data-nodeid="27144">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/1799.n-%E6%AC%A1%E6%93%8D%E4%BD%9C%E5%90%8E%E7%9A%84%E6%9C%80%E5%A4%A7%E5%88%86%E6%95%B0%E5%92%8C.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27362">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/1799.n-%E6%AC%A1%E6%93%8D%E4%BD%9C%E5%90%8E%E7%9A%84%E6%9C%80%E5%A4%A7%E5%88%86%E6%95%B0%E5%92%8C.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27366">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/1799.n-%E6%AC%A1%E6%93%8D%E4%BD%9C%E5%90%8E%E7%9A%84%E6%9C%80%E5%A4%A7%E5%88%86%E6%95%B0%E5%92%8C.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27370">Python</a></td>
</tr>
<tr data-nodeid="27145">
<td data-nodeid="27146">练习题 8</td>
<td data-nodeid="27147"><a href="https://leetcode-cn.com/problems/maximum-students-taking-exam/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27374">测试平台</a></td>
<td data-nodeid="27148">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/1349.%E5%8F%82%E5%8A%A0%E8%80%83%E8%AF%95%E7%9A%84%E6%9C%80%E5%A4%A7%E5%AD%A6%E7%94%9F%E6%95%B0.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27378">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/1349.%E5%8F%82%E5%8A%A0%E8%80%83%E8%AF%95%E7%9A%84%E6%9C%80%E5%A4%A7%E5%AD%A6%E7%94%9F%E6%95%B0.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27382">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/1349.%E5%8F%82%E5%8A%A0%E8%80%83%E8%AF%95%E7%9A%84%E6%9C%80%E5%A4%A7%E5%AD%A6%E7%94%9F%E6%95%B0.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27386">Python</a></td>
</tr>
<tr data-nodeid="27149">
<td data-nodeid="27150">思考题</td>
<td data-nodeid="27151"><a href="https://leetcode-cn.com/problems/new-21-game/description/?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27390">测试平台</a></td>
<td data-nodeid="27152">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/837.%E6%96%B0-21-%E7%82%B9.java?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27394">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/837.%E6%96%B0-21-%E7%82%B9.cpp?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27398">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/14.DP/837.%E6%96%B0-21-%E7%82%B9.py?fileGuid=xxQTRXtVcqtHK6j8" data-nodeid="27402">Python</a></td>
</tr>
</tbody>
</table>