### 本资源由 itjc8.com 收集整理
<p data-nodeid="7945" class="">队列在日常生活中很常见，当我们排队买票看电影的时候，排在队列前面的人先入场，排在队列后面的人只能后入场。在计算机系统中常用<strong data-nodeid="8370">先进先出</strong>（<strong data-nodeid="8371">F</strong>irst <strong data-nodeid="8372">I</strong>n <strong data-nodeid="8373">F</strong>irst <strong data-nodeid="8374">O</strong>ut）的队列来表示这种场景。</p>
<p data-nodeid="7946">但是除了这种 FIFO 队列以外，还有一种队列需要注意，就是<strong data-nodeid="8380">单调队列</strong>，由于课本上不常讲，面试中又容易出现，因此需要格外注意。让我们一起把这个数据结构的知识图谱丰富起来。</p>
<p data-nodeid="7947"><img src="https://s0.lgstatic.com/i/image6/M00/11/0A/Cgp9HWA_RiuASOCMAACEYQ4Rhu8096.png" alt="Drawing 1.png" data-nodeid="8383"></p>
<p data-nodeid="7948">下面我要介绍的内容在实际的工程应用中也经常会用到，比如：</p>
<ul data-nodeid="7949">
<li data-nodeid="7950">
<p data-nodeid="7951">Redis 的消息队列，用来搭建秒杀系统；</p>
</li>
<li data-nodeid="7952">
<p data-nodeid="7953">LevelDB 的写入队列，可以保证数据写入的顺序；</p>
</li>
<li data-nodeid="7954">
<p data-nodeid="7955">Qemu 的 Ring Buffer，用来完成数据的高效传输。</p>
</li>
</ul>
<p data-nodeid="7956">它们是很多基础设施的基本算法，比如操作系统、数据库、TCP/IP 协议栈等。OK, Let's Go!</p>
<h3 data-nodeid="7957">FIFO 队列</h3>
<p data-nodeid="7958">我们先从基本的 FIFO 队列入手，其特点用动画表示如下：</p>
<p data-nodeid="7959"><img src="https://s0.lgstatic.com/i/image6/M00/11/0B/Cgp9HWA_RuiAYzgpAADIHD6hfoY449.gif" alt="1.gif" data-nodeid="8396"></p>
<p data-nodeid="7960">可以发现 FIFO 有两个特点：</p>
<ul data-nodeid="7961">
<li data-nodeid="7962">
<p data-nodeid="7963">push 元素时，总是将元素放在队列尾部；</p>
</li>
<li data-nodeid="7964">
<p data-nodeid="7965">pop 元素时，总是将队列首部的元素扔掉。</p>
</li>
</ul>
<p data-nodeid="7966">但只知道 FIFO 的特性，并不能从容地应对复杂的面试。因此我们还需要进一步对FIFO 加以深挖，力求在面试中游刃有余。接下来我将通过大厂面试题，带你学习这块重点知识。</p>
<h4 data-nodeid="7967">例 1：二叉树的层次遍历（两种方法）</h4>
<p data-nodeid="7968">【<strong data-nodeid="8407">题目</strong>】从上到下按层打印二叉树，同一层结点按从左到右的顺序打印，每一层打印到一行。</p>
<p data-nodeid="7969">输入：</p>
<p data-nodeid="7970"><img src="https://s0.lgstatic.com/i/image6/M00/11/08/CioPOWA_RwyAWm07AACF5LV9ej0062.png" alt="Drawing 4.png" data-nodeid="8411"></p>
<p data-nodeid="7971">输出：[[3], [9, 8], [6, 7]]</p>
<pre class="lang-java" data-nodeid="7972"><code data-language="java"><span class="hljs-comment">// 二叉树结点的定义</span>
<span class="hljs-keyword">public</span> <span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">TreeNode</span> </span>{
  <span class="hljs-comment">// 树结点中的元素值</span>
  <span class="hljs-keyword">int</span> val = <span class="hljs-number">0</span>;
  <span class="hljs-comment">// 二叉树结点的左子结点</span>
  TreeNode left = <span class="hljs-keyword">null</span>;
  <span class="hljs-comment">// 二叉树结点的右子结点</span>
  TreeNode right = <span class="hljs-keyword">null</span>;
}
</code></pre>
<p data-nodeid="7973">【<strong data-nodeid="8435">分析</strong>】这道题已经在非常多的大厂面试中出现过了，比如微软，美团，腾讯等，因此你务必要掌握题目涉及的思想和原理。在真正开始写代码之前，我们还是参考“<a href="https://kaiwu.lagou.com/course/courseInfo.htm?courseId=685#/detail/pc?id=6690" data-nodeid="8433">第 01 讲</a>”中给出的深度思考的路线，从分析题目到写出代码“走”一遍。</p>
<p data-nodeid="7974"><strong data-nodeid="8443">1. 模拟</strong><br>
首先我们在这棵树上进行模拟，动图演示效果如下所示：</p>
<p data-nodeid="7975"><img src="https://s0.lgstatic.com/i/image6/M00/11/08/CioPOWA_RyiAQ0IkAAbQTq2M1V8935.gif" alt="2.gif" data-nodeid="8446"></p>
<p data-nodeid="7976"><strong data-nodeid="8454">2. 规律</strong><br>
通过运行的模拟，可以总结出以下两个特点。</p>
<p data-nodeid="7977"><strong data-nodeid="8463">（1）广度遍历</strong>（<strong data-nodeid="8464">层次遍历</strong>）：由于二叉树的特点，当我们拿到第 N 层的结点 A 之后，可以通过 A 的 left 和 right 指针拿到下一层的结点。</p>
<p data-nodeid="7978"><strong data-nodeid="8481">（2）顺序输出</strong>：每层输出时，排在<strong data-nodeid="8482">左边的结点</strong>，它的<strong data-nodeid="8483">子结点同样</strong>排在<strong data-nodeid="8484">下一层最左边</strong>。</p>
<p data-nodeid="7979"><strong data-nodeid="8490">3. 匹配</strong></p>
<p data-nodeid="7980">当你发现题目具备<strong data-nodeid="8508">广度遍历</strong>（<strong data-nodeid="8509">分层遍历</strong>）<strong data-nodeid="8511">和顺序输出的特点，<strong data-nodeid="8510">就应该想到用</strong>FIFO 队列</strong>来试一试。</p>
<p data-nodeid="7981"><strong data-nodeid="8515">4.. 边界</strong></p>
<p data-nodeid="7982">关于二叉树的边界，需要考虑一种空二叉树的情况。当遇到一棵空的二叉树，有两种解决办法。</p>
<p data-nodeid="7983">（1）<strong data-nodeid="8522">特殊判断</strong>：如果发现是一棵空二叉树，就直接返回空结果。</p>
<p data-nodeid="7984">（2）<strong data-nodeid="8528">制定一个规则</strong>：不要让空指针进入到 FIFO 队列。</p>
<p data-nodeid="7985">我个人比较喜欢第 2 种方案，因为代码一致性更好（一致性是指不需要为各种特殊情况再添加额外的 if/else 来处理）。所以接下来我将从“<strong data-nodeid="8534">制定一个规则：不要让空指针进入队列</strong>”上考虑代码的实现。</p>
<p data-nodeid="7986">【<strong data-nodeid="8540">画图</strong>】当我们拿到一道题，脑海中已经关联了相应的数据结构：FIFO 队列，下面就可以利用它来画图了。</p>
<p data-nodeid="7987">不过，二叉树的层次遍历与标准的 FIFO 队列不太一样，需要在每一层开始处理之前，记录一下 Queue Size（当前层里面结点的个数），演示如下图所示：</p>
<p data-nodeid="7988"><img src="https://s0.lgstatic.com/i/image6/M01/11/0C/Cgp9HWA_R4WADJ8eACXiUG8cfgY721.gif" alt="3.gif" data-nodeid="8544"></p>
<p data-nodeid="7989">Step1. 在一开始首先将根结点 3 加入队列中。</p>
<p data-nodeid="7990">Step 2. 开始<strong data-nodeid="8554">新一层遍历</strong>，记录下当前队列长度 QSize=1，初始化当前层存放结果的[]。</p>
<p data-nodeid="7991">Step 3. 将结点 3 出队，然后将其放到当前层中。</p>
<p data-nodeid="7992">Step 4. 再将结点 3 的左右子结点分别入队。QSize = 1 的这一层已经处理完毕。</p>
<p data-nodeid="7993">Step 5. <strong data-nodeid="8565">开始新一层的遍历</strong>。记录下新一层的 QSize = 2，初始化新的当前层存放当前层结果的[]。</p>
<p data-nodeid="7994">Step 6. 从队列中取出 9，放到当前层结果中。结点 9 没有左右子结点，不需要继续处理左右子结点。</p>
<p data-nodeid="7995">Step 7. 从队列中取出 8，放到当前层结果中。</p>
<p data-nodeid="7996">Step 8. 将结点 8 的左右子结点分别入队。此时，QSize = 2 的部分已经全部处理完成。</p>
<p data-nodeid="7997">Step 9.<strong data-nodeid="8577">开始新一层的遍历</strong>，记录下当前队列中的结点数 QSize = 2，并且生成存放当前层结果的 list[]。</p>
<p data-nodeid="7998">Step 10. 将队首结点 6 出队放到当前层结果中。结点 6 没有左右子结点，没有元素要入队。</p>
<p data-nodeid="7999">Step 11. 将队首结点 7 出队，放到当前层结果中。结点 7 没有左右子结点，没有元素要入队。</p>
<p data-nodeid="8000">结束，返回我们层次遍历的结果。</p>
<p data-nodeid="8001">【<strong data-nodeid="8586">代码</strong>】现在我们有解题思路，也有运行图，接下来就可以写出以下核心代码（解析在注释里）：</p>
<pre class="lang-java" data-nodeid="8002"><code data-language="java"><span class="hljs-class"><span class="hljs-keyword">class</span>&nbsp;<span class="hljs-title">Solution</span>&nbsp;</span>{
&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-keyword">public</span>&nbsp;List&lt;List&lt;Integer&gt;&gt;&nbsp;levelOrder(TreeNode&nbsp;root)&nbsp;{
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-comment">//&nbsp;生成FIFO队列</span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Queue&lt;TreeNode&gt;&nbsp;Q&nbsp;=&nbsp;<span class="hljs-keyword">new</span>&nbsp;LinkedList&lt;&gt;();
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-comment">//&nbsp;如果结点不为空，那么加入FIFO队列</span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-keyword">if</span>&nbsp;(root&nbsp;!=&nbsp;<span class="hljs-keyword">null</span>)&nbsp;{
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Q.offer(root);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-comment">//&nbsp;ans用于保存层次遍历的结果</span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;List&lt;List&lt;Integer&gt;&gt;&nbsp;ans&nbsp;=&nbsp;<span class="hljs-keyword">new</span>&nbsp;LinkedList&lt;&gt;();
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-comment">// 开始利用FIFO队列进行层次遍历</span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-keyword">while</span>&nbsp;(Q.size()&nbsp;&gt;&nbsp;<span class="hljs-number">0</span>)&nbsp;{
            <span class="hljs-comment">// 取出当前层里面元素的个数</span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-keyword">final</span>&nbsp;<span class="hljs-keyword">int</span>&nbsp;qSize&nbsp;=&nbsp;Q.size();
            <span class="hljs-comment">// 当前层的结果存放于tmp链表中</span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;List&lt;Integer&gt;&nbsp;tmp&nbsp;=&nbsp;<span class="hljs-keyword">new</span>&nbsp;LinkedList&lt;&gt;();
            <span class="hljs-comment">// 遍历当前层的每个结点</span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-keyword">for</span>&nbsp;(<span class="hljs-keyword">int</span>&nbsp;i&nbsp;=&nbsp;<span class="hljs-number">0</span>;&nbsp;i&nbsp;&lt;&nbsp;qSize;&nbsp;i++)&nbsp;{
                <span class="hljs-comment">// 当前层前面的结点先出队</span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;TreeNode&nbsp;cur&nbsp;=&nbsp;Q.poll();
                <span class="hljs-comment">// 把结果存放当于当前层中</span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;tmp.add(cur.val);
                <span class="hljs-comment">// 把下一层的结点入队，注意入队时需要非空才可以入队。</span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-keyword">if</span>&nbsp;(cur.left&nbsp;!=&nbsp;<span class="hljs-keyword">null</span>)&nbsp;{
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Q.offer(cur.left);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-keyword">if</span>&nbsp;(cur.right&nbsp;!=&nbsp;<span class="hljs-keyword">null</span>)&nbsp;{
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Q.offer(cur.right);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}
            <span class="hljs-comment">// 把当前层的结果放到返回值里面。</span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ans.add(tmp);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-keyword">return</span>&nbsp;ans;
&nbsp;&nbsp;&nbsp;&nbsp;}
}
</code></pre>
<blockquote data-nodeid="21869">
<p data-nodeid="21870" class="te-preview-highlight">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/01.TreeLevelOrder.java" data-nodeid="21874">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/01.TreeLevelOrder.cpp" data-nodeid="21878">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/01.TreeLevelOrder.py" data-nodeid="21882">Python</a></p>
</blockquote>




<p data-nodeid="8005"><strong data-nodeid="8603">复杂度分析</strong>：由于二叉树的每个结点，我们都只访问了一遍，所以时间复杂度为 O(n)。如果不算返回的数组，那么空间复杂度为 O(k)，这里的 k 表示二叉树横向最宽的那一层的结点数目。</p>
<p data-nodeid="8006">【<strong data-nodeid="8609">小结</strong>】写完代码之后，对 FIFO 队列进行一轮总结。现在除了知道先进先出的特点之外，还可以进一步细化知识点，如下图所示：</p>
<p data-nodeid="8007"><img src="https://s0.lgstatic.com/i/image6/M01/11/09/CioPOWA_R6aAdoJvAACnbi7IL-c504.png" alt="Drawing 22.png" data-nodeid="8612"></p>
<p data-nodeid="8008">这道题是很多高频面试题的“<strong data-nodeid="8618">母题</strong>”，可以衍生出很多子题出来，因此建议你把这道题研究透彻。如果还有哪里不理解，可以在留言区提问。</p>
<p data-nodeid="8009">在依靠 FIFO 队列的解法中，我们<strong data-nodeid="8624">利用 QSize 得到当前层的元素个数，然后再开始执行 FIFO 是处理分层遍历的关键</strong>。下面我再向你介绍另外一种更直观的思路。</p>
<p data-nodeid="8010">【<strong data-nodeid="8630">解法二</strong>】再来回顾一下题目的特点：</p>
<ul data-nodeid="8011">
<li data-nodeid="8012">
<p data-nodeid="8013">分层遍历</p>
</li>
<li data-nodeid="8014">
<p data-nodeid="8015">顺序遍历</p>
</li>
</ul>
<p data-nodeid="8016">那么我们是不是可以用 List 来表示每一层，把下一层的结点统一放到一个新生成的 List 里面。示意图如下：</p>
<p data-nodeid="8017"><img src="https://s0.lgstatic.com/i/image6/M00/11/09/CioPOWA_R9eAb3DqAA5cp3pt5r8391.gif" alt="4.gif" data-nodeid="8636"></p>
<p data-nodeid="8018">Step 1. 首先将结点 3 加入 cur,，形成 cur=[3]。</p>
<p data-nodeid="8019">Step 2. 开始依次遍历当前层 cur, 这里 cur 只有结点 3，依次把结点 3 的左子结点和右子结点加入 next，形成 [9, 8]。</p>
<p data-nodeid="8020">Step 3. 将 cur 指向 next，并且 next 设置为 []</p>
<p data-nodeid="8021">Step 4. 依次遍历 cur，并将每个结点的左右子结点放到 next 中。</p>
<p data-nodeid="8022">Step 5. 将 cur 指向 next。并依次遍历。由于这是最后一层，所以不会再生成 next。</p>
<p data-nodeid="8023">Step 6. 最后得到层次遍历的结果。</p>
<p data-nodeid="8024">根据这个思路，写出的代码如下（解析在注释里）：</p>
<pre class="lang-java" data-nodeid="8025"><code data-language="java"><span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">Solution</span> </span>{
&nbsp; &nbsp; <span class="hljs-keyword">public</span> List&lt;List&lt;Integer&gt;&gt; levelOrder(TreeNode root) {
&nbsp; &nbsp; &nbsp; &nbsp; List&lt;List&lt;Integer&gt;&gt; ans = <span class="hljs-keyword">new</span> ArrayList&lt;&gt;();
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// 初始化当前层结点</span>
&nbsp; &nbsp; &nbsp; &nbsp; List&lt;TreeNode&gt; curLevel = <span class="hljs-keyword">new</span> ArrayList&lt;&gt;();
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// 注意：需要root不空的时候才加到里面。</span>
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-keyword">if</span> (root != <span class="hljs-keyword">null</span>) {
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; curLevel.add(root);
&nbsp; &nbsp; &nbsp; &nbsp; }
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-keyword">while</span> (curLevel.size() &gt; <span class="hljs-number">0</span>) {
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// 准备用来存放下一层的结点</span>
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; List&lt;TreeNode&gt; nextLevel = <span class="hljs-keyword">new</span> ArrayList&lt;&gt;();
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// 用来存放当前层的结果</span>
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; List&lt;Integer&gt; curResult = <span class="hljs-keyword">new</span> ArrayList&lt;&gt;();
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// 遍历当前层的每个结点</span>
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-keyword">for</span> (TreeNode cur: curLevel) {
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// 把当前层的值存放到当前结果里面</span>
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; curResult.add(cur.val);
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// 生成下一层</span>
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-keyword">if</span> (cur.left != <span class="hljs-keyword">null</span>) {
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; nextLevel.add(cur.left);
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-keyword">if</span> (cur.right != <span class="hljs-keyword">null</span>) {
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; nextLevel.add(cur.right);
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; }
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// 注意这里的更迭!滚动前进</span>
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; curLevel = nextLevel;
            <span class="hljs-comment">// 把当前层的值放到结果里面</span>
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ans.add(curResult);
&nbsp; &nbsp; &nbsp; &nbsp; }
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-keyword">return</span> ans;
&nbsp; &nbsp; }
}
</code></pre>
<blockquote data-nodeid="8026">
<p data-nodeid="8027">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/01.2.TreeLevelOrder.java" data-nodeid="8657">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/01.2.TreeLevelOrder.cpp" data-nodeid="8661">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/01.2.TreeLevelOrder.py" data-nodeid="8665">Python</a></p>
</blockquote>
<p data-nodeid="8028">通过这个有趣的解法，我们知道，FIFO 队列不仅可以用 Queue 表示，还可以用两层 ArrayList 来表示，均可达到同样的效果。再把思路扩展一下，思考<strong data-nodeid="8671">是否还有其他的形式可以表达 FIFO 队列呢</strong>？请看下面这道思考题。</p>
<p data-nodeid="8029">【<strong data-nodeid="8677">思考题</strong>】给定一棵二叉树，如下图所示，树中的结点稍微有点变化，定义如下：</p>
<p data-nodeid="8030"><img src="https://s0.lgstatic.com/i/image6/M00/11/09/CioPOWA_SB2AMn_VAACXDtKnvt4099.png" alt="Drawing 30.png" data-nodeid="8680"></p>
<pre class="lang-java" data-nodeid="8031"><code data-language="java">struct&nbsp;Node&nbsp;{
&nbsp;&nbsp;<span class="hljs-keyword">int</span>&nbsp;val&nbsp;=&nbsp;<span class="hljs-number">0</span>;
&nbsp;&nbsp;Node&nbsp;*left&nbsp;=&nbsp;<span class="hljs-keyword">null</span>;
&nbsp;&nbsp;Node&nbsp;*right&nbsp;=&nbsp;<span class="hljs-keyword">null</span>;
&nbsp;&nbsp;Node&nbsp;*next&nbsp;=&nbsp;<span class="hljs-keyword">null</span>;
}
</code></pre>
<p data-nodeid="8032">希望你能修改二叉树里所有的 next 指针，使其指向右边的结点，如果右边没有结点，那么设置为空指针。</p>
<blockquote data-nodeid="8033">
<p data-nodeid="8034">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/01.3.TreeNext.java" data-nodeid="8685">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/01.3.TreeNext.cpp" data-nodeid="8689">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/01.3.TreeNext.py" data-nodeid="8693">Python</a></p>
</blockquote>
<p data-nodeid="8035">至此，经过我们的“浇灌”，FIFO 队列长出了更多的“树叶”。为了方便你理解，我把解决这类题目的重点总结在一张大图中：</p>
<p data-nodeid="8036"><img src="https://s0.lgstatic.com/i/image6/M00/11/0C/Cgp9HWA_SC2AdwWAAADBBGybQP0811.png" alt="Drawing 33.png" data-nodeid="8697"></p>
<p data-nodeid="8037">【<strong data-nodeid="8707">题目扩展</strong>】切忌盲目刷题，其实只要吃透一道题，就可以解决很多类似的题目。只要掌握分层遍历的技巧，以后再碰到类似的题目，就再也难不住你了。这里我为你总结了一张关于“<strong data-nodeid="8708">二叉树的层次遍历</strong>”的解题技巧，如下图所示：</p>
<p data-nodeid="8038"><img src="https://s0.lgstatic.com/i/image6/M01/11/0C/Cgp9HWA_SEGALU-UAADmDhvBE6M451.png" alt="Drawing 35.png" data-nodeid="8711"></p>
<blockquote data-nodeid="8039">
<p data-nodeid="8040">可以点开这里，查看题目的<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/README.md" data-nodeid="8715">信息，代码</a>。</p>
</blockquote>
<h4 data-nodeid="8041">例 2：循环队列</h4>
<p data-nodeid="8042">【<strong data-nodeid="8723">题目</strong>】设计一个可以容纳 k 个元素的循环队列。需要实现以下接口：</p>
<pre class="lang-java" data-nodeid="8043"><code data-language="java"><span class="hljs-class"><span class="hljs-keyword">class</span>&nbsp;<span class="hljs-title">MyCircularQueue</span>&nbsp;</span>{
&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-comment">//&nbsp;参数k表示这个循环队列最多只能容纳k个元素</span>
&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-function"><span class="hljs-keyword">public</span>&nbsp;<span class="hljs-title">MyCircularQueue</span><span class="hljs-params">(<span class="hljs-keyword">int</span>&nbsp;k)</span></span>;
&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-comment">//&nbsp;将value放到队列中,&nbsp;成功返回true</span>
&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-function"><span class="hljs-keyword">public</span>&nbsp;<span class="hljs-keyword">boolean</span>&nbsp;<span class="hljs-title">enQueue</span><span class="hljs-params">(<span class="hljs-keyword">int</span>&nbsp;value)</span></span>;
&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-comment">//&nbsp;删除队首元素，成功返回true</span>
&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-function"><span class="hljs-keyword">public</span>&nbsp;<span class="hljs-keyword">boolean</span>&nbsp;<span class="hljs-title">deQueue</span><span class="hljs-params">()</span></span>;
&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-comment">//&nbsp;得到队首元素，如果为空，返回-1</span>
&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-function"><span class="hljs-keyword">public</span>&nbsp;<span class="hljs-keyword">int</span>&nbsp;<span class="hljs-title">Front</span><span class="hljs-params">()</span></span>;
&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-comment">//&nbsp;得到队尾元素，如果队列为空，返回-1</span>
&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-function"><span class="hljs-keyword">public</span>&nbsp;<span class="hljs-keyword">int</span>&nbsp;<span class="hljs-title">Rear</span><span class="hljs-params">()</span></span>;
&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-comment">//&nbsp;看一下循环队列是否为空</span>
&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-function"><span class="hljs-keyword">public</span>&nbsp;<span class="hljs-keyword">boolean</span>&nbsp;<span class="hljs-title">isEmpty</span><span class="hljs-params">()</span></span>;
&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-comment">//&nbsp;看一下循环队列是否已放满k个元素</span>
&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-function"><span class="hljs-keyword">public</span>&nbsp;<span class="hljs-keyword">boolean</span>&nbsp;<span class="hljs-title">isFull</span><span class="hljs-params">()</span></span>;
}
</code></pre>
<p data-nodeid="8044">【<strong data-nodeid="8733">分析</strong>】循环队列是一个书本上非常经典的关于队列的例子，在工程实践中也有很多运用，比如 Ring Buffer、生产者消费者队列。我去<strong data-nodeid="8734">微软面试</strong>的时候也遇到了这道经典的题目。正好借着讲 FIFO 队列的机会，我再给你介绍一下循环队列。</p>
<p data-nodeid="8045">循环队列的重点在于<strong data-nodeid="8744">循环使用固定空间</strong>，难点在于<strong data-nodeid="8745">控制好 front/rear 两个首尾指示器</strong>。这里我会介绍两种实现。</p>
<p data-nodeid="8046">【<strong data-nodeid="8751">方法</strong> 1】只使用 k 个元素的空间，三个变量 front, rear, used 来控制循环队列的使用。分别标记 k = 6 时，循环队列的三种情况，如下图所示：</p>
<p data-nodeid="8047"><img src="https://s0.lgstatic.com/i/image6/M01/11/0C/Cgp9HWA_SF2AEV3pAADK0cYKmv8794.png" alt="Drawing 36.png" data-nodeid="8754"></p>
<p data-nodeid="8048">由图可知，在一般情况下，front 和 rear 都是不相等的。但是，如果仔细观察，你会发现在空队列与满队列的时候，front 和 rear 是相等的。那此时该怎么处理呢？</p>
<p data-nodeid="8049">通过上述分析，可以知道只用 front 和 rear 两个变量，还不足以区分是空队列还是满队列，因此我们还需要用到额外的变量做进一步区分。一种比较简单的办法就是<strong data-nodeid="8761">采用 used 变量</strong>，标记已经放了多少个元素在循环队列里面。</p>
<ul data-nodeid="8050">
<li data-nodeid="8051">
<p data-nodeid="8052">如图（a）所示，当队列为空的时候，used == 0；</p>
</li>
<li data-nodeid="8053">
<p data-nodeid="8054">如图（b）所示，当队列满的时候，used == k。</p>
</li>
</ul>
<p data-nodeid="8055">虽然从图片来看这是一个循环数组，但是面试官要求只能使用一个普通的数组来实现。在下标的移动上，要特别注意不要越界。下标只能在 [0, k-1] 范围里面移动。以下 3 点需要你格外注意，正常情况下：</p>
<ol data-nodeid="8056">
<li data-nodeid="8057">
<p data-nodeid="8058">index = i 的后一个是 i + 1，前一个是 i - 1</p>
</li>
<li data-nodeid="8059">
<p data-nodeid="8060">index = k-1 的后一个就是 index = 0</p>
</li>
<li data-nodeid="8061">
<p data-nodeid="8062">index = 0 的前一个是 index = k-1</p>
</li>
</ol>
<p data-nodeid="8063">实际上，这三个式子都可以利用<strong data-nodeid="8777">取模的技巧</strong>来统一处理：</p>
<ul data-nodeid="8064">
<li data-nodeid="8065">
<p data-nodeid="8066">index = i 的后一个 (i + 1) % capacity</p>
</li>
<li data-nodeid="8067">
<p data-nodeid="8068">index = i 的前一个(i - 1 + capacity) % capacity</p>
</li>
</ul>
<p data-nodeid="8069"><em data-nodeid="8784"><strong data-nodeid="8783">注意：所有的循环数组下标的处理都需要按照这个取模方法来。</strong></em></p>
<p data-nodeid="8070">通过前面的分析， 我们可以利用 front, rear, used 来写出循环队列的代码，如下所示（解析在注释里）：</p>
<pre class="lang-java" data-nodeid="8071"><code data-language="java"><span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">MyCircularQueue</span> </span>{
    <span class="hljs-comment">// 已经使用的元素个数</span>
    <span class="hljs-keyword">private</span> <span class="hljs-keyword">int</span> used = <span class="hljs-number">0</span>;
    <span class="hljs-comment">// 第一个元素所在位置</span>
    <span class="hljs-keyword">private</span> <span class="hljs-keyword">int</span> front = <span class="hljs-number">0</span>;
    <span class="hljs-comment">// rear是enQueue可在存放的位置</span>
    <span class="hljs-comment">// 注意开闭原则</span>
    <span class="hljs-comment">// [front, rear)</span>
    <span class="hljs-keyword">private</span> <span class="hljs-keyword">int</span> rear = <span class="hljs-number">0</span>;
    <span class="hljs-comment">// 循环队列最多可以存放的元素个数</span>
    <span class="hljs-keyword">private</span> <span class="hljs-keyword">int</span> capacity = <span class="hljs-number">0</span>;
    <span class="hljs-comment">// 循环队列的存储空间</span>
    <span class="hljs-keyword">private</span> <span class="hljs-keyword">int</span>[] a = <span class="hljs-keyword">null</span>;
    <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-title">MyCircularQueue</span><span class="hljs-params">(<span class="hljs-keyword">int</span> k)</span> </span>{
        <span class="hljs-comment">// 初始化循环队列</span>
        capacity = k;
        a = <span class="hljs-keyword">new</span> <span class="hljs-keyword">int</span>[capacity];
    }
    <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">boolean</span> <span class="hljs-title">enQueue</span><span class="hljs-params">(<span class="hljs-keyword">int</span> value)</span> </span>{
        <span class="hljs-comment">// 如果已经放满了</span>
        <span class="hljs-keyword">if</span> (isFull()) {
            <span class="hljs-keyword">return</span> <span class="hljs-keyword">false</span>;
        }
        <span class="hljs-comment">// 如果没有放满，那么a[rear]用来存放新进来的元素</span>
        a[rear] = value;
        <span class="hljs-comment">// rear注意取模</span>
        rear = (rear + <span class="hljs-number">1</span>) % capacity;
        <span class="hljs-comment">// 已经使用的空间</span>
        used++;
        <span class="hljs-comment">// 存放成功!</span>
        <span class="hljs-keyword">return</span> <span class="hljs-keyword">true</span>;
    }
    <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">boolean</span> <span class="hljs-title">deQueue</span><span class="hljs-params">()</span> </span>{
        <span class="hljs-comment">// 如果是一个空队列，当然不能出队</span>
        <span class="hljs-keyword">if</span> (isEmpty()) {
            <span class="hljs-keyword">return</span> <span class="hljs-keyword">false</span>;
        }
        <span class="hljs-comment">// 第一个元素取出</span>
        <span class="hljs-keyword">int</span> ret = a[front];
        <span class="hljs-comment">// 注意取模</span>
        front = (front + <span class="hljs-number">1</span>) % capacity;
        <span class="hljs-comment">// 已经存放的元素减减</span>
        used--;
        <span class="hljs-comment">// 取出元素成功</span>
        <span class="hljs-keyword">return</span> <span class="hljs-keyword">true</span>;
    }
    <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">int</span> <span class="hljs-title">Front</span><span class="hljs-params">()</span> </span>{
        <span class="hljs-comment">// 如果为空，不能取出队首元素</span>
        <span class="hljs-keyword">if</span> (isEmpty()) {
            <span class="hljs-keyword">return</span> -<span class="hljs-number">1</span>;
        }
        <span class="hljs-comment">// 取出队首元素</span>
        <span class="hljs-keyword">return</span> a[front];
    }
    <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">int</span> <span class="hljs-title">Rear</span><span class="hljs-params">()</span> </span>{
        <span class="hljs-comment">// 如果为空，不能取出队尾元素</span>
        <span class="hljs-keyword">if</span> (isEmpty()) {
            <span class="hljs-keyword">return</span> -<span class="hljs-number">1</span>;
        }
        <span class="hljs-comment">// 注意：这里不能使用rear - 1</span>
        <span class="hljs-comment">// 需要取模</span>
        <span class="hljs-keyword">int</span> tail = (rear - <span class="hljs-number">1</span> + capacity) % capacity;
        <span class="hljs-keyword">return</span> a[tail];
    }
    <span class="hljs-comment">// 队列是否为空</span>
    <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">boolean</span> <span class="hljs-title">isEmpty</span><span class="hljs-params">()</span> </span>{
        <span class="hljs-keyword">return</span> used == <span class="hljs-number">0</span>;
    }
    <span class="hljs-comment">// 队列是否满了</span>
    <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">boolean</span> <span class="hljs-title">isFull</span><span class="hljs-params">()</span> </span>{
        <span class="hljs-keyword">return</span> used == capacity;
    }
}
</code></pre>
<blockquote data-nodeid="8072">
<p data-nodeid="8073">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/622.%E8%AE%BE%E8%AE%A1%E5%BE%AA%E7%8E%AF%E9%98%9F%E5%88%97.method1.java" data-nodeid="8789">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/622.%E8%AE%BE%E8%AE%A1%E5%BE%AA%E7%8E%AF%E9%98%9F%E5%88%97.method1.cpp" data-nodeid="8793">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/622.%E8%AE%BE%E8%AE%A1%E5%BE%AA%E7%8E%AF%E9%98%9F%E5%88%97.method1.py" data-nodeid="8797">Python</a></p>
</blockquote>
<p data-nodeid="8074"><strong data-nodeid="8802">复杂度分析</strong>：入队操作与出队操作都是 O(1)。</p>
<p data-nodeid="8075">【<strong data-nodeid="8808">方法 2</strong>】方法 1 利用 used 变量对满队列和空队列进行了区分。实际上，这种区分方式还有另外一种办法，使用 k+1 个元素的空间，两个变量 front, rear 来控制循环队列的使用。具体如下：</p>
<ul data-nodeid="8076">
<li data-nodeid="8077">
<p data-nodeid="8078">在申请数组空间的时候，申请 k + 1 个空间；</p>
</li>
<li data-nodeid="8079">
<p data-nodeid="8080">在放满循环队列的时候，必须要保证 rear 与 front 之间有空隙。</p>
</li>
</ul>
<p data-nodeid="8081"><strong data-nodeid="8823">如下图</strong>（<strong data-nodeid="8824">此时 k = 5</strong>）<strong data-nodeid="8825">所示</strong>：</p>
<p data-nodeid="8082"><img src="https://s0.lgstatic.com/i/image6/M01/11/09/CioPOWA_SHeAP85DAADKwUx6Fio771.png" alt="Drawing 38.png" data-nodeid="8828"></p>
<p data-nodeid="8083">此时，可以发现，循环队列实际上是浪费了一个元素的空间。这个浪费的元素必须卡在 front 与 rear 之间。判断队列空或者满可以：</p>
<ul data-nodeid="8084">
<li data-nodeid="8085">
<p data-nodeid="8086">front == rear 此时队列为空；</p>
</li>
<li data-nodeid="8087">
<p data-nodeid="8088">(rear + 1) % capacity == front，此时队列为满。</p>
</li>
</ul>
<p data-nodeid="8089"><em data-nodeid="8836"><strong data-nodeid="8835">注意：由于浪费了一个元素的空间，在申请数组的时候，要申请的空间大小为 k + 1, 并且 capacity 也必须为 k + 1。</strong></em></p>
<p data-nodeid="8090">除此之后，由于是循环数组，下标的活动范围是[0, k]（capacity 为 k+1，所以最大只能取到k）。下标的移动仍然需要利用<strong data-nodeid="8846">取模的技巧</strong>。</p>
<p data-nodeid="8091">【<strong data-nodeid="8852">代码</strong>】第二种方法的思路，我们写出代码如下（解析在注释里）：</p>
<pre class="lang-java" data-nodeid="8092"><code data-language="java"><span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">MyCircularQueue</span> </span>{
&nbsp; &nbsp; <span class="hljs-comment">// 队列的头部元素所在位置</span>
&nbsp; &nbsp; <span class="hljs-keyword">private</span> <span class="hljs-keyword">int</span> front = <span class="hljs-number">0</span>;
&nbsp; &nbsp; <span class="hljs-comment">// 队列的尾巴</span>
&nbsp; &nbsp; <span class="hljs-comment">// 注意我们采用的是前开后闭原则</span>
&nbsp; &nbsp; <span class="hljs-comment">// [front, rear)</span>
&nbsp; &nbsp; <span class="hljs-keyword">private</span> <span class="hljs-keyword">int</span> rear = <span class="hljs-number">0</span>;
&nbsp; &nbsp; <span class="hljs-keyword">private</span> <span class="hljs-keyword">int</span>[] a = <span class="hljs-keyword">null</span>;
&nbsp; &nbsp; <span class="hljs-keyword">private</span> <span class="hljs-keyword">int</span> capacity = <span class="hljs-number">0</span>;
&nbsp; &nbsp; <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-title">MyCircularQueue</span><span class="hljs-params">(<span class="hljs-keyword">int</span> k)</span> </span>{
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// 初始化队列，注意此时队列中元素个数为</span>
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// k + 1</span>
&nbsp; &nbsp; &nbsp; &nbsp; capacity = k + <span class="hljs-number">1</span>;
&nbsp; &nbsp; &nbsp; &nbsp; a = <span class="hljs-keyword">new</span> <span class="hljs-keyword">int</span>[k + <span class="hljs-number">1</span>];
&nbsp; &nbsp; }
&nbsp; &nbsp; <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">boolean</span> <span class="hljs-title">enQueue</span><span class="hljs-params">(<span class="hljs-keyword">int</span> value)</span> </span>{
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// 如果已经满了，无法入队</span>
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-keyword">if</span> (isFull()) {
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-keyword">return</span> <span class="hljs-keyword">false</span>;
&nbsp; &nbsp; &nbsp; &nbsp; }
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// 把元素放到rear位置</span>
&nbsp; &nbsp; &nbsp; &nbsp; a[rear] = value;
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// rear向后移动</span>
&nbsp; &nbsp; &nbsp; &nbsp; rear = (rear + <span class="hljs-number">1</span>) % capacity;
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-keyword">return</span> <span class="hljs-keyword">true</span>;
&nbsp; &nbsp; }
&nbsp; &nbsp; <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">boolean</span> <span class="hljs-title">deQueue</span><span class="hljs-params">()</span> </span>{
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// 如果为空，无法出队</span>
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-keyword">if</span> (isEmpty()) {
&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-keyword">return</span> <span class="hljs-keyword">false</span>;
&nbsp; &nbsp; &nbsp; &nbsp; }
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// 出队之后，front要向前移</span>
&nbsp; &nbsp; &nbsp; &nbsp; front = (front + <span class="hljs-number">1</span>) % capacity;
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-keyword">return</span> <span class="hljs-keyword">true</span>;
&nbsp; &nbsp; }
&nbsp; &nbsp; <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">int</span> <span class="hljs-title">Front</span><span class="hljs-params">()</span> </span>{
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// 如果能取出第一个元素，取a[front];</span>
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-keyword">return</span> isEmpty() ? -<span class="hljs-number">1</span> : a[front];
&nbsp; &nbsp; }
&nbsp; &nbsp; <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">int</span> <span class="hljs-title">Rear</span><span class="hljs-params">()</span> </span>{
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// 由于我们使用的是前开后闭原则</span>
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// [front, rear)</span>
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// 所以在取最后一个元素时，应该是</span>
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// (rear - 1 + capacity) % capacity;</span>
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-keyword">int</span> tail = (rear - <span class="hljs-number">1</span> + capacity) % capacity;
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-keyword">return</span> isEmpty() ? -<span class="hljs-number">1</span> : a[tail];
&nbsp; &nbsp; }
&nbsp; &nbsp; <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">boolean</span> <span class="hljs-title">isEmpty</span><span class="hljs-params">()</span> </span>{
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// 队列是否为空</span>
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-keyword">return</span> front == rear;
&nbsp; &nbsp; }
&nbsp; &nbsp; <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">boolean</span> <span class="hljs-title">isFull</span><span class="hljs-params">()</span> </span>{
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// rear与front之间至少有一个空格</span>
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// 当rear指向这个最后的一个空格时，</span>
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-comment">// 队列就已经放满了!</span>
&nbsp; &nbsp; &nbsp; &nbsp; <span class="hljs-keyword">return</span> (rear + <span class="hljs-number">1</span>) % capacity == front;
&nbsp; &nbsp; }
}
</code></pre>
<blockquote data-nodeid="8093">
<p data-nodeid="8094">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/622.%E8%AE%BE%E8%AE%A1%E5%BE%AA%E7%8E%AF%E9%98%9F%E5%88%97.method2.java" data-nodeid="8856">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/622.%E8%AE%BE%E8%AE%A1%E5%BE%AA%E7%8E%AF%E9%98%9F%E5%88%97.method2.cpp" data-nodeid="8860">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/622.%E8%AE%BE%E8%AE%A1%E5%BE%AA%E7%8E%AF%E9%98%9F%E5%88%97.method2.py" data-nodeid="8864">Python</a></p>
</blockquote>
<p data-nodeid="8095"><strong data-nodeid="8869">复杂度分析</strong>：入队与出队操作都是 O(1)。</p>
<p data-nodeid="8096">我们介绍了两种方法来实现循环队列，下面我分别从<strong data-nodeid="8875">相似点、差别，以及适用范围</strong>对这两种方法进行总结。</p>
<p data-nodeid="8097"><strong data-nodeid="8881">1. 相似点</strong></p>
<p data-nodeid="8098">两种方法都是利用了<strong data-nodeid="8887">取模</strong>的技巧，强调一下，在取模的时候，如果需要向前移动，不要写成 (i - 1) % capacity，注意一定要加上 capacity 之后再取模，否则在 i = 0 的时候就出错了。</p>
<pre class="lang-java" data-nodeid="8099"><code data-language="java">pre = (i - <span class="hljs-number">1</span> + capacity) % capacity
</code></pre>
<p data-nodeid="8100"><strong data-nodeid="8893">2. 差别</strong></p>
<p data-nodeid="8101">这两种方法的唯一区别在于<strong data-nodeid="8899">区分空队列与满队列</strong>时，方法不一样：</p>
<ul data-nodeid="8102">
<li data-nodeid="8103">
<p data-nodeid="8104">方法 1 引入了另外一个变量 used 进行区分</p>
</li>
<li data-nodeid="8105">
<p data-nodeid="8106">方法 2 采用了浪费一个存储空间的办法进行区分</p>
</li>
</ul>
<p data-nodeid="8107"><strong data-nodeid="8907">3. 适用范围</strong></p>
<p data-nodeid="8108">你可能认为方法 2 在队列元素较大时，存在浪费的情况，实际上这两种办法都有不同的适用范围。</p>
<p data-nodeid="8109">方法 1 的缺点在于控制变量较多，达到 3 个。而方法 2 虽然浪费了一个存储空间，但是控制变量较少，只有 2 个。</p>
<p data-nodeid="8110"><strong data-nodeid="8914">在多线程编程里面，控制变量越少，越容易实现无锁编程，因此，在无锁队列里面，利用方法 2 较容易实现无锁队列</strong>。</p>
<p data-nodeid="8111">至此，我们已经可以将循环队列总结在一张思维导图中，如下图所示：</p>
<p data-nodeid="8112"><img src="https://s0.lgstatic.com/i/image6/M01/11/09/CioPOWA_SIqAG7qhAADoVzWnab0092.png" alt="Drawing 41.png" data-nodeid="8918"></p>
<p data-nodeid="8113">一会儿我们还会遇到循环队列的内容，比如用途等，下面我们先来讲讲单调队列。</p>
<h3 data-nodeid="8114">单调队列</h3>
<p data-nodeid="8115">单调队列属于<strong data-nodeid="8926">双端队列</strong>的一种。双端队列与 FIFO 队列的区别在于：</p>
<ul data-nodeid="8116">
<li data-nodeid="8117">
<p data-nodeid="8118">FIFO 队列只能从尾部添加元素，首部弹出元素；</p>
</li>
<li data-nodeid="8119">
<p data-nodeid="8120">双端队列可以从首尾两端 push/pop 元素。</p>
</li>
</ul>
<p data-nodeid="8121">为了让你更直观地看出两者的区别，我分别绘制了 FIFO 队列和双端队列的图片，如下图所示：</p>
<p data-nodeid="8122"><img src="https://s0.lgstatic.com/i/image6/M01/11/09/CioPOWA_SJeAYvJTAAB3ffWmPoY742.png" alt="Drawing 42.png" data-nodeid="8932"></p>
<div data-nodeid="8123"><p style="text-align:center">FIFO 队列</p></div>
<p data-nodeid="8124"><img src="https://s0.lgstatic.com/i/image6/M01/11/09/CioPOWA_SKmAJflUAACNz8oT0A8471.png" alt="Drawing 44.png" data-nodeid="8935"></p>
<div data-nodeid="8125"><p style="text-align:center">双端队列</p></div>
<p data-nodeid="8126">虽然双端队列经常用于工程实践中，但在面试中出现得较多的往往是<strong data-nodeid="8941">单调队列</strong>，因此，本讲我会重点介绍单调队列。</p>
<h4 data-nodeid="8127">什么是单调队列</h4>
<p data-nodeid="8128">首先来看一下单调队列的定义：要求队列中的元素必须满足单调性，比如<strong data-nodeid="8948">单调递增，或者单调整递减</strong>。那么在入栈与出栈的时候，就与普通的队列不一样了。</p>
<p data-nodeid="8129">接下来我将以单调递减为例，详细讲解单调队列的特性，希望你可以自己推导单调递增的情况。如果有什么疑问可以在评论区留言，我会定期给大家解答。</p>
<p data-nodeid="8130"><strong data-nodeid="8954">单调队列在入队的时候，需要满足 2 点</strong>：</p>
<ol data-nodeid="8131">
<li data-nodeid="8132">
<p data-nodeid="8133">入队前队列已经满足单调性；</p>
</li>
<li data-nodeid="8134">
<p data-nodeid="8135">入队后队列仍然满足单调性。</p>
</li>
</ol>
<p data-nodeid="8136">这里以单调递减队列为例，具体操作如下图所示（为了更直观地展示，我将不同大小的数值绘制为不同的高度）：</p>
<p data-nodeid="8137"><img src="https://s0.lgstatic.com/i/image6/M01/11/0D/Cgp9HWA_SLyAEHB2AEJPbY2MLoE581.gif" alt="5.gif" data-nodeid="8960"></p>
<p data-nodeid="8138">Step 1. 已有单调队列满足单调递减。</p>
<p data-nodeid="8139">Step 2. 元素 5 要从尾部加入队列中。</p>
<p data-nodeid="8140">Step 3. 元素 5 与尾部元素 3 比较，3 &lt; 5，因此扔掉 3。</p>
<p data-nodeid="8141">Step 4. 元素 5 与尾部元素 4 比较，4 &lt; 5，因此扔掉 4。</p>
<p data-nodeid="8142">Step 5. 元素 5 与尾部元素 6 比较，6 &gt; 5，因此将 5 入队。</p>
<p data-nodeid="8143">可以发现，每次入队的时候，为了保证队列的单调性，还要<strong data-nodeid="8979">剔除掉尾部的元素</strong>。<strong data-nodeid="8980">直到尾部的元素大于等于入队元素（因为是单调递减队列）</strong>。</p>
<pre class="lang-java" data-nodeid="8144"><code data-language="java">    <span class="hljs-function"><span class="hljs-keyword">private</span> <span class="hljs-keyword">void</span> <span class="hljs-title">push</span><span class="hljs-params">(<span class="hljs-keyword">int</span> val)</span> </span>{
        <span class="hljs-keyword">while</span> (!Q.isEmpty() &amp;&amp; Q.getLast() &lt; val) {
            Q.removeLast();
        }
        <span class="hljs-comment">// 将元素入队</span>
        Q.addLast(val);
    }
</code></pre>
<p data-nodeid="8145"><strong data-nodeid="8989">单调队列在出队时</strong>，也与普通的队列出队方式<strong data-nodeid="8990">不一样</strong>。出队时，需要给出一个 value，如果 value 与队首相等，才能将这个数出队，代码如下所示：</p>
<pre class="lang-java" data-nodeid="8146"><code data-language="java">    <span class="hljs-comment">// 出队的时候，要相等的时候才会出队</span>
    <span class="hljs-function"><span class="hljs-keyword">private</span> <span class="hljs-keyword">void</span> <span class="hljs-title">pop</span><span class="hljs-params">(<span class="hljs-keyword">int</span> val)</span> </span>{
        <span class="hljs-keyword">if</span> (!Q.isEmpty() &amp;&amp; Q.getFirst() == val) {
            Q.removeFirst();
        }
    }
</code></pre>
<p data-nodeid="8147">那么，采用这种比较特殊的入队与出队的方式有什么巧妙的地方呢？</p>
<ul data-nodeid="8148">
<li data-nodeid="8149">
<p data-nodeid="8150">入队之后，队首元素 Q.getFirst() 就是队列中的最大值。这个比较容易想到，因为我们这里是以单调递减队列为例，所以队首元素就是最大值。</p>
</li>
<li data-nodeid="8151">
<p data-nodeid="8152">出队时，如果一个元素已经被其他元素<strong data-nodeid="8998">剔除</strong>出去了，就不会再出队。但如果一个元素是当前队列中的最大值，那么就会再出队。</p>
</li>
</ul>
<p data-nodeid="8153">关于这一点，你可以参考下面的动图演示（为了更清晰地演示此过程，被叉掉的元素还保留在原处，但实际上已经不在队列中了）：</p>
<p data-nodeid="8154"><img src="https://s0.lgstatic.com/i/image6/M00/11/0A/CioPOWA_SQOAZRMRABqVn-_iVoo720.gif" alt="6.gif" data-nodeid="9002"></p>
<p data-nodeid="8155">Step 1. 将元素 5 入队，元素 3,4 会被剔除掉。区间 [8,6,4,3,5] 最大值为队首元素 8。</p>
<p data-nodeid="8156">Step 2. 将元素 8 出队，元素相等，直接出队。区间 [6,4,3,5] 最大值为队首元素 6。</p>
<p data-nodeid="8157">Step 3. 将元素 6 出队，元素相等，直接出队。区间 [4,3,5] 最大值为队首元素 5。</p>
<p data-nodeid="8158">Step 4. 将元素 4 出队，此时元素不等，队列不变。区间 [3,5] 最大值为队首元素 5。</p>
<p data-nodeid="8159">Step 5. 将元素 3 出队，此时元素不等，队列不变。区间 [5] 最大值为队首元素 5。</p>
<p data-nodeid="8160">Step 6. 将元素 5 出队，此时元素相等，直接出队。</p>
<p data-nodeid="8161">可以发现，单调递减队列最重要的特性是：<strong data-nodeid="9034">入队与出队的组合，可以在 O(1) 时间得到某个区间上的最大值</strong>。</p>
<p data-nodeid="8162">前面说了利用单调队列可以得到某个区间上的最大值。可是这个区间是什么？怎么定量地描述这个区间？与队列中的元素个数有什么关系？</p>
<p data-nodeid="8163">针对以上 3 个疑问，可以分两种情况展开讨论：</p>
<ol data-nodeid="8164">
<li data-nodeid="8165">
<p data-nodeid="8166">只有入队的情况</p>
</li>
<li data-nodeid="8167">
<p data-nodeid="8168">有出队与入队的情况</p>
</li>
</ol>
<p data-nodeid="8169">为了更直观地展示，我分别制作了两种情况对应的动图演示。先来看只有入队的情况，如下图所示：</p>
<p data-nodeid="8170"><img src="https://s0.lgstatic.com/i/image6/M01/11/0D/Cgp9HWA_STiAcHJnAAmEZ9koVKA128.gif" alt="7.gif" data-nodeid="9042"></p>
<p data-nodeid="8171">Step 1. 元素 3 入队，此时队首元素为 3，表示着区间[3]最大值为 3。</p>
<p data-nodeid="8172">Step 2. 元素 2 入队，此时队列首元素为 3，表示区间[3,2]最大值为 3。</p>
<p data-nodeid="8173">Step 3. 元素 5 入队，此时队首元素为 5，此时队列覆盖范围长度为 3，可以得到<strong data-nodeid="9061">区间 [3,2,5] 最大值为 5。</strong></p>
<p data-nodeid="8174">继续执行入队，想必你也能得出结论了：在没有出队的情况下，黄色覆盖范围会一直增加，队首元素就表示这个黄色覆盖范围的最大值。</p>
<p data-nodeid="8175">下面我们再来看出队与入队混合的情况。在上图 Step3 的基础上，如果再把 A[3] = 6 入队，这个时候，队列的覆盖范围长度为 4，假设我们想控制这个覆盖范围长度为 3，应该怎么办？</p>
<p data-nodeid="8176">此时，我们只需要将 A[0] 出队即可。如下图所示：</p>
<p data-nodeid="8177"><img src="https://s0.lgstatic.com/i/image6/M01/11/0E/Cgp9HWA_SX6ADn1yAAlfQannP2I331.gif" alt="8.gif" data-nodeid="9075"><br>
Step 4. 将元素 A[0] = 3 出队，由于此时 3 != Q.getFirst()，所以什么也不做。队列覆盖范围为 [2, 5]，长度为 2。</p>
<p data-nodeid="8178">Step 5. 将 A[3] = 6 入队，此时队首元素为 6，覆盖范围为[2,5,6]，覆盖长度为 3，可以得到<strong data-nodeid="9105">区间 [2,5,6] 最大值为 6</strong>。</p>
<p data-nodeid="8179">Step 6. 将 A[1] = 2 出队，此时 2 != Q.getFirst()，所以什么也不做。此时队列覆盖范围为 [5, 6]，长度为 2。</p>
<p data-nodeid="8180">Step 7. 将 A[4] = 4 入队，此时覆盖范围为 [5, 6, 4]，覆盖长度为 3，<strong data-nodeid="9134">区间 [5,6,4] 最大值为 6</strong>。</p>
<p data-nodeid="8181">从上图中可以发现以下几个重点：</p>
<ul data-nodeid="8182">
<li data-nodeid="8183">
<p data-nodeid="8184">入队，扩张单调队列的覆盖范围；</p>
</li>
<li data-nodeid="8185">
<p data-nodeid="8186">出队，控制单调递减队列的覆盖范围；</p>
</li>
<li data-nodeid="8187">
<p data-nodeid="8188">队首元素就是覆盖范围的最大值；</p>
</li>
<li data-nodeid="8189">
<p data-nodeid="8190">队列中的元素个数<strong data-nodeid="9144">小于</strong>覆盖范围元素的个数。</p>
</li>
</ul>
<p data-nodeid="8191">这里，虽然我们只讨论了单调递减队列，实际上单调递增队列的特性也非常类似，你可以下来自己推导一下。下面我们深入到题目中，趁热打铁，把刚学到的知识运用起来。</p>
<h4 data-nodeid="8192">例 3：滑动窗口的最大值</h4>
<p data-nodeid="8193">【<strong data-nodeid="9152">题目</strong>】给定一个数组和滑动窗口的大小，请找出所有滑动窗口里的最大值。</p>
<p data-nodeid="8194">输入：nums = [1,3,-1,-3,5,3], k = 3</p>
<p data-nodeid="8195">输出：[3,3,5,5]</p>
<p data-nodeid="8196"><strong data-nodeid="9166">解释</strong>：</p>
<p data-nodeid="8197"><img src="https://s0.lgstatic.com/i/image6/M00/11/12/Cgp9HWA_S1aAJXv9AABKF_TFCN8607.png" alt="Drawing 68.png" data-nodeid="9169"></p>
<p data-nodeid="8198">【<strong data-nodeid="9179">分析</strong>】这是一道来自 <strong data-nodeid="9180">eBay</strong> 的面试题。拿到时题目之后，可以发现，题目要求还是比较赤裸裸的，不妨先模拟一下，看看能不能想到比较好的解决办法。</p>
<p data-nodeid="8199"><strong data-nodeid="9186">1. 模拟</strong></p>
<p data-nodeid="8200">首先我们发现窗口在滑动的时候，有元素不停地进出。因此，可以采用<strong data-nodeid="9196">队列</strong>来试一下。由于窗口长度为 3，所以将队列的长度固定为 3。<br>
<img src="https://s0.lgstatic.com/i/image6/M00/11/0C/CioPOWA_ScmAQ8ZYAAoV9uo-AJQ439.gif" alt="9.gif" data-nodeid="9195"></p>
<p data-nodeid="8201">Step 1. 首先将元素 1 入队。</p>
<p data-nodeid="8202">Step 2. 再将元素 3 入队。</p>
<p data-nodeid="8203">Step 3. 再将 -1 入队，此时队列长度为 3，可以从 [1, 3, -1] 中得到最大值 3。</p>
<p data-nodeid="8204">Step 4. 将 1 出队，然后将 3 入队，可以得到 [3,-1,3] 的最大值为3。</p>
<p data-nodeid="8205">Step 5. 将 3 出队，然后再将 5 入队，可以得到 [-1, 3, 5] 的最大值为 5。</p>
<p data-nodeid="8206">Step 6. 将 -1 队出，然后再将 3 入队，可以得到 [3,5,3] 的最大值为 5。</p>
<p data-nodeid="8207"><strong data-nodeid="9224">2. 规律</strong></p>
<p data-nodeid="8208">我们发现两点：</p>
<p data-nodeid="8209">（1）不停地有元素出队入队</p>
<p data-nodeid="8210">（2）需要拿<strong data-nodeid="9231">到队列中的最大值</strong></p>
<p data-nodeid="8211">如果能够在 O(1) 时间内拿到队列中的最大值，那么就可以在 O(N) 时间解决掉这个问题。</p>
<p data-nodeid="8212"><strong data-nodeid="9238">3. 匹配</strong></p>
<p data-nodeid="8213">到这里为止，已经匹配到了你学过的数据结构了——<strong data-nodeid="9244">单调递减队列</strong>！</p>
<p data-nodeid="8214"><strong data-nodeid="9250">4. 边界</strong></p>
<p data-nodeid="8215">接下来，你可能准备开始写代码了，不过我还需要和你讨论一些细节与边界。</p>
<ul data-nodeid="8216">
<li data-nodeid="8217">
<p data-nodeid="8218">滑动窗口的大小与队列的大小。</p>
</li>
<li data-nodeid="8219">
<p data-nodeid="8220">哪种单调递减？为什么？</p>
</li>
</ul>
<p data-nodeid="8221">首先我们看<strong data-nodeid="9267">窗口的大小</strong>。当使用 Q.getFirst() 时，得到的是整个队列的最大值，因此队列的大小，必须与滑动窗口的大小一样。也就是说，当 A[i] 入队的时候，A[i-k] 必须要出队！这样才能保证队列中的元素最多有 k 个。</p>
<p data-nodeid="8222">虽然我们已经知道要使用单调递减队列求解这道题目了，但单调递减有两种：</p>
<ol data-nodeid="8223">
<li data-nodeid="8224">
<p data-nodeid="8225">严格单调递减（队列中没有重复元素）</p>
</li>
<li data-nodeid="8226">
<p data-nodeid="8227">单调递减</p>
</li>
</ol>
<p data-nodeid="8228">那么，应该用哪种呢？首先我们看一下<strong data-nodeid="9276">严格单调递减</strong>是否可以工作，如下图所示：</p>
<p data-nodeid="8229"><img src="https://s0.lgstatic.com/i/image6/M00/11/13/Cgp9HWA_TDqAU-urAADUKwAZCHk961.png" alt="Drawing 76.png" data-nodeid="9279"></p>
<p data-nodeid="8230">假设执行到 A[2] = 3 时，采用<strong data-nodeid="9301">严格单调递减（队列中相等的元素也会被踢出去）</strong>，入队时，A[2] 将会把所有的元素都踢出队列，队列变成 [3]，那么可以得到 [3,2,3] 的最大值为 3。</p>
<p data-nodeid="8231">但是由于窗口滑动的时候，接着需要把 A[0] = 3 出队，出队之后，队列为空。然后再将 A[3] = 1 入队得到。</p>
<p data-nodeid="8232"><img src="https://s0.lgstatic.com/i/image6/M00/11/13/Cgp9HWA_TEyAfSBRAADZkvnyEtw271.png" alt="Drawing 78.png" data-nodeid="9313"></p>
<p data-nodeid="8233">此时得到 [2,3,1] 的最大值为 1，这就出错了！所以我们<strong data-nodeid="9323">不能使用严格单调递减队列求解</strong>。</p>
<blockquote data-nodeid="8234">
<p data-nodeid="8235">注意：严格意义上来说，是可以使用严格单调递减队列，不过需要换一种出队方式，我会在例 4 讲解，在这里你可以先这么认为。</p>
</blockquote>
<p data-nodeid="8236">【<strong data-nodeid="9330">画图</strong>】这部分运行过程与“覆盖范围”完全类似。经过前面的分析，现在你可以尝试自己画一下利用单调队列运行的过程图。如果你有什么疑问，可以在评论区留言，我们一起讨论。</p>
<p data-nodeid="8237">【<strong data-nodeid="9336">代码</strong>】现在我们已经分析清楚算法与数据结构，接下来就可以写代码了，代码如下（解析在注释里）：</p>
<pre class="lang-java" data-nodeid="8238"><code data-language="java"><span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">Solution</span> </span>{
    <span class="hljs-comment">// 单调队列使用双端队列来实现</span>
    <span class="hljs-keyword">private</span> ArrayDeque&lt;Integer&gt; Q = <span class="hljs-keyword">new</span> ArrayDeque&lt;Integer&gt;();
    <span class="hljs-comment">// 入队的时候，last方向入队，但是入队的时候</span>
    <span class="hljs-comment">// 需要保证整个队列的数值是单调的</span>
    <span class="hljs-comment">// (在这个题里面我们需要是递减的)</span>
    <span class="hljs-comment">// 并且需要注意，这里是Q.getLast() &lt; val</span>
    <span class="hljs-comment">// 如果写成Q.getLast() &lt;= val就变成了严格单调递增</span>
    <span class="hljs-function"><span class="hljs-keyword">private</span> <span class="hljs-keyword">void</span> <span class="hljs-title">push</span><span class="hljs-params">(<span class="hljs-keyword">int</span> val)</span> </span>{
        <span class="hljs-keyword">while</span> (!Q.isEmpty() &amp;&amp; Q.getLast() &lt; val) {
            Q.removeLast();
        }
        <span class="hljs-comment">// 将元素入队</span>
        Q.addLast(val);
    }
    <span class="hljs-comment">// 出队的时候，要相等的时候才会出队</span>
    <span class="hljs-function"><span class="hljs-keyword">private</span> <span class="hljs-keyword">void</span> <span class="hljs-title">pop</span><span class="hljs-params">(<span class="hljs-keyword">int</span> val)</span> </span>{
        <span class="hljs-keyword">if</span> (!Q.isEmpty() &amp;&amp; Q.getFirst() == val) {
            Q.removeFirst();
        }
    }
    <span class="hljs-keyword">public</span> <span class="hljs-keyword">int</span>[] maxSlidingWindow(<span class="hljs-keyword">int</span>[] nums, <span class="hljs-keyword">int</span> k) {
        List&lt;Integer&gt; ans = <span class="hljs-keyword">new</span> ArrayList&lt;&gt;();
        <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> i = <span class="hljs-number">0</span>; i &lt; nums.length; i++) {
            push(nums[i]);
            <span class="hljs-comment">// 如果队列中的元素还少于k个</span>
            <span class="hljs-comment">// 那么这个时候，还不能去取最大值</span>
            <span class="hljs-keyword">if</span> (i &lt; k - <span class="hljs-number">1</span>) {
                <span class="hljs-keyword">continue</span>;
            }
            <span class="hljs-comment">// 队首元素就是最大值</span>
            ans.add(Q.getFirst());
            <span class="hljs-comment">// 尝试去移除元素</span>
            pop(nums[i - k + <span class="hljs-number">1</span>]);
        }
        <span class="hljs-comment">// 将ans转换成为数组返回!</span>
        <span class="hljs-keyword">return</span> ans.stream().mapToInt(Integer::valueOf).toArray();
    }
}
</code></pre>
<blockquote data-nodeid="8239">
<p data-nodeid="8240">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/239.%E6%BB%91%E5%8A%A8%E7%AA%97%E5%8F%A3%E6%9C%80%E5%A4%A7%E5%80%BC.java" data-nodeid="9340">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/239.%E6%BB%91%E5%8A%A8%E7%AA%97%E5%8F%A3%E6%9C%80%E5%A4%A7%E5%80%BC.cpp" data-nodeid="9344">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/239.%E6%BB%91%E5%8A%A8%E7%AA%97%E5%8F%A3%E6%9C%80%E5%A4%A7%E5%80%BC.py" data-nodeid="9348">Python</a></p>
</blockquote>
<p data-nodeid="8241"><strong data-nodeid="9353">复杂度分析</strong>：每个元素都只入队一次，出队一次，每次入队与出队都是 O(1) 的复杂度，因此整个算法的复杂度为 O(n)。</p>
<p data-nodeid="8242">【<strong data-nodeid="9367">小结</strong>】至此，我们已经学习了利用单调队列来解决滑动窗口的最大值。下面还可以扩展一下，比如：如何解决滑动窗口的最大值与最小值？具体你可以参考“<a href="https://www.luogu.com.cn/problem/P1886" data-nodeid="9361">题目</a>与<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/P1886.java" data-nodeid="9365">代码</a>”。</p>
<p data-nodeid="8243">我们再对单调队列的特性做一下总结：</p>
<ul data-nodeid="8244">
<li data-nodeid="8245">
<p data-nodeid="8246">入队，扩展单调队列的覆盖范围</p>
</li>
<li data-nodeid="8247">
<p data-nodeid="8248">出队，缩小单调队列的覆盖范围</p>
</li>
<li data-nodeid="8249">
<p data-nodeid="8250">队首元素，是覆盖范围的最大值/最小值</p>
</li>
<li data-nodeid="8251">
<p data-nodeid="8252">范围内的最大值，需要用单调递减队列</p>
</li>
<li data-nodeid="8253">
<p data-nodeid="8254">范围内的最小值，需要用单调递增队列</p>
</li>
</ul>
<p data-nodeid="8255">单调队列在解决滑动窗口的最大值的时候，由于这个<strong data-nodeid="9379">滑动窗口的大小是固定的</strong>。因此，单调队列的大小也是固定的。那么，你能不能用循环队列来模拟单调队列，求解滑动窗口最大值的题目呢？</p>
<blockquote data-nodeid="8256">
<p data-nodeid="8257">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/239.%E6%BB%91%E5%8A%A8%E7%AA%97%E5%8F%A3%E6%9C%80%E5%A4%A7%E5%80%BC.%E5%BE%AA%E7%8E%AF%E9%98%9F%E5%88%97.java" data-nodeid="9383">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/239.%E6%BB%91%E5%8A%A8%E7%AA%97%E5%8F%A3%E6%9C%80%E5%A4%A7%E5%80%BC.%E5%BE%AA%E7%8E%AF%E9%98%9F%E5%88%97.cpp" data-nodeid="9387">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/239.%E6%BB%91%E5%8A%A8%E7%AA%97%E5%8F%A3%E6%9C%80%E5%A4%A7%E5%80%BC.%E5%BE%AA%E7%8E%AF%E9%98%9F%E5%88%97.py" data-nodeid="9391">Python</a></p>
</blockquote>
<h4 data-nodeid="8258">例 4：捡金币游戏</h4>
<p data-nodeid="8259">【<strong data-nodeid="9417">题目</strong>】给定一个数组 A[]，每个位置 i 放置了金币 A[i]，小明从 A[0] 出发。当小明走到 A[i] 的时候，下一步他可以选择 A[i+1, i+k]（当然，不能超出数组边界）。每个位置一旦被选择，将会把那个位置的金币收走（如果为负数，就要交出金币）。请问，最多能收集多少金币？</p>
<p data-nodeid="8260">输入：[1,-1,-100,-1000,100,3], k = 2</p>
<p data-nodeid="8261">输出：4</p>
<p data-nodeid="8262"><strong data-nodeid="9444">解释</strong>：从 A[0] = 1 出发，收获金币 1。下一步走往 A[2] = -100, 收获金币 -100。再下一步走到 A[4] = 100，收获金币 100，最后走到 A[5] = 3，收获金币 3。最多收获 1 - 100 + 100 + 3 = 4。没有比这个更好的走法了。</p>
<p data-nodeid="8263">【<strong data-nodeid="9462">分析</strong>】这是一道来自<strong data-nodeid="9463">头条</strong>的面试题。首先要纠正一种容易出错的想法：当走到 A[i] 的时候，选择 A[i+1, i+k] 里面的最大值作为下一步的落脚点。</p>
<p data-nodeid="8264">如果是采用这种做法，那么根据示例会得到以下信息：</p>
<ul data-nodeid="8265">
<li data-nodeid="8266">
<p data-nodeid="8267">从 A[0] = 1 出发，<strong data-nodeid="9482">收获金币 1</strong>。接下来面临的区间是 [-1, -100]。由于 -1 更大，所以选择A[1] = -1 为落脚点；</p>
</li>
<li data-nodeid="8268">
<p data-nodeid="8269">从 A[1] = -1 出发，<strong data-nodeid="9500">收获金币 -1</strong>。接下来面临的区间是 [-100, -1000]，由于 -100 更大，所以选择 A[2] = -100 为落脚点；</p>
</li>
<li data-nodeid="8270">
<p data-nodeid="8271">从 A[2] = -100 出发，<strong data-nodeid="9522">收获金币 -100</strong>。接下来面临的区间是 [-1000, 100]，由于 A[4] = 100 更大，所以选择 A[4] = 100 为落脚点；</p>
</li>
<li data-nodeid="8272">
<p data-nodeid="8273">从 A[4] = 100 出发，<strong data-nodeid="9536">收获金币 100</strong>，接下来走到 A[5] = 3；</p>
</li>
<li data-nodeid="8274">
<p data-nodeid="8275">停在 A[5] = 3，<strong data-nodeid="9546">收获金币 3</strong>。一共收获金币 1 + (-1) + (-100) + 100 + 3 = 3。并不是最优的 4 个金币。</p>
</li>
</ul>
<p data-nodeid="8276">所以，这道题目，不能采用上述方法。下面我们利用“<strong data-nodeid="9552">四步分析法</strong>”继续寻找更优解法。</p>
<p data-nodeid="8277"><strong data-nodeid="9558">1. 模拟</strong></p>
<p data-nodeid="8278">在分析题目时，一种办法是顺着题意走，另外一种办法是做假设。假设我们已经知道了走到 [0, i-1] 时收获的金币数目，用 get[] 数组来存放，那么走到 A[i] 最多可以收获的金币数目可以是下图这样：</p>
<p data-nodeid="8279"><img src="https://s0.lgstatic.com/i/image6/M00/11/13/Cgp9HWA_S4SAXevyAABpi3LNISI737.png" alt="Drawing 80.png" data-nodeid="9573"></p>
<pre class="lang-java" data-nodeid="8280"><code data-language="java">get[i] = max(get[i-k, ...., i-<span class="hljs-number">1</span>]) + A[i]
</code></pre>
<p data-nodeid="8281">考虑到 i - k 实际上可能会小于 0，对于这种情况，只需要取 max(0, i-k) 就可以了。</p>
<pre class="lang-java" data-nodeid="8282"><code data-language="java">get[i] = max(get[max(i-k, <span class="hljs-number">0</span>), ...., i-<span class="hljs-number">1</span>]) + A[i]
</code></pre>
<p data-nodeid="8283">接下来采用上述方法来进行一波演算，以 [1,-1,-100,-100000,100,3], k = 2 为例，具体动图如下：</p>
<p data-nodeid="8284"><img src="https://s0.lgstatic.com/i/image6/M01/11/13/Cgp9HWA_TACALWYlAB5Uh_D8ZdQ298.gif" alt="10.gif" data-nodeid="9582"></p>
<p data-nodeid="8285">1. index = 0 时，前面没有元素，所以 get[0] = A[0]</p>
<p data-nodeid="8286">2. index = 1 时，只有 get[0] 可以选。所以 get[1] = 1 + -1 = 0。</p>
<p data-nodeid="8287">3. index = 2 时，前面有 get[0], get[1] 可以选，较大的数为1，因此get[2] = 1 - 100 = -99。</p>
<p data-nodeid="8288">4. index = 3 时，前面有 get[1],get[2] 可以选，当然选较大的数 0 了。因此，get[3] = 0 - 1000 = -1000。</p>
<p data-nodeid="8289">5. index = 4 时，前面有 get[2],get[3] 可以选。 当然选较大的数 get[2]。因此，get[4] = -99 + 100 = 1。</p>
<p data-nodeid="8290">6. index = 5 时，前面有 get[3],get[4] 可以选。当然选较大的数 get[4]。因此，get[5] = 1 + 3 = 4。此时我们得到了最终答案 4。</p>
<p data-nodeid="8291"><strong data-nodeid="9705">2. 规律</strong><br>
经过模拟之后，我们发现，如果按照模拟的方法来写代码，那么复杂度会达到 O(Nk)。现在的问题是，每次要求 get[i] 的时候，都需要从前面长度为 k 的黄色范围里面选择一个最大值。有没有什么办法可以优化呢？</p>
<p data-nodeid="8292">如果专注于黄色区域，会发现一个特点：<strong data-nodeid="9711">黄色区域就是一个滑动窗口，我们要选的是滑动窗口的最大值</strong>。</p>
<p data-nodeid="8293"><strong data-nodeid="9727">3. 匹配</strong><br>
现在我们已经发现了滑动窗口，并且要求这个<strong data-nodeid="9728">滑动窗口的最大值</strong>。那么数据结构已经呼之欲出了——<strong data-nodeid="9729">单调队列</strong>。</p>
<p data-nodeid="8294"><strong data-nodeid="9753">4. 边界</strong><br>
这里要特别注意的是第一个元素 get[0]。此时单调队列为空。在求 get[0] 的时候，不能去单调队列中找最大值，要直接设置 get[0] = A[0]。</p>
<p data-nodeid="8295"><img src="https://s0.lgstatic.com/i/image6/M00/11/13/Cgp9HWA_TH6AUMlAAB3Xvu5uEzw814.gif" alt="11.gif" data-nodeid="9756"></p>
<p data-nodeid="8296">Step1. 当 index = 0 时，队列 Q[] 为空，那么 get[0] = A[0]。然后将 A[0] 入队。</p>
<p data-nodeid="8297">Step 2. 当 index = 1 时，get[1] = 队首元素 + A[1] = 1 + -1 = 0。然后将 0 入队。</p>
<p data-nodeid="8298">Step 3. 当 index = 2 时，get[2] = 队首元素 + A[2] = 1 - 100 = -99。然后将 -99 入队。</p>
<p data-nodeid="8299">Step 4. 当 index = 3 时，首先将超出范围的元素出队。然后，get[3] = 队首元素 + A[3] = 0 - 1000 = -1000。然后将 -1000 入队。</p>
<p data-nodeid="8300">Step 5. 当 index = 4 时，首先将队列中超出范围的元素出队，然后 get[4] = 队首元素 + A[4] = -99 + 100 = 1。然后再将 1 入队。</p>
<p data-nodeid="8301">接下来我们<strong data-nodeid="9814">重点看一下入队</strong>，由于 1 比队列中的元素都要大，按照单调队列的定义，所以队列中的元素都被清空。</p>
<p data-nodeid="8302">Step 6. 当 index = 5 时，首先将队列中超出范围的元素出队（只不过此时队首元素和要出队的元素并不相等）。然后 get[5] = 1 + 3 = 4。</p>
<p data-nodeid="8303">【<strong data-nodeid="9825">代码</strong>】结合上述的讲解，写出代码如下（解析在注释里）：</p>
<pre class="lang-java" data-nodeid="8304"><code data-language="java"><span class="hljs-class"><span class="hljs-keyword">class</span>&nbsp;<span class="hljs-title">Solution</span>&nbsp;</span>{
&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-function"><span class="hljs-keyword">public</span>&nbsp;<span class="hljs-keyword">int</span>&nbsp;<span class="hljs-title">maxResult</span><span class="hljs-params">(<span class="hljs-keyword">int</span>[]&nbsp;A,&nbsp;<span class="hljs-keyword">int</span>&nbsp;k)</span>&nbsp;</span>{
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-comment">//&nbsp;处理掉各种边界条件!</span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-keyword">if</span>&nbsp;(A&nbsp;==&nbsp;<span class="hljs-keyword">null</span>&nbsp;||&nbsp;A.length&nbsp;==&nbsp;<span class="hljs-number">0</span>&nbsp;||&nbsp;k&nbsp;&lt;=&nbsp;<span class="hljs-number">0</span>)&nbsp;{
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-keyword">return</span>&nbsp;<span class="hljs-number">0</span>;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-keyword">final</span>&nbsp;<span class="hljs-keyword">int</span>&nbsp;N&nbsp;=&nbsp;A.length;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-comment">//&nbsp;每个位置可以收集到的金币数目</span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-keyword">int</span>[]&nbsp;get&nbsp;=&nbsp;<span class="hljs-keyword">new</span>&nbsp;<span class="hljs-keyword">int</span>[N];
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-comment">//&nbsp;单调队列，这里并不是严格递减</span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ArrayDeque&lt;Integer&gt;&nbsp;Q&nbsp;=&nbsp;<span class="hljs-keyword">new</span>&nbsp;ArrayDeque&lt;Integer&gt;();
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-keyword">for</span>&nbsp;(<span class="hljs-keyword">int</span>&nbsp;i&nbsp;=&nbsp;<span class="hljs-number">0</span>;&nbsp;i&nbsp;&lt;&nbsp;N;&nbsp;i++)&nbsp;{
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-comment">//&nbsp;在取最大值之前，需要保证单调队列中都是有效值。</span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-comment">//&nbsp;也就是都在区间里面的值</span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-comment">//&nbsp;当要求get[i]的时候，</span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-comment">//&nbsp;单调队列中应该是只能保存[i-k,&nbsp;i-1]这个范围</span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-keyword">if</span>&nbsp;(i&nbsp;-&nbsp;k&nbsp;&gt;&nbsp;<span class="hljs-number">0</span>)&nbsp;{
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-keyword">if</span>&nbsp;(!Q.isEmpty()&nbsp;&amp;&amp;&nbsp;Q.getFirst()&nbsp;==&nbsp;get[i-k-<span class="hljs-number">1</span>])&nbsp;{
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Q.removeFirst();
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-comment">//&nbsp;从单调队列中取得较大值</span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-keyword">int</span>&nbsp;old&nbsp;=&nbsp;Q.isEmpty()&nbsp;?&nbsp;<span class="hljs-number">0</span>&nbsp;:&nbsp;Q.getFirst();
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;get[i]&nbsp;=&nbsp;old&nbsp;+&nbsp;A[i];
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-comment">//&nbsp;入队的时候，采用单调队列入队</span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-keyword">while</span>&nbsp;(!Q.isEmpty()&nbsp;&amp;&amp;&nbsp;Q.getLast()&nbsp;&lt;&nbsp;get[i])&nbsp;{
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Q.removeLast();
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Q.addLast(get[i]);
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;}
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span class="hljs-keyword">return</span>&nbsp;get[N-<span class="hljs-number">1</span>];
&nbsp;&nbsp;&nbsp;&nbsp;}
}
</code></pre>
<blockquote data-nodeid="8305">
<p data-nodeid="8306">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/1696.%E8%B7%B3%E8%B7%83%E6%B8%B8%E6%88%8F-vi.java" data-nodeid="9829">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/1696.%E8%B7%B3%E8%B7%83%E6%B8%B8%E6%88%8F-vi.cpp" data-nodeid="9833">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/1696.%E8%B7%B3%E8%B7%83%E6%B8%B8%E6%88%8F-vi.py" data-nodeid="9837">Python</a></p>
</blockquote>
<p data-nodeid="8307"><strong data-nodeid="9842">复杂度分析</strong>：每个元素只入队一次，出队一次，每次入队与出队复杂度都是 O(n)。因此，时间复杂度为 O(n)，空间复杂度为 O(n)。</p>
<p data-nodeid="8308">【<strong data-nodeid="9851">小结</strong>】这仍然是一个单调队列的题目。不同之处在于操作的时候，是通过了一个 get[] 数组来进行滑动窗口的。因此，这道题的考点就是两方面：</p>
<ol data-nodeid="8309">
<li data-nodeid="8310">
<p data-nodeid="8311">找到 get[] 数组，并且知道如何生成；</p>
</li>
<li data-nodeid="8312">
<p data-nodeid="8313">利用单调队列在 get[] 数组上操作，找到滑动窗口的最大值。</p>
</li>
</ol>
<p data-nodeid="8314">通过这道题你应该明白，<strong data-nodeid="9865">有的时候，滑动窗口不一定是在给定的数组上操作，还可能会在一个隐藏的数组上操作</strong>。</p>
<p data-nodeid="8315"><strong data-nodeid="9870">拓展：是否存在不同的出队方式</strong>？</p>
<p data-nodeid="8316">前面我们在学习单调队列的时候，利用了元素相等来判断是否出队。这种出队方式的特点是<strong data-nodeid="9876">必须要保证单调队列不能是严格递减或者严格递增</strong>。</p>
<p data-nodeid="8317">那么是否还有别的出队方式？是否可以不通过元素值相等的方式进行出队？针对上述两个问题，我们一起来看一下具体如何处理。</p>
<ul data-nodeid="8318">
<li data-nodeid="8319">
<p data-nodeid="8320">入队：入队的时候，将<strong data-nodeid="9882">值和下标一起入队。</strong></p>
</li>
<li data-nodeid="8321">
<p data-nodeid="8322">出队：直接判断队首元素的下标，进而判断是否应该将队首元素出队。</p>
</li>
</ul>
<p data-nodeid="8323">基于这种思想，我们可以将这道题换种写法。代码如下（解析在注释里）：</p>
<pre class="lang-java" data-nodeid="8324"><code data-language="java"><span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">Solution</span> </span>{
    <span class="hljs-comment">// 走到下标index = idx的记录</span>
    <span class="hljs-class"><span class="hljs-keyword">class</span> <span class="hljs-title">Node</span> </span>{
        <span class="hljs-comment">// 累计取得的金币!</span>
        <span class="hljs-keyword">int</span> sum = <span class="hljs-number">0</span>;
        <span class="hljs-comment">// 在index = idx的时候</span>
        <span class="hljs-comment">// 取得的最大金币为sum</span>
        <span class="hljs-keyword">int</span> idx = <span class="hljs-number">0</span>;
        <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-title">Node</span><span class="hljs-params">(<span class="hljs-keyword">int</span> s, <span class="hljs-keyword">int</span> i)</span> </span>{
            sum = s;
            idx = i;
        }
    };
    <span class="hljs-function"><span class="hljs-keyword">public</span> <span class="hljs-keyword">int</span> <span class="hljs-title">maxResult</span><span class="hljs-params">(<span class="hljs-keyword">int</span>[] A, <span class="hljs-keyword">int</span> k)</span> </span>{
        <span class="hljs-comment">// 严格单调递减队列</span>
        <span class="hljs-comment">// 里面存放的是每个位置可以收集到的金币以及下标index</span>
        ArrayDeque&lt;Node&gt; Q = <span class="hljs-keyword">new</span> ArrayDeque&lt;Node&gt;();
        <span class="hljs-comment">// 走到i位置时，最大的金币收益</span>
        <span class="hljs-keyword">int</span> ans = <span class="hljs-number">0</span>;
        <span class="hljs-keyword">for</span> (<span class="hljs-keyword">int</span> i = <span class="hljs-number">0</span>; i &lt; A.length; i++) {
            <span class="hljs-comment">// 出队！</span>
            <span class="hljs-comment">// 对于i而言，</span>
            <span class="hljs-comment">// [i-k, i-1]可以跳到A[i]</span>
            <span class="hljs-comment">// 最远i - (i - k) = k</span>
            <span class="hljs-comment">// 因此超出这个范围的，必须要出队</span>
            <span class="hljs-keyword">while</span> (!Q.isEmpty() &amp;&amp; i - Q.getFirst().idx &gt; k) {
                Q.removeFirst();
            }
            <span class="hljs-comment">// 获得在位置i时的收益</span>
            <span class="hljs-keyword">if</span> (Q.isEmpty()) {
                ans = A[i];
            } <span class="hljs-keyword">else</span> {
                ans = Q.getFirst().sum + A[i];
            }
            <span class="hljs-comment">// 入队，当A[i]入队的时候，要把小于他的那些</span>
            <span class="hljs-comment">// 收益比他低，又比他旧的给踢除掉</span>
            <span class="hljs-comment">// 注意！这里使用的是严格的单调递减!</span>
            <span class="hljs-keyword">while</span> (!Q.isEmpty() &amp;&amp; Q.getLast().sum &lt;= ans) {
                Q.removeLast();
            }
            Q.addLast(<span class="hljs-keyword">new</span> Node(ans, i));
        }
        <span class="hljs-keyword">return</span> ans;
    }
}
</code></pre>
<blockquote data-nodeid="8325">
<p data-nodeid="8326">代码：<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/1696.%E8%B7%B3%E8%B7%83%E6%B8%B8%E6%88%8F-vi.2.java" data-nodeid="9888">Java</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/1696.%E8%B7%B3%E8%B7%83%E6%B8%B8%E6%88%8F-vi.2.cpp" data-nodeid="9892">C++</a>/<a href="https://github.com/lagoueduCol/Algorithm-Dryad/blob/main/02.Queue/1696.%E8%B7%B3%E8%B7%83%E6%B8%B8%E6%88%8F-vi.2.py" data-nodeid="9896">Python</a></p>
</blockquote>
<p data-nodeid="8327"><strong data-nodeid="9901">复杂度分析</strong>：每个元素只入队一次，出队一次，每次入队与出队复杂度都是 O(n)。因此，时间复杂度为 O(n)，空间复杂度为 O(n)。</p>
<h3 data-nodeid="8328">总结与延伸</h3>
<p data-nodeid="8329">至此，你已经了解了单调队列的用法和特性。和“<a href="https://kaiwu.lagou.com/course/courseInfo.htm?courseId=685#/detail/pc?id=6690" data-nodeid="9906">第 01 讲</a>”一样，经过不断地“浇灌”，我们又得到了一棵枝繁叶茂的“大树”。回到知识层面，我把本讲重点介绍、且需要你掌握的内容总结在一张思维导图中，如下图所示：</p>
<p data-nodeid="8330"><img src="https://s0.lgstatic.com/i/image6/M00/11/10/CioPOWA_TLCATeR6AAFTfMBlaiw858.png" alt="Drawing 98.png" data-nodeid="9910"></p>
<p data-nodeid="8331">每个学科都会涉及很多知识，靠做题记知识点，就容易出现知识之间的割裂而形成孤立地，无法将知识系统化。希望你在做题的过程中能够主动尝试建立知识之间的联系，主动思考如何让新知识与原有知识相关联，提高学习效率。比如，循环队列实际上也是单调队列的好帮手，当然你也可以用来实现 FIFO 队列。</p>
<p data-nodeid="8332">FIFO 队列和单调队列帮助我们解决了很多有趣的题目，通过这些题目，希望你能够整理出以下模板：</p>
<ul data-nodeid="8333">
<li data-nodeid="8334">
<p data-nodeid="8335">分层遍历</p>
</li>
<li data-nodeid="8336">
<p data-nodeid="8337">循环队列</p>
</li>
<li data-nodeid="8338">
<p data-nodeid="8339">单调队列</p>
</li>
</ul>
<h3 data-nodeid="8340">思考题</h3>
<p data-nodeid="8341">我再给你留一道<strong data-nodeid="9922">思考题</strong>：在专栏的前两讲里学习了栈和队列，让我想到了曾经在面试中遇到过两道有意思的题目：</p>
<ul data-nodeid="8342">
<li data-nodeid="8343">
<p data-nodeid="8344">请利用栈来实现一个队列的操作</p>
</li>
<li data-nodeid="8345">
<p data-nodeid="8346">请用队列来实现一个栈的操作</p>
</li>
</ul>
<p data-nodeid="8347">你可以把答案写在评论区，我们一起讨论。接下来请和我一起踏上更加奇妙的算法与数据结构的旅程。让我们继续前进。</p>
<p data-nodeid="8348" class="">下一讲将介绍 03 | 优先级队列：堆与优先级队列，如何筛选最优元素。记得按时来探险。</p>